# 茶山浮亭（杭州长埭村，由牧）

> 目录曾标为松阳/Studio RE+N；当时发出原文写明是杭州转塘长埭村、由牧建筑设计，并说明与松阳浮亭不是同一项目。此处按发出原文更正显示名，未改写原文。

- 归档编号：`chashan_fu_pavilion`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 同项目互见

本项目另有目录 `youmu_tea_pavilion`。与 `chashan_fu_pavilion` 为同一项目。当时发出原文写明是杭州转塘长埭村、由牧建筑设计的「茶山浮亭」，并说明与松阳浮亭不是同一项目。本目录为 2026-10-25 的另一批配图。

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `chashan_fu_pavilion_1.jpg` | `226601707f7c246a6aa6a6479514cbe06fc701c4935667b2921b6e4bf1d6ce92` | 177983 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_1.jpg` |
| `chashan_fu_pavilion_10.jpg` | `97c1c3f32fc5be774d6d37701f07cfdddca51262da633494828d91a6d2391805` | 285175 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_10.jpg` |
| `chashan_fu_pavilion_2.jpg` | `377f9135b890b299f790a6ed64a3ddb0aea112e590ea5625907dd89d2a4d0c80` | 142550 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_2.jpg` |
| `chashan_fu_pavilion_3.jpg` | `cc9f97a4b865e6dbbdabd8082be69534814325f72531c0596b5a99574b7d0331` | 211173 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_3.jpg` |
| `chashan_fu_pavilion_4.jpg` | `8141d9efa238a770ba5dec0d59fbc6760994af1e870f091084fbbfc623bb80e0` | 150625 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_4.jpg` |
| `chashan_fu_pavilion_5.jpg` | `79715d05e18d3d4497c1a9315a27f135071a7f4298b19c905901ac9d5fee673d` | 282585 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_5.jpg` |
| `chashan_fu_pavilion_6.jpg` | `bf5fb3f87b65a34e2b7e0f9cca9ec8d52bb7a7358b4e921cde7f5b74d912b9a9` | 211119 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_6.jpg` |
| `chashan_fu_pavilion_7.jpg` | `434eb9d3970b43cd55daa61563bca3f2490bc46111b7bc9b5d6deb5bc9d7f63d` | 116063 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_7.jpg` |
| `chashan_fu_pavilion_8.jpg` | `f7d352028841fc003ab1c269074700b792dfcc18a1fe285760ec46e23dd7d36d` | 227798 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_8.jpg` |
| `chashan_fu_pavilion_9.jpg` | `086ca8ab36d1ac721dabcc23c5eb6be64177243aeeacf4eded2d8d3fa71c6d95` | 37346 | 是 | `/workspace/landscape/structures/chashan_fu_pavilion_9.jpg` |
