# 长宁外环市民服务驿站（上海，致正）

- 归档编号：`changning_service_stations_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch29`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `changning_service_stations_sh_1.jpg` | `e325fa090c67c49305b5008fa22f14f26e7ee77b17fd7cdd1709d81dce17be4e` | 225240 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_1.jpg` |
| `changning_service_stations_sh_10.jpg` | `59f9a6b277f828d5e0da0c0e8b2b7bf9cf0db102dcd0045192addc9eb44bdd17` | 65742 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_10.jpg` |
| `changning_service_stations_sh_2.jpg` | `8c54a0ef32509c2116097c4b77290ce4d02516088a04b85f403180468bef0308` | 155606 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_2.jpg` |
| `changning_service_stations_sh_3.jpg` | `68ecae237df441bb4706910f1d2bcce50df9d25a7806430620132538ac16dafd` | 211514 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_3.jpg` |
| `changning_service_stations_sh_4.jpg` | `daa69b9c8ff3bfa289fc0dd60688eadcf010d255120fcbfe50efdd434b517761` | 267031 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_4.jpg` |
| `changning_service_stations_sh_5.jpg` | `97d9d0218ff0def3ea50694927061eaecb5483c6517f1b3f16a2951839905fba` | 317868 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_5.jpg` |
| `changning_service_stations_sh_6.jpg` | `ab94e9b76959a6d3573fde34c9645cfb322e1e9d465009b554885f380c13308e` | 267006 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_6.jpg` |
| `changning_service_stations_sh_7.jpg` | `494287909d1b6aa6e55a55c351fda848bfb231903108f5b6f358f7d84686159e` | 220115 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_7.jpg` |
| `changning_service_stations_sh_8.jpg` | `88aeab3fcd2053636a3aa37c344140231286611762eec27c3c55fd3f44c05594` | 210073 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_8.jpg` |
| `changning_service_stations_sh_9.jpg` | `fc59b271b84599bfc3ebb3f3173b29e67c44b67fb50c55db5ae9192e0de50268` | 306782 | 是 | `/workspace/landscape/batch29/changning_service_stations_sh_9.jpg` |
