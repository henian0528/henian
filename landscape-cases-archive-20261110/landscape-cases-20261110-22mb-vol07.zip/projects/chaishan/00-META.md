# 舟山柴山岛海边长亭（GN 栖城设计）

- 归档编号：`chaishan`
- 推荐状态（汇总）：`uncertain`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-18
  - 出处说明：目录为周日；柴山岛海边长亭。是否正式群推未从对话记录完全确认
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/2026-10-18`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `chaishan_01_island_entrance_aerial.jpg` | `e241d4b8f01191332a42d331e55be977742f3664c2fc16a5e5a258ffd2126d45` | 492948 | 是 | `/workspace/landscape/2026-10-18/chaishan_01_island_entrance_aerial.jpg` |
| `chaishan_02_topdown_pier.jpg` | `a2cf091b403ac4a68e796cd118daf774d44c4ff72281b65d4eebb615aa73c6b5` | 504859 | 是 | `/workspace/landscape/2026-10-18/chaishan_02_topdown_pier.jpg` |
| `chaishan_03_leaves_over_rocks_aerial.jpg` | `324c0bbfc2fb1dffae7e8a02328ad9c74978f31c24e488bb84a8e9aac2c6c805` | 434967 | 是 | `/workspace/landscape/2026-10-18/chaishan_03_leaves_over_rocks_aerial.jpg` |
| `chaishan_04_frame_silhouette.jpg` | `7746a6ef36e27e46cb73bc9639721781445b829a3f683787bef73efe0d6f02ee` | 323861 | 是 | `/workspace/landscape/2026-10-18/chaishan_04_frame_silhouette.jpg` |
| `chaishan_05_under_canopy.jpg` | `673a652e59406867229b3d4f309ace520f28bee13b35facbd0b46e3ab7b84bec` | 691034 | 是 | `/workspace/landscape/2026-10-18/chaishan_05_under_canopy.jpg` |
| `chaishan_06_seating_view.jpg` | `f5fc4026a6ac294fecf7e5c175f8bb172f8bd79114527cf067fb3a34b38980b9` | 320682 | 是 | `/workspace/landscape/2026-10-18/chaishan_06_seating_view.jpg` |
| `chaishan_07_leaves_and_hills.jpg` | `66fff126d22df60bc9f33c9bc9ad37d2b24c1fd0156274224927144d6d343d66` | 482879 | 是 | `/workspace/landscape/2026-10-18/chaishan_07_leaves_and_hills.jpg` |
| `chaishan_08_cantilever_over_rocks.jpg` | `b5877f569c00f984ee917fe41b66f1309e34fc2084dc6272bdb5cb3548b62727` | 563428 | 是 | `/workspace/landscape/2026-10-18/chaishan_08_cantilever_over_rocks.jpg` |
| `chaishan_09_dusk_aerial.jpg` | `fee3fa22467263a175a946c38db0cb65c161b5f51258606c80adc5435773e343` | 557496 | 是 | `/workspace/landscape/2026-10-18/chaishan_09_dusk_aerial.jpg` |
| `chaishan_10_night_glow.jpg` | `cf20c22dc06331f116e14a483e6888ecb9cd87ba29e4556e21745581423a256a` | 379483 | 是 | `/workspace/landscape/2026-10-18/chaishan_10_night_glow.jpg` |
