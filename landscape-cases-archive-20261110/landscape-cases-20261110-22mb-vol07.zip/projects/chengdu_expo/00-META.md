# 成都园博相关白色亭（white）

- 归档编号：`chengdu_expo`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `chengdu_expo_1.jpg` | `b0dd84de8a497d6ea313c5cc4a60696273a083b37e8712f63cdb7392ea75af4a` | 124999 | 是 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_1.jpg` |
| `chengdu_expo_2.jpg` | `88dafa63ae55606763b21c930657bc826d1f754c4b7f568b85b458ee2aec6faa` | 159817 | 是 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_2.jpg` |
| `chengdu_expo_3.jpg` | `6d99b2269d7e78083bc3fb5d63dd4e887756876abf18169e5d001811f705bf3f` | 66036 | 否 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_3.jpg` |
| `chengdu_expo_4.jpg` | `0eb02660e87539775f5195cce3fefe26bb66521a83188f92ad45bdf5778d3fac` | 122756 | 否 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_4.jpg` |
| `chengdu_expo_5.jpg` | `948577883091f64069d9dfe03cb7e4a64c473b36266e86d233f4de5b3366ec8c` | 100875 | 是 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_5.jpg` |
| `chengdu_expo_6.jpg` | `3bf90779d0cf3a7b1196719c1899e1a422333e113c54a7e9bee8cbee134542b2` | 121961 | 是 | `/workspace/landscape/china-canopy-cases/white/chengdu_expo_6.jpg` |
