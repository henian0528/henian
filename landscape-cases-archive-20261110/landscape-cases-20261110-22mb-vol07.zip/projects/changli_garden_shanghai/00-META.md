# 昌里花园（上海，TM Studio）

- 归档编号：`changli_garden_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch31`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `changli_garden_shanghai_1.jpg` | `cb7afe2f9e1746023632bb19cc24240f8728c76f296b7ce02ae3fd2c13bbda12` | 779807 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_1.jpg` |
| `changli_garden_shanghai_10.jpg` | `28f3e5d2c560bf9202fdd689a57ef8509b8e7179529141c8c37d35f369a7bea1` | 86349 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_10.jpg` |
| `changli_garden_shanghai_2.jpg` | `b64edd40ed5790c692bf976d29b71ca17dfc9ffd0f1997721bce68ba4ebe3909` | 678909 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_2.jpg` |
| `changli_garden_shanghai_3.jpg` | `696cc98f0ca113e12db1a482190711ee1f2bf3430b2cb219b4f72d855b3031b9` | 718677 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_3.jpg` |
| `changli_garden_shanghai_4.jpg` | `a921d4b9957c308c4b7f8f04d7fc7d455a605e7926a42006796ded1ed2eee71b` | 677731 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_4.jpg` |
| `changli_garden_shanghai_5.jpg` | `4b5a0fcae22be13116e9a4c7914f6cc8e989e0243b446bddf78c90c881849e86` | 915195 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_5.jpg` |
| `changli_garden_shanghai_6.jpg` | `1868feb89baa4ce96168c172082588d1ac38f7d533a9ded8c78c16791e768698` | 578050 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_6.jpg` |
| `changli_garden_shanghai_7.jpg` | `d144cf762a735ba2c488c8e363e65c76d19601f148351696f205e4a130ff9639` | 809676 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_7.jpg` |
| `changli_garden_shanghai_8.jpg` | `4b7eab5f60be9d66e220439bd32f052b6a219fd24dda608fe02fda20dcb623d2` | 675072 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_8.jpg` |
| `changli_garden_shanghai_9.jpg` | `5e878ea3463b1e7fcd2d72f047ee66c23435269bf24b5064bc514a11bb04fc86` | 387703 | 是 | `/workspace/landscape/batch31/changli_garden_shanghai_9.jpg` |
