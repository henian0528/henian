# 长亭驿（杭州滨江钱塘江，同济原作）

- 归档编号：`changting_hangzhou`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-10
  - 出处说明：日期目录 2026-11-10（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-10/changting_hangzhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ct_01_photo_overview.jpg` | `915cbb659b67f2efc5cfea8affc9603bc1799f3bbf52d65921ee5d9ba73928a9` | 507512 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_01_photo_overview.jpg` |
| `ct_02_photo_longview.jpg` | `767db38c6e04cace5bab6bae13969fdf0431ff408b13e6e4f07e9d901b24e71e` | 530055 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_02_photo_longview.jpg` |
| `ct_03_photo_passage.jpg` | `64c6214d6b9a382ddb46ee86f567c9fee6d28416b0b8fd9d067c1bf379e82c7c` | 302976 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_03_photo_passage.jpg` |
| `ct_04_photo_structure.jpg` | `cf4dca5cffcd588a858b1309e405deca35dc8633e70700e84cf60b412dfb60f8` | 921480 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_04_photo_structure.jpg` |
| `ct_05_photo_nature.jpg` | `dae67cc2cb049b749326e3a73d596d192101f6f1b23cb72aad7dae091641cbed` | 1599754 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_05_photo_nature.jpg` |
| `ct_06_drawing_axo.jpg` | `167eeff327576559262984197c48a66db1ab0e4b69e5e40142a391318e176a1a` | 164486 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_06_drawing_axo.jpg` |
| `ct_07_drawing_plan1.jpg` | `edd30a49c8e0dc2a58a0dfb8b51254be45bf5521e19bef48e8ac3fbb22903583` | 202322 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_07_drawing_plan1.jpg` |
| `ct_08_drawing_plan2.jpg` | `dc6e5d6037a73c7c20728ce1a869ad15639e2a908c35026eba5375f4ad6672ee` | 59779 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_08_drawing_plan2.jpg` |
| `ct_09_drawing_elevation.jpg` | `d88064d0adfaa783a21f35407136eedad8e55e4f236fe7b9e4eafe5ce634894f` | 109713 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_09_drawing_elevation.jpg` |
| `ct_10_drawing_section.jpg` | `06ec5a76bc24058684a75f630744ad580ea0464bfe2a41388698cdb8f1633d8d` | 133946 | 否 | `/workspace/landscape/2026-11-10/changting_hangzhou/ct_10_drawing_section.jpg` |
