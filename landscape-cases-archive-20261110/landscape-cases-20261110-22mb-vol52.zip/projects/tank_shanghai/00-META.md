# 上海油罐艺术中心（variety2 早期批次）

- 归档编号：`tank_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：4 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `tank_shanghai_1.jpg` | `dec7aaba29d2130c8fb0f28ebff5f04343e89ff4bf6de3ea6bdbd1b9ab9096f1` | 227040 | 是 | `/workspace/landscape/variety2/tank_shanghai_1.jpg` |
| `tank_shanghai_2.jpg` | `8c054675d00259d5716c450c0900004be343d9aa7735a69fee0487cbbad77e90` | 198838 | 是 | `/workspace/landscape/variety2/tank_shanghai_2.jpg` |
| `tank_shanghai_3.jpg` | `dcfb8520d22c95cace42c0b4294f31f449cafe9a962c6e001de22babb5bab658` | 161962 | 是 | `/workspace/landscape/variety2/tank_shanghai_3.jpg` |
| `tank_shanghai_4.jpg` | `eabd2f0472f0253c4a246773e1accb3d51d1106e4a21ab8cfdc23f495dd803bf` | 144428 | 是 | `/workspace/landscape/variety2/tank_shanghai_4.jpg` |
| `tank_shanghai_5.jpg` | `765345d4774905a9a367506305a300ed31eb231e01361f2c06292c2c1be87533` | 165636 | 否 | `/workspace/landscape/variety2/tank_shanghai_5.jpg` |
