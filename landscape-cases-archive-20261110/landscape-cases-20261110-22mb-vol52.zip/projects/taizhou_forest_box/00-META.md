# 台州森林盒子（batch7）

- 归档编号：`taizhou_forest_box`
- 推荐状态（汇总）：`uncertain`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch7`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `taizhou_forest_box_1.jpg` | `7e3a694ba197c75450d0e101eb16cc783eac7b7edba9154a44e4924445895068` | 524564 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_1.jpg` |
| `taizhou_forest_box_10.jpg` | `4e284bcbc5752082afeeeb690803d3580d55a1cf0d8019f7d8bf1433a5594e21` | 112237 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_10.jpg` |
| `taizhou_forest_box_2.jpg` | `5c20a7603dfb735a95467569b047a21d5244ede6c387c022c7a3a0d73bf52bf5` | 595094 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_2.jpg` |
| `taizhou_forest_box_3.jpg` | `61d304d2bf97310e0b4042478540bc9102026f956daab5323218db934311ffa2` | 463519 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_3.jpg` |
| `taizhou_forest_box_4.jpg` | `fe2e58249b27ecb3f809a2cd47603d087d888b1417973dd6b41d2340aab3197a` | 546999 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_4.jpg` |
| `taizhou_forest_box_5.jpg` | `5f298a1a69845fbcc360ba58a242243ade8cf7516dd2209786a908041e8d6578` | 454906 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_5.jpg` |
| `taizhou_forest_box_6.jpg` | `1eaba9874d57f20fa6335ad1572a45f76950bec03803d2b4ca4e84693355e5e8` | 540918 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_6.jpg` |
| `taizhou_forest_box_7.jpg` | `07563a91135535301073451852e3354cbe1367b990ff61d813e8fef8e9dca5a3` | 458325 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_7.jpg` |
| `taizhou_forest_box_8.jpg` | `3d4c63f42b4e1f742c54aeb1289e66d6762c79c7d99d9bd17e8c0dd69b95d4a8` | 468623 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_8.jpg` |
| `taizhou_forest_box_9.jpg` | `4cd4e714a0953f435bb84bb47d5611e09fc02a8f933895f6759fd8da94364a96` | 645615 | 是 | `/workspace/landscape/batch7/taizhou_forest_box_9.jpg` |
