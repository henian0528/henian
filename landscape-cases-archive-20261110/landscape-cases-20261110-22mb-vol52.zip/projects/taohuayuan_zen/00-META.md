# 桃花源（courtyard 早期批次）

- 归档编号：`taohuayuan_zen`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `taohuayuan_zen_1.jpg` | `3ffee40b40b642c32e5475ca70bf991cb5fdbff158b619714f9df7229accc87b` | 127042 | 是 | `/workspace/landscape/courtyard/taohuayuan_zen_1.jpg` |
| `taohuayuan_zen_2.jpg` | `38c5a729ceae65828d417a9fbccf15fe5ac3beb7a4f1ae49cb64b57ba9f64094` | 221738 | 是 | `/workspace/landscape/courtyard/taohuayuan_zen_2.jpg` |
| `taohuayuan_zen_3.jpg` | `3b3f39937fc9ba81d6b035fea6ae1a398934c47bae7c4eb9d983e3d30f93f523` | 126379 | 是 | `/workspace/landscape/courtyard/taohuayuan_zen_3.jpg` |
| `taohuayuan_zen_4.jpg` | `fff182271222487ef080c445fa6ce72d0d422ab661a0c9ac383681e3ff357d7d` | 385156 | 否 | `/workspace/landscape/courtyard/taohuayuan_zen_4.jpg` |
| `taohuayuan_zen_5.jpg` | `c2eff2d184b948145e4e180ecbd860707d8008bcd8f6f12a8478a0360442e52d` | 312102 | 否 | `/workspace/landscape/courtyard/taohuayuan_zen_5.jpg` |
| `taohuayuan_zen_6.jpg` | `bd301467a200eefc360d467143ab9ff5f402ff756139dd72a162006ebe7f4a6e` | 486943 | 是 | `/workspace/landscape/courtyard/taohuayuan_zen_6.jpg` |
