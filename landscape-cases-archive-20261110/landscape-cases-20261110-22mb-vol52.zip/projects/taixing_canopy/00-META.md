# 泰兴运河畔「大船篷／大茶棚」

- 归档编号：`taixing_canopy`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-24
  - 出处说明：日期目录 2026-10-24（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-10-24/taixing_canopy`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `taixing_01_photo.jpg` | `94e75220a6acb6f6a87fb52a49d189cb16b9caf387b5bf5f7ad69095e4b400d9` | 1000403 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_01_photo.jpg` |
| `taixing_02_photo.jpg` | `847298e02e7ca262ffcdb2d9ae47973f26602a4675c08c66806106a4831af7e2` | 1373636 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_02_photo.jpg` |
| `taixing_03_photo.jpg` | `92dc57ffe808c02ba403e7cd78a7186668eaf3bfa5df86529b72bedd62db8f2f` | 1046268 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_03_photo.jpg` |
| `taixing_05_photo.jpg` | `05f3654e2af2086ffb75db4cb25641821906c1b994228b97f8f4cb3ceac9e165` | 1108610 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_05_photo.jpg` |
| `taixing_07_photo.jpg` | `80375c355127fb092b8d46686a6efc1b45e56d956e39b34f434ae87327990c5c` | 1192268 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_07_photo.jpg` |
| `taixing_10_photo.jpg` | `552b9ee7c8595debbaf6cbae95caa48a83ed92617c404da21529e018d9c575a5` | 1333444 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_10_photo.jpg` |
| `taixing_12_photo.jpg` | `80c01c8a57504d56ee9c1d5ede7aade75d5084dc0a4f5b8dd9683692989cb0be` | 2685497 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_12_photo.jpg` |
| `taixing_15_drawing_site_plan.jpg` | `aaa41715ad22d8565c485e45a268b2ac01561286590bb10cd013fc5f0cb98091` | 1043302 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_15_drawing_site_plan.jpg` |
| `taixing_16_drawing_floor_plan.jpg` | `158b8c0a486163c1c760575380c14114049428f6777c49b8a64c767492420032` | 408899 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_16_drawing_floor_plan.jpg` |
| `taixing_18_drawing_section_1.jpg` | `e5cdd64148aad25b9f3c7d9b71fc05590d49dcde2f2af54ca4cf2fc1f36bc8bf` | 321950 | 否 | `/workspace/landscape/2026-10-24/taixing_canopy/taixing_18_drawing_section_1.jpg` |
