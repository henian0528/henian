# 风袂驿（惠州罗浮山显岗水库）

- 归档编号：`fengmei_huizhou`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：20
- 在 bot 附件库中匹配到的配图：10 / 20（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-*）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-01
  - 出处说明：日期目录 2026-11-01（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-01/fengmei_huizhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch7`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `fm_01_photo_aerial.jpg` | `a53ddba1923fb6e91dba3947355408df170dcf3ff41f185ad4697db539eda6f4` | 908043 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_01_photo_aerial.jpg` |
| `fm_02_photo.jpg` | `726fc03ea413f930c157cb0cfc2153d8cc82e7279876441e491fec9dabef917f` | 894684 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_02_photo.jpg` |
| `fm_03_photo.jpg` | `a73e7c816e36b2780af0ceb51b5ed7243ec01124ee7cadbc4fbc0f06af7eb59d` | 940951 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_03_photo.jpg` |
| `fm_04_photo.jpg` | `2ef76e2025e88d1f4266739add3783f089e0583b3051d243d56b0f2f39d66329` | 1028981 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_04_photo.jpg` |
| `fm_05_photo.jpg` | `93485911571a4652f0e7714ef41dfb964686c75f6393df998428159688a1f6df` | 856962 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_05_photo.jpg` |
| `fm_06_photo.jpg` | `01c78d138c818838c904f482ef40b8905398c42d685bffa784539341be6e92e5` | 766420 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_06_photo.jpg` |
| `fm_07_photo.jpg` | `5aa1d96cea309e7a278a69791df93d81dec4310eaa349db9885164fd2573fed9` | 214227 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_07_photo.jpg` |
| `fm_08_photo.jpg` | `42ab2bdb86e655438fd5ecb6f6418e75cf06a85a2eb0e090547d3b686095ef26` | 980726 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_08_photo.jpg` |
| `fm_09_drawing_elevation.jpg` | `533d2e31d15c75205196d651367b6f7f4ad2ccf2d48b11cc0b0f7c1b52581ad7` | 570109 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_09_drawing_elevation.jpg` |
| `fm_10_drawing_axo.jpg` | `a2d82849aa256527aacddb22775c98d4d279b503998cd7ce64fd809a4e88191a` | 431611 | 否 | `/workspace/landscape/2026-11-01/fengmei_huizhou/fm_10_drawing_axo.jpg` |
| `fengmei_canopy_grove_1.jpg` | `6806f14f3463f1cebf8258681c3b46fbcd368fc272e34daa4f4141233c3ab252` | 254113 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_1.jpg` |
| `fengmei_canopy_grove_10.jpg` | `a692a18fc72672c21aab8946aeeebf70152e8fe8b9eb26c14e8e480fec71ac7f` | 65193 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_10.jpg` |
| `fengmei_canopy_grove_2.jpg` | `3d0b1e862079bfcde0ebb136cda117bfdff36f7df0f083a8348ac1079ff90921` | 422724 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_2.jpg` |
| `fengmei_canopy_grove_3.jpg` | `043284b3c26a8327fcfc20ae2064c122178d5621af32e855ac8e8dd2290833a1` | 360223 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_3.jpg` |
| `fengmei_canopy_grove_4.jpg` | `b8788680fef5ba37b853a5b365551233099e72a01b94d9e85169b8fd9ebde224` | 294270 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_4.jpg` |
| `fengmei_canopy_grove_5.jpg` | `0931a4a819458df286f5e6d505fa29c2cc4e93a653b72050680d49d3627beae6` | 260965 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_5.jpg` |
| `fengmei_canopy_grove_6.jpg` | `a06354e25007ce74c1196245759ce676d39414471149a5bfc54f347dd5618109` | 275909 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_6.jpg` |
| `fengmei_canopy_grove_7.jpg` | `5a63ab6209b31ef50b0fcf64d88c0a57322c6550c6109ac392e05bf0f99e4a5f` | 250218 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_7.jpg` |
| `fengmei_canopy_grove_8.jpg` | `fc824dab8658cb7c5fda82cc8f60138b2c143ac5dc92a532bff5ca89863214ce` | 150117 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_8.jpg` |
| `fengmei_canopy_grove_9.jpg` | `9dfaaa957f1d54be806074a28412c5d5e9bdf4db74a880281dc18417f5742403` | 226059 | 是 | `/workspace/landscape/batch7/fengmei_canopy_grove_9.jpg` |
