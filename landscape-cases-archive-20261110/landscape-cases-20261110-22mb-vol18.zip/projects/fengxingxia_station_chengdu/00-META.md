# 丰行侠驿站（成都）

- 归档编号：`fengxingxia_station_chengdu`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `fengxingxia_station_chengdu_1.jpg` | `584668214dea2c9d1e3bd9a4050824b50e91c51164756b654ba13ceaca4e2949` | 612860 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_1.jpg` |
| `fengxingxia_station_chengdu_10.jpg` | `60367ac9fad75a02b355cb7b6c2fd08cc80cb55ae7b9c4a1963bf37d9fdc4f0a` | 181032 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_10.jpg` |
| `fengxingxia_station_chengdu_2.jpg` | `7116cdac61f5c0d303bff400bf7be00488bee69f6476f8c586c4f5817de35582` | 489494 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_2.jpg` |
| `fengxingxia_station_chengdu_3.jpg` | `7658e9d457dfa6fcd0512823b4392431102a0fec1e17b16e0e476ea7ea0e55b3` | 437897 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_3.jpg` |
| `fengxingxia_station_chengdu_4.jpg` | `aa0a532463ea12958f86a9af3d66384efe56700bc7fbdae1bbba2041dcaa5ed6` | 569309 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_4.jpg` |
| `fengxingxia_station_chengdu_5.jpg` | `a120efc39af6385fb7c803125338f0f5b74ce1607a3c19f4a36adbc28558af9d` | 579636 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_5.jpg` |
| `fengxingxia_station_chengdu_6.jpg` | `35efeaf34974cf319e620276d41f4b4dcd16f8e921531f2e224c9cdce0581d60` | 538496 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_6.jpg` |
| `fengxingxia_station_chengdu_7.jpg` | `2e32f87853862f1bdcbf073e4c986d0ccfae614fbdde3adaa5f1162868d60f08` | 486830 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_7.jpg` |
| `fengxingxia_station_chengdu_8.jpg` | `d4f50e7d2902a7002afbb81a073b88bcd3996050ecea9ff8e53428adc5bdcbe1` | 700960 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_8.jpg` |
| `fengxingxia_station_chengdu_9.jpg` | `73c1089c157d062672831441d0fb8caeebc43211951327599fa23aa34de19caf` | 598712 | 是 | `/workspace/landscape/batch9/fengxingxia_station_chengdu_9.jpg` |
