# 风之园驿站（苏州金鸡湖，矶崎新+胡倩工作室）

- 归档编号：`fengzhiyuan_suzhou`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-08
  - 出处说明：日期目录 2026-11-08（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-08/fengzhiyuan_suzhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `fz_01_photo_aerial.jpg` | `39c3835cbb49f6c8552ee65eefd007986154edbb9dae497e3b3608954173b78b` | 406381 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_01_photo_aerial.jpg` |
| `fz_02_photo_distant.jpg` | `0f084d238661f5560eec14c1bbbb2e659299c89098d980836321070aec46b8a9` | 424384 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_02_photo_distant.jpg` |
| `fz_03_photo_base_cylinder.jpg` | `cd444c9d400bf1c5e6e2b489a69d3c7244b07a44213b0de5f1fa1c45f46a2761` | 369356 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_03_photo_base_cylinder.jpg` |
| `fz_04_photo_white_cylinder.jpg` | `1a557192b9af533380163e73bd6b25c60a8015098f70ae542c36cff18fae95e3` | 151079 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_04_photo_white_cylinder.jpg` |
| `fz_05_photo_lattice.jpg` | `945b0899698fbef17c8b65f3386a092cbaa378b55178efc152830fa3386a9b36` | 320775 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_05_photo_lattice.jpg` |
| `fz_06_photo_courtyard.jpg` | `82bf2e04ec4930c2ca5f4183da5bb3fdd0754d559795b87a02359df98b2529b3` | 529812 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_06_photo_courtyard.jpg` |
| `fz_07_photo_night.jpg` | `15f7d5f7ce60737228ceb11a5e17f6401ef26338668d3ae687e42c211eda360a` | 405732 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_07_photo_night.jpg` |
| `fz_08_drawing_plan_1f.jpg` | `20cf49acf72df051d5004f5b8030dea6d6420f0ac9220f337bedf9d51fa0f97b` | 703663 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_08_drawing_plan_1f.jpg` |
| `fz_09_drawing_plan_2f.jpg` | `12d1168dd408fa7bb09c524fd3f6b0e6bd9749c4803d4c512cbaed29c6117f3e` | 321840 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_09_drawing_plan_2f.jpg` |
| `fz_10_drawing_section.jpg` | `3283663534f8b7ddd8a00f7ec603c5fbfdb83ae7334e1905235d74e134658d3c` | 181413 | 否 | `/workspace/landscape/2026-11-08/fengzhiyuan_suzhou/fz_10_drawing_section.jpg` |
