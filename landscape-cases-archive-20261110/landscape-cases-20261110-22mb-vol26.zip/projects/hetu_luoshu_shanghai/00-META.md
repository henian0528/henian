# 河图洛书亭（上海西岸黄浦江畔）

- 归档编号：`hetu_luoshu_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：40
- 在 bot 附件库中匹配到的配图：4 / 40（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-27
  - 出处说明：日期目录 2026-10-27（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-27/hetu_luoshu_shanghai`
  - 注：项目子目录精选图
  - 本记录配图文件数：34

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·国内折板/伞状遮阳及棚架案例（目录 china-canopy-cases；期刊有「答应找国内类似 Superkilen 案例」）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases`
  - 注：来源 china-canopy-cases
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `gom_001.jpg` | `bb4af36ded70016f3cb29a476afe193f45bcc53826b769eebbbbebfe53f1171d` | 388998 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_001.jpg` |
| `gom_002.jpg` | `f84ae456a2a4ca9c5177bc6de35baa98ce8ee16413e3883820862dcd51da7bec` | 800536 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_002.jpg` |
| `gom_003.jpg` | `59ef4f98033e18c33cb287dd3af7e430f06a3b3afa7ba8b64e55e78527d7242b` | 267505 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_003.jpg` |
| `gom_004.jpg` | `6734726beeb3c8e018f07e768dbb3fe4241cb66753ca5361eee18b4692d7966b` | 593497 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_004.jpg` |
| `gom_005.jpg` | `124bc953afacf09ca9de82713013eeb42d291308baf1d7c7b794b69ec6a7a867` | 281265 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_005.jpg` |
| `gom_006.jpg` | `e68fc3d9bf3514b8d4bbdde3006b6a69fa1fb076bcc3667b84114b152bbeb274` | 380975 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_006.jpg` |
| `gom_007.jpg` | `d721fdef6f41406d66e439512c25e0a38612ffba6470f14388b8a0dc9156654b` | 200694 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_007.jpg` |
| `gom_008.jpg` | `8310b8162ae166c837b8a680493d32d23f5c33f5b11d4aa638285c345837036f` | 314520 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_008.jpg` |
| `gom_009.jpg` | `acb268adbea4cbe56e0156bdd057df88e2436abead0ae625e441aca28197ab29` | 387334 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_009.jpg` |
| `gom_01.jpg` | `0237544126977e61e7b9742b7092d513b2e781006b9b574c9d64ce9ac70ae49d` | 176594 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_01.jpg` |
| `gom_010.jpg` | `18391195fff78b01b7214c274fcefc9be5bee6ebd101eec067d50c883c50cf3c` | 293997 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_010.jpg` |
| `gom_011.jpg` | `edd603f181a410222e2c559c447fe426258ceb210a0d89d7091d0fb8a3021b72` | 391881 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_011.jpg` |
| `gom_012.jpg` | `87582e705722e16c514e0f8921c81dd20f4bb372ce935e996535e2affffd390c` | 427072 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_012.jpg` |
| `gom_013.jpg` | `26f823eda3466fd26bbe39ac482bc165e7260f18ab4dc86d5f025febbfdb95a7` | 248436 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_013.jpg` |
| `gom_014.jpg` | `c63cebb0f092f291b46082c1e2fedaf113b300aca9cdf608bdcfa893e2a56db4` | 391994 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_014.jpg` |
| `gom_015.jpg` | `8a8361bb10c6999b21e5e5a43bfe790cdde3d0cfd31da8feb15ee313570d9f5e` | 334406 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_015.jpg` |
| `gom_016.jpg` | `ce3072de8090c3e1256d4b14caedb63155ad7b4e6d362cd02071046c261d3c96` | 274677 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_016.jpg` |
| `gom_017.jpg` | `72376e562a56b1e2f256fab1f2cd997afc663f9ce181864ca67709dcfba253ac` | 267189 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_017.jpg` |
| `gom_018.jpg` | `1927c992d05134284b5f4c3094d860012660829be57b506448fe196cc937d821` | 206770 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_018.jpg` |
| `gom_019.jpg` | `9dcd7ed85fb0b586f1b6c5a30305491251a9b51517fced654117461d698bfd23` | 128311 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_019.jpg` |
| `gom_02.jpg` | `d8b39fb5367a30fe4ca858c82cdea196331d0dc1a6ecba9a436ed8c82f838089` | 145952 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_02.jpg` |
| `gom_020.jpg` | `cb527da2533bbf48391c99e6fc9e20e5e7b3c30071e77acf96be93ccef7e0100` | 201527 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_020.jpg` |
| `gom_03.jpg` | `2e75d0092eedc8df6c82ac09d194a86d77d852539fdf914f99be2deffa2bb973` | 502809 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_03.jpg` |
| `gom_04.jpg` | `3283920e110247ef66f517ead067c797855bddfd0bf415edebe48bb318c0cd87` | 199160 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/gom_04.jpg` |
| `hl_01_photo.jpg` | `e68fc3d9bf3514b8d4bbdde3006b6a69fa1fb076bcc3667b84114b152bbeb274` | 380975 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_01_photo.jpg` |
| `hl_02_photo.jpg` | `8310b8162ae166c837b8a680493d32d23f5c33f5b11d4aa638285c345837036f` | 314520 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_02_photo.jpg` |
| `hl_03_photo.jpg` | `acb268adbea4cbe56e0156bdd057df88e2436abead0ae625e441aca28197ab29` | 387334 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_03_photo.jpg` |
| `hl_04_photo.jpg` | `edd603f181a410222e2c559c447fe426258ceb210a0d89d7091d0fb8a3021b72` | 391881 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_04_photo.jpg` |
| `hl_05_photo.jpg` | `18391195fff78b01b7214c274fcefc9be5bee6ebd101eec067d50c883c50cf3c` | 293997 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_05_photo.jpg` |
| `hl_06_photo.jpg` | `59ef4f98033e18c33cb287dd3af7e430f06a3b3afa7ba8b64e55e78527d7242b` | 267505 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_06_photo.jpg` |
| `hl_07_photo.jpg` | `124bc953afacf09ca9de82713013eeb42d291308baf1d7c7b794b69ec6a7a867` | 281265 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_07_photo.jpg` |
| `hl_08_drawing_site_plan.jpg` | `bb4af36ded70016f3cb29a476afe193f45bcc53826b769eebbbbebfe53f1171d` | 388998 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_08_drawing_site_plan.jpg` |
| `hl_09_drawing_plan.jpg` | `72376e562a56b1e2f256fab1f2cd997afc663f9ce181864ca67709dcfba253ac` | 267189 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_09_drawing_plan.jpg` |
| `hl_10_drawing_axon.jpg` | `2e75d0092eedc8df6c82ac09d194a86d77d852539fdf914f99be2deffa2bb973` | 502809 | 否 | `/workspace/landscape/2026-10-27/hetu_luoshu_shanghai/hl_10_drawing_axon.jpg` |
| `hetuluoshu_1.jpg` | `d7f122d7e57e30ac363620e726374935f3c002895a977172831945fb523ec09c` | 342775 | 是 | `/workspace/landscape/china-canopy-cases/hetuluoshu_1.jpg` |
| `hetuluoshu_2.jpg` | `0b8a2ab9a91f848d15183332874cea56133805a364c07fd5ed5573304a34cf2b` | 204100 | 是 | `/workspace/landscape/china-canopy-cases/hetuluoshu_2.jpg` |
| `hetuluoshu_3.jpg` | `44b7c6bc01e7315f1412e4cfa55d9e99db7f5801754cc5bbe6070dc3a82adb17` | 260474 | 是 | `/workspace/landscape/china-canopy-cases/hetuluoshu_3.jpg` |
| `hetuluoshu_4.jpg` | `e851e9250bee5ee65dc62e6f0bc2f8e556e1d9c657dac73dc35318659764d522` | 240705 | 是 | `/workspace/landscape/china-canopy-cases/hetuluoshu_4.jpg` |
| `hetuluoshu_5.jpg` | `f71ff7ae9a73b8c30673447c03a13c3a7885d4ea0717be6fab64c149a3666453` | 218554 | 否 | `/workspace/landscape/china-canopy-cases/hetuluoshu_5.jpg` |
| `hetuluoshu_6.jpg` | `0aeeeae08be12805c3ca74d0db6c9d5435fd8613bb7da9477c0816a0947993cf` | 265803 | 否 | `/workspace/landscape/china-canopy-cases/hetuluoshu_6.jpg` |
