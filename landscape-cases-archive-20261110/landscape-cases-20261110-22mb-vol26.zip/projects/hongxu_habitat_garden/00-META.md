# 虹旭生境花园（上海长宁）

- 归档编号：`hongxu_habitat_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch25`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hongxu_habitat_garden_1.jpg` | `e4e9cc7fbd4ec93567d94cb156ef41f3157bbf58bbbd12f3a1a8c8c29e45ee5c` | 913283 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_1.jpg` |
| `hongxu_habitat_garden_10.jpg` | `a03a37ca3aa65a9542e7d6191f2a83457bcc8aa80ba6a45a6c3b7aa84d0b2809` | 991873 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_10.jpg` |
| `hongxu_habitat_garden_2.jpg` | `98acc731e342d79e7f911f46f6c061383713a7a851bed580c81a488131c62957` | 903256 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_2.jpg` |
| `hongxu_habitat_garden_3.jpg` | `a430e47e400ff29b1c76808cf6d8e1bc7bfd7abe37fc189eb4bbaa5282761369` | 480859 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_3.jpg` |
| `hongxu_habitat_garden_4.jpg` | `ba37431c3165e80bb71570f90c5792d32e2c1facb9042aa006c5f52acadd5b21` | 138452 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_4.jpg` |
| `hongxu_habitat_garden_5.jpg` | `529b1df995722bc9b8bda9bfb031f158ade8e4c70bd21a71e61f737c9fab5b20` | 785899 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_5.jpg` |
| `hongxu_habitat_garden_6.jpg` | `5c3cc345edf7d58a53e9e33092bd7e38000c89ea792dbfab1dab651b3f8cc4d5` | 821650 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_6.jpg` |
| `hongxu_habitat_garden_7.jpg` | `39d6d5696476640eaa0aae937dce5226ddf22209c448f4670098d420b09ae2c9` | 809050 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_7.jpg` |
| `hongxu_habitat_garden_8.jpg` | `36624b7cf05289fa836c38f45748a745c77b03056b2ab328643ee24a6c56f7f2` | 842752 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_8.jpg` |
| `hongxu_habitat_garden_9.jpg` | `212da463115627e12eeb91c6353a45a23caa51d785b49ae9dc2ed239549dc37c` | 803238 | 是 | `/workspace/landscape/batch25/hongxu_habitat_garden_9.jpg` |
