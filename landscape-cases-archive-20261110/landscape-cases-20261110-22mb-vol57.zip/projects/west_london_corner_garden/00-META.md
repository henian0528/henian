# 西伦敦转角花园（Stefano Marinaz）

- 归档编号：`west_london_corner_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `west_london_corner_garden_1.jpg` | `3ed7fab1ed431cffeeb88e8522989a53b84b2eb10718c2519d3dfc209dd33b1a` | 1344060 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_1.jpg` |
| `west_london_corner_garden_2.jpg` | `947da05bdb74a99cad77b8ecce2e8d36baf62a72687721df648a09a6d32e418e` | 1781253 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_2.jpg` |
| `west_london_corner_garden_3.jpg` | `c9f8eaf0df2a5e8ab9d2665c3ede219243c4d19d22a92e2bc63dd2071fb4e12b` | 1622832 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_3.jpg` |
| `west_london_corner_garden_4.jpg` | `bf360dddef7d1827c861e8e56dd93ee49d2626a5b61fecc8560b6899da6f78f4` | 1758149 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_4.jpg` |
| `west_london_corner_garden_5.jpg` | `ae2c89c98eea094290c01b40144c6a20ff3a1e343ee07ea3bf48332402dc756b` | 1599120 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_5.jpg` |
| `west_london_corner_garden_6.jpg` | `1e00ce4432642892ac6dc25969b947202a4b65d5c63d51bceeb13f53f879c42d` | 1544480 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_6.jpg` |
| `west_london_corner_garden_7.jpg` | `903d8777867680667fe3028f78d8c8f4906ad8684e110b40a32291931ecb2b39` | 1538313 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_7.jpg` |
| `west_london_corner_garden_8.jpg` | `58451f61fae2c6a24929ac9f14c14dea9a1eda222ced5b46a2688a0977a1abaa` | 1490100 | 是 | `/workspace/landscape/batch33/west_london_corner_garden_8.jpg` |
