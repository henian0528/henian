# 浪花园（深圳，大小景观）

- 归档编号：`wave_garden_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch16`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wave_garden_sz_1.jpg` | `b71b6dd7a8733a810d4f9d570931f36c470fb79f25b2e77faa63cb7d0ded9efd` | 702994 | 是 | `/workspace/landscape/batch16/wave_garden_sz_1.jpg` |
| `wave_garden_sz_10.jpg` | `31c1ca577acd6ee910a7ce2c3ec7a40a5f3c4d7f4efad280537209d2ca6205e4` | 640668 | 是 | `/workspace/landscape/batch16/wave_garden_sz_10.jpg` |
| `wave_garden_sz_2.jpg` | `d0a5b7b78e719b5258667981991d7edeeba005abf0bcd33fb687e92f9724b18e` | 866449 | 是 | `/workspace/landscape/batch16/wave_garden_sz_2.jpg` |
| `wave_garden_sz_3.jpg` | `cdaaac1006085ac2a87173a817fbaef8c56dd59151856d0877fdce93980306dc` | 766503 | 是 | `/workspace/landscape/batch16/wave_garden_sz_3.jpg` |
| `wave_garden_sz_4.jpg` | `1788274a1f9a3085e96f32a01b9fc317f855876cb3f28b25d7c7b89c1f8f8aa8` | 944699 | 是 | `/workspace/landscape/batch16/wave_garden_sz_4.jpg` |
| `wave_garden_sz_5.jpg` | `53e09133a8d873c824493f84e95c914603fd3cbd898e9f99d86132862857764e` | 851992 | 是 | `/workspace/landscape/batch16/wave_garden_sz_5.jpg` |
| `wave_garden_sz_6.jpg` | `a768c9598bcdeeb7f48e87a1165306ed52c6674552654392fd7ca5ff632e74d9` | 648296 | 是 | `/workspace/landscape/batch16/wave_garden_sz_6.jpg` |
| `wave_garden_sz_7.jpg` | `cacb9c62337e532a896453ce0ba134c6bc9c5f7914c80b04d5521df5821e3bdf` | 587766 | 是 | `/workspace/landscape/batch16/wave_garden_sz_7.jpg` |
| `wave_garden_sz_8.jpg` | `da60fe4e512c4302413dc095fc3fadedafe1b49ed9887185b7abe06106d48a09` | 788730 | 是 | `/workspace/landscape/batch16/wave_garden_sz_8.jpg` |
| `wave_garden_sz_9.jpg` | `d5ad093005034e05372e47a2a1d113efe468c836e7ca30a45921e9b998db5723` | 150295 | 是 | `/workspace/landscape/batch16/wave_garden_sz_9.jpg` |
