# Diagonal House（东京，永山祐子/荻野）

- 归档编号：`diagonal_house_tokyo`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `diagonal_house_tokyo_1.jpg` | `a560cb106ec51731d6727d0c1cbf34f92132235085676b2188382363e0d7193e` | 113945 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_1.jpg` |
| `diagonal_house_tokyo_2.jpg` | `366307262d1b3c79d0f2bcd1aa5de08135d294cdb3d16bac6ce3a605c646c394` | 410313 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_2.jpg` |
| `diagonal_house_tokyo_3.jpg` | `4bd287695185c3c6172f586ebe77d484d1675e3911680880f2b6ed98cf02335c` | 329179 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_3.jpg` |
| `diagonal_house_tokyo_4.jpg` | `a15e6237069c1f44ebddac162e0be4dfe88113f00356fe97df4221a53f196f73` | 306938 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_4.jpg` |
| `diagonal_house_tokyo_5.jpg` | `4f73b93102a35786f4d807dcbd43348d59f2acccf2a172d6dbcdd37ae7fdda07` | 218883 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_5.jpg` |
| `diagonal_house_tokyo_6.jpg` | `49e51190109a6ba58a1bcc36e8d6291d157e80cec0763bd6bb7921467742bdae` | 168859 | 是 | `/workspace/landscape/batch23/diagonal_house_tokyo_6.jpg` |
