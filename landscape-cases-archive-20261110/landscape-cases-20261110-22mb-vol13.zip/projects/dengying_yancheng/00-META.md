# 登瀛小筑（盐城铜马广场，MUDO）

- 归档编号：`dengying_yancheng`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：20
- 在 bot 附件库中匹配到的配图：10 / 20（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-10
  - 出处说明：日期目录 2026-11-10（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-10/dengying_yancheng`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `dy_01_photo_aerial.jpg` | `21100ff78e72f4d15c4e22769e4338658adc13b0c1252673931a49df35dfe089` | 678658 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_01_photo_aerial.jpg` |
| `dy_02_photo_square.jpg` | `e85def9e002a98589e2211bc56236449ff01765d923aa9c83e69748abe323094` | 688118 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_02_photo_square.jpg` |
| `dy_03_photo_night.jpg` | `dab45f74b95d7250b721682e95f9f1ca537a59e26c5764fb7262b2b0007e6541` | 642306 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_03_photo_night.jpg` |
| `dy_04_photo_grayspace.jpg` | `3e65e3013ce20d7b9b28d5cca8430f99347f69f0882548b3fec4ab2994c45f8b` | 851883 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_04_photo_grayspace.jpg` |
| `dy_05_photo_facade.jpg` | `257d017892b49ce131b2faff897ef11414b0089f97f72054ef061f7f442e7b25` | 594668 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_05_photo_facade.jpg` |
| `dy_06_photo_eaves.jpg` | `6c3225e684865075dc8c1f5a7e89b6f63d5089427f21680b9cc114af6b9cdf57` | 499163 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_06_photo_eaves.jpg` |
| `dy_07_photo_rooftop.jpg` | `d9d54a8ec4cff64ffd94040b756e80f44c435b6fcde0c1ebaf07c850248700e7` | 1045373 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_07_photo_rooftop.jpg` |
| `dy_08_drawing_siteplan.jpg` | `7d92dfa09970b6dfae5b95722b598ff34cf8653facdd99890ff851965c127d4d` | 217475 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_08_drawing_siteplan.jpg` |
| `dy_09_drawing_plan.jpg` | `8c7aeb00f2fbbb12bb0ee1b3184d6233343ebd7d4cf349c2aba46ab68d561c8e` | 322280 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_09_drawing_plan.jpg` |
| `dy_10_drawing_section.jpg` | `8fef1b2c7871fb16d96a42bc6d773046e2151a18954e5f972700135ee054dc66` | 260333 | 否 | `/workspace/landscape/2026-11-10/dengying_yancheng/dy_10_drawing_section.jpg` |
| `dengying_station_yancheng_1.jpg` | `28073291a014c8ea592e9ee68ab5defe1bd85dd5db4fb1d5677cafe1967f1f38` | 639886 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_1.jpg` |
| `dengying_station_yancheng_10.jpg` | `d5051dd32eb3b273e59d254e9f89dfa4fefbeaee02c5bd94182182340f3b0bcb` | 239949 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_10.jpg` |
| `dengying_station_yancheng_2.jpg` | `d5453a83841e5a09be49162f3482e10eab57f7eabb7b18d8120cc1f853c176d5` | 620454 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_2.jpg` |
| `dengying_station_yancheng_3.jpg` | `809900f156b55dced1498fa7306bda90e9b6c5ebdc49c92304b7818ccdb7ebff` | 708452 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_3.jpg` |
| `dengying_station_yancheng_4.jpg` | `3588881aca8b5272c40d86dac29ce499c17b5a7d7cc881f48a142117856ce860` | 515230 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_4.jpg` |
| `dengying_station_yancheng_5.jpg` | `99241ffa15a86288ef538fdc9de03e91b54cf933af2d81be4233c105f25ee13f` | 687445 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_5.jpg` |
| `dengying_station_yancheng_6.jpg` | `027e213cf81a39d37c3a987b978ca0a0a08cca0caec12eeba3d12fc933550b9e` | 851995 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_6.jpg` |
| `dengying_station_yancheng_7.jpg` | `f6855d0ba5d680807137edc85e97deb227d33c1a7b37d4da6c8459fd0ac77329` | 757599 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_7.jpg` |
| `dengying_station_yancheng_8.jpg` | `ffae0f093a2c334615882d887a81fda7ad79046cccd5e8bd1c5b78e880972783` | 548088 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_8.jpg` |
| `dengying_station_yancheng_9.jpg` | `7caaa39852ae6274a264cbba8600669814a758ed645c0cb11b2fa146c292bb05` | 334367 | 是 | `/workspace/landscape/batch8/dengying_station_yancheng_9.jpg` |
