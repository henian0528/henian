# Domus Living Houthavens（阿姆斯特丹）

- 归档编号：`domus_houthavens_courtyard`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `domus_houthavens_courtyard_1.jpg` | `e8bfe1e5eb9d27a98e71852be5e4460da5b43c3e227a0008560d19c60e50ef1c` | 1507276 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_1.jpg` |
| `domus_houthavens_courtyard_10.jpg` | `a5d59bc097ac5d0117f278311aac524f1ac0c6a56f27fce066d7477ba52ac8ff` | 123257 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_10.jpg` |
| `domus_houthavens_courtyard_2.jpg` | `f12f18311f147eb3443430eb98eeda30182576ebac4648764895a8330bf0e6d4` | 571914 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_2.jpg` |
| `domus_houthavens_courtyard_3.jpg` | `32499b14c1a998f54a97cefd1ef03795b95b4bb6c2d0cc1b01ff4555b1369bee` | 738519 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_3.jpg` |
| `domus_houthavens_courtyard_4.jpg` | `d7224de4800cd361a44f579e74fc529b7dbec804b302b656f785b2c31d51fc46` | 528281 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_4.jpg` |
| `domus_houthavens_courtyard_5.jpg` | `e952cb900003f83f63aaaab73e68b6730161d0c7156a450875c15054c52cd1ce` | 538047 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_5.jpg` |
| `domus_houthavens_courtyard_6.jpg` | `eb139f86702368ded699db5b80f1decc98d515d983b1338774de992a94cf705f` | 655468 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_6.jpg` |
| `domus_houthavens_courtyard_7.jpg` | `433564a00518d846ec5ccc98c883df44ec8a79eed98ce1b2fd44a5df2c852be7` | 627682 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_7.jpg` |
| `domus_houthavens_courtyard_8.jpg` | `f918d65eff50e876524e27ccef46fec86ab1f2fab5afadcf9fad90f0a25717b8` | 518820 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_8.jpg` |
| `domus_houthavens_courtyard_9.jpg` | `188f31ec2443a74afbd05689143935ff5573fc92d24fb9230ba707052001fdca` | 270392 | 是 | `/workspace/landscape/batch33/domus_houthavens_courtyard_9.jpg` |
