# 麻布台之云（white3）

- 归档编号：`azabudai_cloud`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：4
- 在 bot 附件库中匹配到的配图：4 / 4（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white3）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white3`
  - 注：来源 china-canopy-cases/white3
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `azabudai_cloud_1.jpg` | `7fea809b02ee0ee364cd014bb4724e7f2db76251bd996a7f59f8217e4603875e` | 121474 | 是 | `/workspace/landscape/china-canopy-cases/white3/azabudai_cloud_1.jpg` |
| `azabudai_cloud_2.jpg` | `b427b034ba23caf59df0083c1307bb7e8a85a5b02846bf233d49535102a81c0e` | 102383 | 是 | `/workspace/landscape/china-canopy-cases/white3/azabudai_cloud_2.jpg` |
| `azabudai_cloud_3.jpg` | `7237d46cc75915dc10829b466cf25f079df0b53f03a257db68355c958ad7f32c` | 140590 | 是 | `/workspace/landscape/china-canopy-cases/white3/azabudai_cloud_3.jpg` |
| `azabudai_cloud_4.jpg` | `71ce0ce9a09157c348a2223a2e27d9adeb3d0531ba3c7376a4f873df835f251a` | 1155948 | 是 | `/workspace/landscape/china-canopy-cases/white3/azabudai_cloud_4.jpg` |
