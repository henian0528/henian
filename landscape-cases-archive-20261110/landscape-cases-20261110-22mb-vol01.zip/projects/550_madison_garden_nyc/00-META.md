# 550 Madison Avenue Garden（纽约，Snøhetta）

- 归档编号：`550_madison_garden_nyc`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch31`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `550_madison_garden_nyc_1.jpg` | `0249887f8c53b5c30fa1bb9d883263ba0621b1bb162134e6afa12f478d4881df` | 820015 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_1.jpg` |
| `550_madison_garden_nyc_10.jpg` | `cb30b9871d0b9072558fe3b3cfd5dbd0e1b2e7649e7b6ea60eaf0362635d0df2` | 456071 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_10.jpg` |
| `550_madison_garden_nyc_2.jpg` | `503d9bc4676ee8c25c090f30edcc169c492ad6526c8355fb0721aef14c4cc2f0` | 773962 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_2.jpg` |
| `550_madison_garden_nyc_3.jpg` | `86334730538049ff1debb9dac845bf0bd790a989dbc9965efa4389147c1bcd47` | 582112 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_3.jpg` |
| `550_madison_garden_nyc_4.jpg` | `fc2d8fce781f20f91317328acf223a1fbcc69964c36967a769acdd7533081a53` | 859070 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_4.jpg` |
| `550_madison_garden_nyc_5.jpg` | `1c6f23ff1ebd9d406ff882e4909cc3e8756e7a3adfd7e3d4caebce26fee50a4e` | 662521 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_5.jpg` |
| `550_madison_garden_nyc_6.jpg` | `ce646c13cd4af3a627097da44b2687486761ce4425b387a8bd6bca6973f882b9` | 768983 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_6.jpg` |
| `550_madison_garden_nyc_7.jpg` | `2bd98594e1da5822f6086483d0f7e76ac9e6531206a69c643285671b188e4eb1` | 696824 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_7.jpg` |
| `550_madison_garden_nyc_8.jpg` | `34ea42a7e643f747e0265c5914af9884d090bf78e25b9411d8eae6707cd337be` | 925918 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_8.jpg` |
| `550_madison_garden_nyc_9.jpg` | `9d42e4bf9cfb7f2c28dfcd81885285ccf28dd736d84f5f7761145fae7b70900c` | 806927 | 是 | `/workspace/landscape/batch31/550_madison_garden_nyc_9.jpg` |
