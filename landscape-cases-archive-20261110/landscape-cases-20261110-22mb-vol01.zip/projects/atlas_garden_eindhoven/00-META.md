# Atlas Garden（埃因霍温）

- 归档编号：`atlas_garden_eindhoven`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch22`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `atlas_garden_eindhoven_1.jpg` | `07e90c6716ad6c48a72949a64c2087eb243db907a1556cefd6110a9b56889e6b` | 639714 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_1.jpg` |
| `atlas_garden_eindhoven_2.jpg` | `5809859a030152c26eea61418c607ddcd46b5960c6f9e868137db941fa3e6fe0` | 709817 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_2.jpg` |
| `atlas_garden_eindhoven_3.jpg` | `ba784df4b3c9d08c3a6e1331bd394bea71dbf8a832c6f8585364e7e2be247370` | 556738 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_3.jpg` |
| `atlas_garden_eindhoven_4.jpg` | `86d95ca5e7f240e01fbac10979fbcca11fe2fe52054d37772047316110114f52` | 606293 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_4.jpg` |
| `atlas_garden_eindhoven_5.jpg` | `e6be8df0b28a8ac924ef1b1b282980e8c93e4f6dc6e05d7bd7310aafe8b31f35` | 602915 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_5.jpg` |
| `atlas_garden_eindhoven_6.jpg` | `71140488c1514e73e0ccc1313ef1c99110074f982ee97541a2bda0fc18d97c2c` | 605203 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_6.jpg` |
| `atlas_garden_eindhoven_7.jpg` | `1f82d0049993403405efe42bd93dfa70eb6683895300d03858f1bec9c4dcfa90` | 456442 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_7.jpg` |
| `atlas_garden_eindhoven_8.jpg` | `e856fc41a0d098a3460c8fca69d5a804dd032881b78f1d24fb137bb643855606` | 686889 | 是 | `/workspace/landscape/batch22/atlas_garden_eindhoven_8.jpg` |
