# Ankaret 白色棚架屋顶花园（Guise）

- 归档编号：`ankaret_trellis_roof`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch17`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ankaret_trellis_roof_1.jpg` | `01a629b68ca9dda52c1a9bbbd61589344778a3380e0ee9b520acfd19511debb5` | 232241 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_1.jpg` |
| `ankaret_trellis_roof_10.jpg` | `18c10d1d1ad41011872131476a79ba0b741c0998ec4cbcfc7e570d7965ed54c9` | 45270 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_10.jpg` |
| `ankaret_trellis_roof_2.jpg` | `193dee0103ea20306cf8d4a7f833936bc1656d85f29d97eece83747377e0a796` | 85274 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_2.jpg` |
| `ankaret_trellis_roof_3.jpg` | `6c0d885ff10ff5237aa887035cfc3d05569de38edc7126427f6997f924fdc0c7` | 105331 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_3.jpg` |
| `ankaret_trellis_roof_4.jpg` | `a6d678874e7558f868974192d1980e4a6190a3d866fe3811cfa5fdfb6e1af4bd` | 231169 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_4.jpg` |
| `ankaret_trellis_roof_5.jpg` | `ebc26d425b08934e704ac6fb746383079fd9a5954422e0369f46363700c9f725` | 262758 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_5.jpg` |
| `ankaret_trellis_roof_6.jpg` | `97ba6917f433e709e007af3707ebc2bf8aa372c41db74abf1e46ea07cd27668e` | 243809 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_6.jpg` |
| `ankaret_trellis_roof_7.jpg` | `4f3bd6c244273d87894e640f221d09efcdaff9b58b4452369ca175b1ac0d46d5` | 236240 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_7.jpg` |
| `ankaret_trellis_roof_8.jpg` | `489b29ed787fab995d28760aa754f2e698af5c85a89a41c1d114de0fd737d1c8` | 48359 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_8.jpg` |
| `ankaret_trellis_roof_9.jpg` | `a5e302eb6d5bb5223ea32ac9e71e70c807b729ad4ce597ff334390fcac37ea6b` | 40373 | 是 | `/workspace/landscape/batch17/ankaret_trellis_roof_9.jpg` |
