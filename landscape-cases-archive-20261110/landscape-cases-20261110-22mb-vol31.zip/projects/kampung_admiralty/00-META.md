# Kampung Admiralty（variety 早期批次）

- 归档编号：`kampung_admiralty`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `kampung_admiralty_1.jpg` | `b98e83a8bdf7a9216c768fd2186f00acb120f7a8f2fc11f303a3f84176b3ab11` | 1337119 | 是 | `/workspace/landscape/variety/kampung_admiralty_1.jpg` |
| `kampung_admiralty_2.jpg` | `db7b47bbbeec38e1f04d4a114a15ba0e5cc547af63f82e2e0850ce3a486c35dc` | 1268990 | 是 | `/workspace/landscape/variety/kampung_admiralty_2.jpg` |
| `kampung_admiralty_3.jpg` | `a63f4a5f22de48d9170f8424e7c75f4287cbb550c4980fe44bb2a843b2186b9a` | 1045563 | 是 | `/workspace/landscape/variety/kampung_admiralty_3.jpg` |
| `kampung_admiralty_4.jpg` | `7ee5a571c96759d1e5a3a547c5ac867c7149296714fb84fabaa8a5b7632003bd` | 1098437 | 否 | `/workspace/landscape/variety/kampung_admiralty_4.jpg` |
| `kampung_admiralty_5.jpg` | `443448656387b7ef20a3c7baeaa1234a62eed963a8b9e4f35c6dd53656bd3769` | 1182051 | 否 | `/workspace/landscape/variety/kampung_admiralty_5.jpg` |
| `kampung_admiralty_6.jpg` | `931d695881deab5c764879d9d72b0f060917242bc4ff190375acfeedc3b653c9` | 167110 | 是 | `/workspace/landscape/variety/kampung_admiralty_6.jpg` |
