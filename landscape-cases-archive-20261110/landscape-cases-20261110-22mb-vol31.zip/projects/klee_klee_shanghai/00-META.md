# klee klee & friends 店铺景观（上海，或然）

- 归档编号：`klee_klee_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `klee_klee_shanghai_1.jpg` | `b87d262f9ad482ad0de0abd0a4e5a25ddc702bde6527109e6de475ffb001bde1` | 225122 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_1.jpg` |
| `klee_klee_shanghai_10.jpg` | `cd78548734d0781c8f0294bbfa90b48bb7acc5c1ca418ab76223c2b069f7c1ed` | 105058 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_10.jpg` |
| `klee_klee_shanghai_2.jpg` | `a786152a49604e42577347042abe8c7b9a5a9e8b413dece21a27ba111f03790f` | 473518 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_2.jpg` |
| `klee_klee_shanghai_3.jpg` | `9dea8ea98c18d60bfb8a5196de6f165724cf7a1308b6d410e0a4d502cbe603b2` | 313449 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_3.jpg` |
| `klee_klee_shanghai_4.jpg` | `46a36874eb65de611694fe7294456cf0d87e15499c8e143a29016a6acddc63f1` | 583247 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_4.jpg` |
| `klee_klee_shanghai_5.jpg` | `369dfe37b184e6a5997c8e7777cf159d914fe45635423e06ffa6564d8c59beb9` | 580791 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_5.jpg` |
| `klee_klee_shanghai_6.jpg` | `2aa076fda2afcbf2fbb24b65fe93747340f13215ea9648c5c2c2d4f6b7722eac` | 258351 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_6.jpg` |
| `klee_klee_shanghai_7.jpg` | `e9cd3a3bc1c15985b51cfd219b97eeafb2e92133cebd6d2d6b4d0245f0214ee8` | 560884 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_7.jpg` |
| `klee_klee_shanghai_8.jpg` | `e8a46423501acd068e944049222c0fba3f0ec8017f6283fbc4339184aa4d485c` | 534892 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_8.jpg` |
| `klee_klee_shanghai_9.jpg` | `b737e004d8212ded26e2aca8dd913ecd2b332153cb8a34485f32ad3c2a2a6685` | 308070 | 是 | `/workspace/landscape/batch27/klee_klee_shanghai_9.jpg` |
