# 金鸡湖 1 号驿站（苏州）

- 归档编号：`jinji_no1_suzhou`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-08
  - 出处说明：日期目录 2026-11-08（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-08/jinji_no1_suzhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `jj_01_photo_morning.jpg` | `6c50fa210ded16f74e6e73b5fbaeab93dbe6f238f44e1cd1835aba03ead30a16` | 604812 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_01_photo_morning.jpg` |
| `jj_02_photo_lakeside.jpg` | `9c64b5af879da4dd1fe83fdfe3afbbcf50507a521ebe78a0362bf13ef1a12714` | 615601 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_02_photo_lakeside.jpg` |
| `jj_03_photo_eaves.jpg` | `cd51da617e474aae33d3fdd41a777f0df610f190bef4b5cc63ede49e114dad23` | 518811 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_03_photo_eaves.jpg` |
| `jj_04_photo_north_corridor.jpg` | `8e4305147bba6cc5b7a1196f39d4a4e2d1199ab51a07f035652e5f502a7c6123` | 493122 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_04_photo_north_corridor.jpg` |
| `jj_05_photo_woods.jpg` | `38ae52a11e68efad4cd22c156c5de67cbc47d09a74e89920b096bea01e2f449e` | 771062 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_05_photo_woods.jpg` |
| `jj_06_photo_grayspace.jpg` | `8ee9921f93470a26d61f42ab241034799adac3ae919b7c26606da8782b8e827c` | 481784 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_06_photo_grayspace.jpg` |
| `jj_07_photo_night.jpg` | `426dff5377e5d0539959cc33df92f3e144cbfc9684c556d8a69c56d53d78fec8` | 276242 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_07_photo_night.jpg` |
| `jj_08_drawing_siteplan.jpg` | `4e219c43887a9053efcd825cb75946f8cbc9522586f3a8effbb459c428050174` | 816224 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_08_drawing_siteplan.jpg` |
| `jj_09_drawing_plan_2f.jpg` | `29f24e14edc2c404c1fe109c4ad07ec5bd07ff96d4c2236455d393e133ea1c21` | 831068 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_09_drawing_plan_2f.jpg` |
| `jj_10_drawing_section.jpg` | `2f305beeb5d58479f0d2f40b71829d67ea16742c7b248d3e057a5c7a845ee16b` | 176998 | 否 | `/workspace/landscape/2026-11-08/jinji_no1_suzhou/jj_10_drawing_section.jpg` |
