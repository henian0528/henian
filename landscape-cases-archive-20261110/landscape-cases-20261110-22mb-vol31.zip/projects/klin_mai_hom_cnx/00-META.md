# Klin Mai Hom（清迈，batch15）

- 归档编号：`klin_mai_hom_cnx`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch15`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `klin_mai_hom_cnx_1.jpg` | `bee4c1ee0e428f91072551ff18d02b40914756fc71bac4052e6d8661e282d905` | 263969 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_1.jpg` |
| `klin_mai_hom_cnx_10.jpg` | `d4f8a3aae382f9eeaa985bd7a1096ac640809c4b7a05c36f246ece6bd1cf81b8` | 404889 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_10.jpg` |
| `klin_mai_hom_cnx_2.jpg` | `b7481ce42c904c192b7370b25126ff20c6fa02711288c1f8944c9367cb0378df` | 311802 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_2.jpg` |
| `klin_mai_hom_cnx_3.jpg` | `8741946fee6466217fe0a0c3c97b057821fcd03e92d499ee70098c2c19374809` | 254953 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_3.jpg` |
| `klin_mai_hom_cnx_4.jpg` | `c8cb950a31030de3ddd25625373af9d3789b3ac966813ac09be704ac210386e1` | 309976 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_4.jpg` |
| `klin_mai_hom_cnx_5.jpg` | `dcb6b83cc2a3c3e7a6018c88e92c47f58004abfb8535dd1910b8d990619af480` | 637483 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_5.jpg` |
| `klin_mai_hom_cnx_6.jpg` | `107a1010603dc78fdc65df2bdb6ecac4cf9402fc3832ebac79e33e604075a9ed` | 280738 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_6.jpg` |
| `klin_mai_hom_cnx_7.jpg` | `174f10a0148c6ccaaa5a383f9fdd340b3100374344cd29a3774e8d20598d9ac6` | 231949 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_7.jpg` |
| `klin_mai_hom_cnx_8.jpg` | `1a40ae17a76c15058cb6c5914dcbee63c5bfd795dfc37760efebd3bb2b93121f` | 500896 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_8.jpg` |
| `klin_mai_hom_cnx_9.jpg` | `fe320a93af81c1e8a61e13d8d85ff1a924df516232e56dec38f373e8d3f55192` | 220288 | 是 | `/workspace/landscape/batch15/klin_mai_hom_cnx_9.jpg` |
