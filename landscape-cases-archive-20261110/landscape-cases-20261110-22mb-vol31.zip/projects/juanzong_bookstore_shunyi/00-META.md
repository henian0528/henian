# 卷宗书店（顺义，batch24）

- 归档编号：`juanzong_bookstore_shunyi`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：0 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch24`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `juanzong_bookstore_shunyi_1.jpg` | `415d88905b5babd659d9eb8153b8579de4b65669f2f390ec13839a4565c7efed` | 248205 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_1.jpg` |
| `juanzong_bookstore_shunyi_2.jpg` | `107a707745fb283e0a437394c19e8ec997409dc626acad01254f0fe8acc6e2a7` | 252182 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_2.jpg` |
| `juanzong_bookstore_shunyi_3.jpg` | `f953e7a0795a7ffd0529ec9062e5880cbd97614fb899de07dcf21c3d1ef13b14` | 229182 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_3.jpg` |
| `juanzong_bookstore_shunyi_4.jpg` | `f69dc6858f7459373696b6d3660b7fabbddefeb30a702b954eff7c419bf09985` | 310047 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_4.jpg` |
| `juanzong_bookstore_shunyi_5.jpg` | `fc5ae2622e52a01804b63aa19c748fc2bb173fd4d205c745003f680ec9f74812` | 155802 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_5.jpg` |
| `juanzong_bookstore_shunyi_6.jpg` | `476c6374cf4e47686a0066fe84d77c06096b031927cb2c23f2b6e86141248950` | 54546 | 否 | `/workspace/landscape/batch24/juanzong_bookstore_shunyi_6.jpg` |
