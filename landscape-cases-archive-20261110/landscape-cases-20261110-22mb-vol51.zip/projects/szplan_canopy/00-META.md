# 深圳规划相关棚（white3）

- 归档编号：`szplan_canopy`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white3）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white3`
  - 注：来源 china-canopy-cases/white3
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `szplan_canopy_1.jpg` | `f6b174c9bc90d6c153210ff40ed01778d71b07e758b7528f0093e4c59dac0c4f` | 678541 | 是 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_1.jpg` |
| `szplan_canopy_2.jpg` | `658e6042439878497e5cdcbe5f3f9e1b5f6d210d9860dd010548909918ac26c1` | 576938 | 是 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_2.jpg` |
| `szplan_canopy_3.jpg` | `8de75ac966017d86bcc1a3c2d6cba11fcea71da0b31d41c0733d1469ae43e3dd` | 520159 | 否 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_3.jpg` |
| `szplan_canopy_4.jpg` | `f7a384524eda9ff00d9377180ce8d995f0a7e69d5e2884db25138fc78936e545` | 637996 | 否 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_4.jpg` |
| `szplan_canopy_5.jpg` | `cfcaccf760058616359c35fb99b8ca3450b5deac0e27d728634c18ba20cda0bf` | 515722 | 是 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_5.jpg` |
| `szplan_canopy_6.jpg` | `bc178f8b76c7b31a3479cfa25e5accb5ef9b7f565b8df1dc412450b9b03e598e` | 422302 | 是 | `/workspace/landscape/china-canopy-cases/white3/szplan_canopy_6.jpg` |
