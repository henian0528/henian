# 漩花园（深圳，大小营造）

- 归档编号：`swirl_garden_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch17`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `swirl_garden_sz_1.jpg` | `5dd64e937112dc47260dd28693a438c58d7a747337121e6804d9b429c4a52fce` | 650172 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_1.jpg` |
| `swirl_garden_sz_2.jpg` | `51c324c9ada20e82df4eb0e04e4d74dd951ec4015785364259b0469ae5128612` | 655342 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_2.jpg` |
| `swirl_garden_sz_3.jpg` | `d0fa3a339a9c83531edef507fcc7675611204ce85f42de05dcd739777d68db59` | 838831 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_3.jpg` |
| `swirl_garden_sz_4.jpg` | `15515f3262a172cbc5daf406f0ed050cde3487b225f64694918cbe1aa81c3e50` | 574637 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_4.jpg` |
| `swirl_garden_sz_5.jpg` | `0df889a246e54ef9482613d7cc6f451793d74755128d13d1e8afc8b2258f8cb9` | 696239 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_5.jpg` |
| `swirl_garden_sz_6.jpg` | `5bc44be74e5e7f0b03b81e41259f99be6c43520d4ad7a69b93e8daf6e0574689` | 653909 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_6.jpg` |
| `swirl_garden_sz_7.jpg` | `5dbc18494f488bec22f3bb08c9d42b8b3092adc75ec820219483422d416bb523` | 856989 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_7.jpg` |
| `swirl_garden_sz_8.jpg` | `734145d9b1ac32f9172c4e2fe130abe7750e2f1e5a4f33210e7ce836f8c5f296` | 684572 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_8.jpg` |
| `swirl_garden_sz_9.jpg` | `13e8872507207f9b180b5576c716579e4281e675e4d1108dd6bc9436fa253f2f` | 721685 | 是 | `/workspace/landscape/batch17/swirl_garden_sz_9.jpg` |
