# 广州大金钟公园·月影亭

- 归档编号：`moonlight_pavilion`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-12
  - 出处说明：群聊工作日日推（目录与来源页为大金钟公园月影亭；原文未从对话记录回读）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-12`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `moonlight_pavilion_1_inside_oculus.jpg` | `42580b79d8d4f46403f0120d1b43f197b576c0c03f139ba40b2a98162425271b` | 503201 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_1_inside_oculus.jpg` |
| `moonlight_pavilion_2_dusk_reflection.jpg` | `444018096efea14c46023be1df43e4b526d05030450a78e779afb30bad1cebb0` | 461605 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_2_dusk_reflection.jpg` |
| `moonlight_pavilion_3_ring_in_planting.jpg` | `c3c6f335e900f26b2ef218e7c706295912bf48ac6be36f9756fc5cf2e6489a6d` | 166728 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_3_ring_in_planting.jpg` |
| `moonlight_pavilion_4_corridor.jpg` | `471e2eed195b43d94cae9bcb74515717602e21823dc6988e9ef23b6101f2434c` | 187312 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_4_corridor.jpg` |
| `moonlight_pavilion_5_thin_roof_columns.jpg` | `96887f6be65da48dcf3dd050092969695c61835f260363debbfe72bf9a6352a5` | 416506 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_5_thin_roof_columns.jpg` |
| `moonlight_pavilion_6_park_aerial.jpg` | `802ee248b4f7f9022746bae5f3ee4c3714b2f3006611210ee5a075e574cae83d` | 273592 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_6_park_aerial.jpg` |
| `moonlight_pavilion_7_site_strategy_diagram.jpg` | `61509b2cc66a5a817315f933dc5659005dd91f3d9cc1e2b6dbde3182b78cdb91` | 449249 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_7_site_strategy_diagram.jpg` |
| `moonlight_pavilion_8_circulation_plan.jpg` | `ea43612a52830d809120e81996533776b96456f856f89ef87ccb3aa625307a82` | 160708 | 是 | `/workspace/landscape/2026-10-12/moonlight_pavilion_8_circulation_plan.jpg` |
