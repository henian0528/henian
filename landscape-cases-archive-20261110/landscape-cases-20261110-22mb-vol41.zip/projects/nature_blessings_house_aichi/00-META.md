# 受到自然祝福的住宅（爱知，TSC）

- 归档编号：`nature_blessings_house_aichi`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch19`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `nature_blessings_house_aichi_1.jpg` | `e30d956de8cc12eeec077e8be182efb4c73bc6c9ca4c611f65ae0df8bbbe20c6` | 189636 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_1.jpg` |
| `nature_blessings_house_aichi_10.jpg` | `9135d0b74b29f7e86fafc622fc841897451f0324cc482b6ea71a16793faf340c` | 88304 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_10.jpg` |
| `nature_blessings_house_aichi_2.jpg` | `623217ed8fe4afc4538b74e033c151d88d549145c286bbc691fc3b3f81c0a9e4` | 271424 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_2.jpg` |
| `nature_blessings_house_aichi_3.jpg` | `34264abca4cbe5950174af7a258a50f896cebe770243e2b7b875d37fe93dfb68` | 189125 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_3.jpg` |
| `nature_blessings_house_aichi_4.jpg` | `71f6df3eb675ac8b85f0c4fa090ddb75249ec4d33acb5886b44c459a53f73e00` | 394793 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_4.jpg` |
| `nature_blessings_house_aichi_5.jpg` | `7afcbf81aa465c2185c5f99c244836787264097664a90122fc73d88a250699d6` | 294916 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_5.jpg` |
| `nature_blessings_house_aichi_6.jpg` | `3ac2682475d94b969485f984c1b988ef8d4370d7c3e0a7c088ae1ff52f74a96b` | 325031 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_6.jpg` |
| `nature_blessings_house_aichi_7.jpg` | `8199c5cde635163e8c58e9a72d43d7fefba62c1bf4e6babcc488a8ddd0f5e00d` | 293672 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_7.jpg` |
| `nature_blessings_house_aichi_8.jpg` | `70673e2019dd91bcfbb7daa3797b4ce15b6b928bfa975fa88927911478f42231` | 258916 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_8.jpg` |
| `nature_blessings_house_aichi_9.jpg` | `bdd6aeedc51d479c1da49f0d19102326b7d85a7a401f1052c8bea0a166e25b8f` | 187172 | 是 | `/workspace/landscape/batch19/nature_blessings_house_aichi_9.jpg` |
