# 直岛 SANAA（white2）

- 归档编号：`naoshima_sanaa`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `naoshima_sanaa_1.jpg` | `07b1c291446dbb1abbf882633ab25a6d2e57d70fdca6697c94f4050784a585c2` | 113202 | 是 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_1.jpg` |
| `naoshima_sanaa_2.jpg` | `7ad140cd7d8c5075bd1d856aea44b7945ddbefe263ce5c3053c7f08e7f0bafa0` | 228230 | 是 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_2.jpg` |
| `naoshima_sanaa_3.jpg` | `55b95369f7b88180d08ac4ad14edff2e635d0db47db48c3ff64ddee59a4940fa` | 224860 | 是 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_3.jpg` |
| `naoshima_sanaa_4.jpg` | `291881dc3d7c4f96840440cfd17e1313749d97f971cb21a4aba4541d994c7adb` | 338418 | 是 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_4.jpg` |
| `naoshima_sanaa_5.jpg` | `0bb0f42010f527008695aa5e910227d363fef7c94d5d7540c87a1bd54480236f` | 230775 | 否 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_5.jpg` |
| `naoshima_sanaa_6.jpg` | `f2748f60fae4b5f3abb3bc03955fe37bdd9bf7916c80c6654baa4d29983b0ac0` | 203624 | 否 | `/workspace/landscape/china-canopy-cases/white2/naoshima_sanaa_6.jpg` |
