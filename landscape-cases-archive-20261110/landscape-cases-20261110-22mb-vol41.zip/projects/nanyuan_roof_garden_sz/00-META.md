# 南园绿云屋顶共建花园（深圳，一十一建筑）

- 归档编号：`nanyuan_roof_garden_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch13`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `nanyuan_roof_garden_sz_1.jpg` | `3ea3124398b27c7cdec66128741ce7f67005970e13eb959171f69ec09eba8862` | 631730 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_1.jpg` |
| `nanyuan_roof_garden_sz_10.jpg` | `f9732985a516bae0c755075e152a92733e41db21f559f77ceb9d2fe12954f553` | 361057 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_10.jpg` |
| `nanyuan_roof_garden_sz_2.jpg` | `531017ed72e75ad9af34a0621be1e24caaca9aad7f73222b5efbcc9cc5113374` | 505674 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_2.jpg` |
| `nanyuan_roof_garden_sz_3.jpg` | `dbc147eb2a45aefeee6b8a1c1273eee4d9cdb9675d8c6c49c0f6c6cc295e5409` | 336108 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_3.jpg` |
| `nanyuan_roof_garden_sz_4.jpg` | `11d7298c2ada101a41662ac20b1c082d3c728800beef60869922cc295633dabb` | 374001 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_4.jpg` |
| `nanyuan_roof_garden_sz_5.jpg` | `03122a97937651d15ac007a168ed11c7967cd84062f5ebf257205eac64c72fc2` | 468144 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_5.jpg` |
| `nanyuan_roof_garden_sz_6.jpg` | `0edc959bcefab52a0d5698281ead3e4f122045e11b376db956a4543ee9b4a223` | 546025 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_6.jpg` |
| `nanyuan_roof_garden_sz_7.jpg` | `a7dc741754e67f4cbc0248e6151b5b8a0da96712107da73f39c3ec65eac5827d` | 615003 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_7.jpg` |
| `nanyuan_roof_garden_sz_8.jpg` | `f59c7702882302412d8e3ceba7d2a88f09a30c505403fb72e9c8bb76cd41ed3b` | 762672 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_8.jpg` |
| `nanyuan_roof_garden_sz_9.jpg` | `37b734298d512f023854ebc2dd9e2eb7275d3ba98aad5389a2a6aee3ff836441` | 570482 | 是 | `/workspace/landscape/batch13/nanyuan_roof_garden_sz_9.jpg` |
