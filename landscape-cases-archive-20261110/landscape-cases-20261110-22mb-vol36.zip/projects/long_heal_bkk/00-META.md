# LongiPark Long Heal（曼谷，Shma，临时）

- 归档编号：`long_heal_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch14`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `long_heal_bkk_1.jpg` | `8e571df97cec72dc1234dee75ab8d82d834cfa07b9d0beb43c0cf7c0c355359f` | 634265 | 是 | `/workspace/landscape/batch14/long_heal_bkk_1.jpg` |
| `long_heal_bkk_10.jpg` | `f45ac84acd6f1e5f2b406e7c522122375195d16c67b5716fc4e7f82931e9b90e` | 244135 | 是 | `/workspace/landscape/batch14/long_heal_bkk_10.jpg` |
| `long_heal_bkk_2.jpg` | `f99b0122d041aca66ad9451008dce3c87d0553067edfcc68d60df2d2ba10ff01` | 510608 | 是 | `/workspace/landscape/batch14/long_heal_bkk_2.jpg` |
| `long_heal_bkk_3.jpg` | `9600e3829d0de957eb9ec26e3ef8a3c6d739f3958fe6be8d940c04b8040850b4` | 621413 | 是 | `/workspace/landscape/batch14/long_heal_bkk_3.jpg` |
| `long_heal_bkk_4.jpg` | `b8a743b617ca71c2d80f399bce27d1ddf2d58ae40f1dc8c95c83cf80a939981b` | 916650 | 是 | `/workspace/landscape/batch14/long_heal_bkk_4.jpg` |
| `long_heal_bkk_5.jpg` | `70e698b3366e1e98fd7f7d51204d34dbd3999fc203ee55a29a2bc1ed49d53b5e` | 652341 | 是 | `/workspace/landscape/batch14/long_heal_bkk_5.jpg` |
| `long_heal_bkk_6.jpg` | `58907030d31db942c9edca83cbebfc9950f97993d55bf033746d6220a8cb237d` | 806910 | 是 | `/workspace/landscape/batch14/long_heal_bkk_6.jpg` |
| `long_heal_bkk_7.jpg` | `004dfead22b165c28503e4a7ce2e75a5a39d70eb2427b58fe9aa2b71e6558de2` | 871932 | 是 | `/workspace/landscape/batch14/long_heal_bkk_7.jpg` |
| `long_heal_bkk_8.jpg` | `5025bde8c201628f103b273a2286cf8a374ae165bc860f83d8e45da56f7acc8a` | 955795 | 是 | `/workspace/landscape/batch14/long_heal_bkk_8.jpg` |
| `long_heal_bkk_9.jpg` | `581e9b7b6f196092218146c4f0302230f6a066674805ffe79762826df0f86f70` | 544291 | 是 | `/workspace/landscape/batch14/long_heal_bkk_9.jpg` |
