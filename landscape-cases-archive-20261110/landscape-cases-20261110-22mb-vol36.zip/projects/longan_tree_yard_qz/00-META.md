# 龙眼树院（batch18）

- 归档编号：`longan_tree_yard_qz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `longan_tree_yard_qz_1.jpg` | `406dfe62df02aa4a66d26b58a7873786864a117a0e3ee4a2e457b6a911d05fea` | 1029952 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_1.jpg` |
| `longan_tree_yard_qz_10.jpg` | `191a94b284b93a5dcde2671c59d15025005d101bd6dc72ffb3787fc011d55e80` | 488192 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_10.jpg` |
| `longan_tree_yard_qz_2.jpg` | `3770342da934079f13d903842557739a17fac14e1abad134a18971fbac957069` | 790977 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_2.jpg` |
| `longan_tree_yard_qz_3.jpg` | `f9dc6c106540edcc9c825e51ad4ba6e24b579783fb78f94e9851826ca00bdfba` | 889476 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_3.jpg` |
| `longan_tree_yard_qz_4.jpg` | `314c294e7b4480bb6e259d5a36a0a9ce4403351edb9f39dd732beb56a5dbf574` | 656552 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_4.jpg` |
| `longan_tree_yard_qz_5.jpg` | `e5600eea56530af6db4837d22920a6135f4a6524de904ac0ba09801c96bb65bf` | 596804 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_5.jpg` |
| `longan_tree_yard_qz_6.jpg` | `8357ac070d63e25325de2e27dd4c1d4956c93be54c4ccfe58b11e6dcfaee5bea` | 772730 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_6.jpg` |
| `longan_tree_yard_qz_7.jpg` | `7618cf1d9224b74c4988e01be265ee354b9d8bc5858fe6783c04901575fdbdd9` | 966481 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_7.jpg` |
| `longan_tree_yard_qz_8.jpg` | `c9d7ea8b975036450d175069fd5618d7361852a2e172de7de57c7b56936a712f` | 723712 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_8.jpg` |
| `longan_tree_yard_qz_9.jpg` | `828c6b6dec646ecd83457404c994dc79628ca8885ef286c5e7faed88bda016e2` | 469890 | 是 | `/workspace/landscape/batch18/longan_tree_yard_qz_9.jpg` |
