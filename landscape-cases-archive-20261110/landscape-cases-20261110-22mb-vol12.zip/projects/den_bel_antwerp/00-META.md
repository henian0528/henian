# Den Bel（期刊记因图片拦截未发）

- 归档编号：`den_bel_antwerp`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：5 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`（后续补发，见 texts/original-*）
  - 本地来源：`/workspace/landscape/batch31`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `den_bel_antwerp_1.jpg` | `6eeb6ab6dcb7b1f1454820ce0c22d0ae1759deaf7d03f5d890bbe0732c376546` | 363438 | 是 | `/workspace/landscape/batch31/den_bel_antwerp_1.jpg` |
| `den_bel_antwerp_2.jpg` | `dfac5122f3b8b60e3eff9a798dce0a08fff21516a9d76e4d1c3d34de01f2888e` | 781569 | 是 | `/workspace/landscape/batch31/den_bel_antwerp_2.jpg` |
| `den_bel_antwerp_3.jpg` | `63f02395a08e696eeceb7f81b0ca97dd1eeb3d6919455ab3783adb4cba2f6f5f` | 641977 | 是 | `/workspace/landscape/batch31/den_bel_antwerp_3.jpg` |
| `den_bel_antwerp_4.jpg` | `caeb81687e4be2660ac59744d322b9d255d9ab8a0c3b2b85d38e79d797ddb66d` | 1121382 | 是 | `/workspace/landscape/batch31/den_bel_antwerp_4.jpg` |
| `den_bel_antwerp_5.jpg` | `9a2e581cf171c16e82afc4f7085d58f6270876bc3c27233b55d7baa73e521882` | 347898 | 是 | `/workspace/landscape/batch31/den_bel_antwerp_5.jpg` |
