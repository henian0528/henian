# 上海甲板花园（VIA 维亚景观）

- 归档编号：`deck`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：群聊工作日日推（目录与来源页为甲板花园；原文未从对话记录回读）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-15`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `deck_10_axon_diagram.jpg` | `6c54c52f80108ccd05a768f2c2b23b02f5f4f9064a959306b3884ec2dce6efe0` | 251923 | 是 | `/workspace/landscape/2026-10-15/deck_10_axon_diagram.jpg` |
| `deck_1_overhead.jpg` | `056d7eac6158ce44918ce3540fec82a7592b65df029d999981dbad254b144a23` | 354864 | 是 | `/workspace/landscape/2026-10-15/deck_1_overhead.jpg` |
| `deck_2_raised_deck.jpg` | `58dc1fe138ddfd62c53c7905caf4128651f4ac2532190b141b421351009449a6` | 344556 | 是 | `/workspace/landscape/2026-10-15/deck_2_raised_deck.jpg` |
| `deck_3_steps_ramp.jpg` | `f88e02ae1a26d712ae2fcf3a1d497cf007295b892f41c7a2fa9ce438d1d362c8` | 331804 | 是 | `/workspace/landscape/2026-10-15/deck_3_steps_ramp.jpg` |
| `deck_4_lawn_and_deck.jpg` | `9d0d1ae58a2dbc456d086f65a7c9ed98e1f5c19b054b87224336302b1d8217f9` | 359075 | 是 | `/workspace/landscape/2026-10-15/deck_4_lawn_and_deck.jpg` |
| `deck_5_ginkgo_entrance.jpg` | `01ff2f43df775bae3e56fa5508c4ec2c123748be0690b41f83969502a13f1ee4` | 343248 | 是 | `/workspace/landscape/2026-10-15/deck_5_ginkgo_entrance.jpg` |
| `deck_6_upper_platform.jpg` | `38edcfc440dd65fdc289600a4193b45338ce7c7af73b160782e9f4b45b4bca0e` | 335217 | 是 | `/workspace/landscape/2026-10-15/deck_6_upper_platform.jpg` |
| `deck_7_riverside_seats.jpg` | `3ce93f52e6cb71a321937c3991cd08deada19a41098e96acc98eaa5166dbf970` | 410586 | 是 | `/workspace/landscape/2026-10-15/deck_7_riverside_seats.jpg` |
| `deck_8_dusk.jpg` | `72222869862cdaa57f3ae65d9b71ebb38559acd0fa15129d31b6058d8d7d277b` | 312947 | 是 | `/workspace/landscape/2026-10-15/deck_8_dusk.jpg` |
| `deck_9_plan.jpg` | `fea546df3917a8781b6ecb91be16a6532b20a0232480c1fadb8ff35b1dad04a0` | 147670 | 是 | `/workspace/landscape/2026-10-15/deck_9_plan.jpg` |
