# 杭州龙井茶亭（上埠头村）

- 归档编号：`longjing_tea_pavilion`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：32
- 在 bot 附件库中匹配到的配图：0 / 32（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-25
  - 出处说明：日期目录 2026-10-25（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-25/longjing_tea_pavilion`
  - 注：项目子目录精选图
  - 本记录配图文件数：32

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `_raw_00_longjing-tea-pavilion-02.jpg` | `a0def4e44941cf4d541f621287d0aaa102e897caa3307f31866253ed6830f8f5` | 298158 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_00_longjing-tea-pavilion-02.jpg` |
| `_raw_01_longjing-tea-pavilion-01.jpg` | `f015774d7dec0292a35726f23999e357351d9a416bd9cd5dcf650dd9fdc4d588` | 382958 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_01_longjing-tea-pavilion-01.jpg` |
| `_raw_02_longjing-tea-pavilion-04.jpg` | `78f32e33d1fd2d66968be1c366cd081c579ac1d84d04e9fa6bd081f760f9690d` | 637931 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_02_longjing-tea-pavilion-04.jpg` |
| `_raw_03_longjing-tea-pavilion-03.jpg` | `128286d56e26050d37d8dc0c0cae99c4ec016f10e9280839ea2da12ae1b86ccb` | 558150 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_03_longjing-tea-pavilion-03.jpg` |
| `_raw_04_longjing-tea-pavilion-05.jpg` | `5fd557c8529fe33e9b288bc20cc4ffed8e1e239c325cf84fb90da8dd48948544` | 239484 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_04_longjing-tea-pavilion-05.jpg` |
| `_raw_05_longjing-tea-pavilion-07.jpg` | `d825f93eaf5855a11f44eaca67acd46ab464b4cd5c34865ad2756c5e11f2579a` | 214925 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_05_longjing-tea-pavilion-07.jpg` |
| `_raw_06_longjing-tea-pavilion-06.jpg` | `9d11fc16aa76a717e0a09a5e2176202db39bf986b97696000a348d2d75c64b87` | 285135 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_06_longjing-tea-pavilion-06.jpg` |
| `_raw_07_longjing-tea-pavilion-08.jpg` | `2ff8da0e19ce88583cb14421bf91031b87f069620b808df136fe13e8aacf0199` | 478578 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_07_longjing-tea-pavilion-08.jpg` |
| `_raw_08_longjing-tea-pavilion-12.jpg` | `5b6d959bd0c694fdd9dee7a7845d3e39714d3382bfe79743076762034edf4868` | 385184 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_08_longjing-tea-pavilion-12.jpg` |
| `_raw_09_longjing-tea-pavilion-10.jpg` | `d8aeffd99d512ed64d14165a358327244b901f64f6c8534aba1ea5411bc2db61` | 784982 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_09_longjing-tea-pavilion-10.jpg` |
| `_raw_10_longjing-tea-pavilion-11.jpg` | `98eadc619155cbb489c8d205223c483ba08430850ea98c6eab54db457b5955c2` | 641360 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_10_longjing-tea-pavilion-11.jpg` |
| `_raw_11_longjing-tea-pavilion-16.jpg` | `80eddaf3941364cb08cf9a3d098425f85cd6bd803876cefdd7de96998cb6b0a5` | 157362 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_11_longjing-tea-pavilion-16.jpg` |
| `_raw_12_longjing-tea-pavilion-09.jpg` | `48b43133edc70194a96b24bec4390ac9e18834155f34b9597adfc99ca9ec1871` | 546650 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_12_longjing-tea-pavilion-09.jpg` |
| `_raw_13_longjing-tea-pavilion-13.jpg` | `498afc01de280de41336d798313f39a37c9acefcffbca9818bbc1992a2dc09a1` | 394936 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_13_longjing-tea-pavilion-13.jpg` |
| `_raw_extra_14.jpg` | `0e1973e252f6f5cfc5d38551841e73781e07a90a4b59fa6ebc45f051b211e615` | 329642 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_14.jpg` |
| `_raw_extra_15.jpg` | `5f52f9beda09f8e9ddc0e4088f614b6f11cb0827b95a8684b135eb7b5915c853` | 453859 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_15.jpg` |
| `_raw_extra_17.jpg` | `0e7af2ac8710f4f6736b051c22af14e5786fc98234616a58c92e908cd41abd98` | 199680 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_17.jpg` |
| `_raw_extra_18.jpg` | `1e5ae30c808906f9e11009738de3262f987e060b801cebe3be1862392924ef84` | 384419 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_18.jpg` |
| `_raw_extra_19.jpg` | `d2e11ac569e02220020521a009ededba1879e950368f6074fdf4cdc04b50e499` | 276557 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_19.jpg` |
| `_raw_extra_20.jpg` | `e8825256a529b34c4838f3c5f388b52718c18b9655bbeeb3fdab78045a1d553a` | 488431 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_20.jpg` |
| `_raw_extra_21.jpg` | `6132b2934f01860849cfff6c614fa37319a8ac5cc2c0081dee4af3fc7bcf28d3` | 457850 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_21.jpg` |
| `_raw_extra_22.jpg` | `935cec1c14a5a4efbee04c52e591e72a23bc87535b116dae79d95f9a8807369f` | 548240 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/_raw_extra_22.jpg` |
| `lj_01_photo_aerial_fuchun.jpg` | `f015774d7dec0292a35726f23999e357351d9a416bd9cd5dcf650dd9fdc4d588` | 382958 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_01_photo_aerial_fuchun.jpg` |
| `lj_02_photo_east_elevation.jpg` | `2ff8da0e19ce88583cb14421bf91031b87f069620b808df136fe13e8aacf0199` | 478578 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_02_photo_east_elevation.jpg` |
| `lj_03_photo_aerial_tea_fields.jpg` | `48b43133edc70194a96b24bec4390ac9e18834155f34b9597adfc99ca9ec1871` | 546650 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_03_photo_aerial_tea_fields.jpg` |
| `lj_04_photo_west_facade.jpg` | `498afc01de280de41336d798313f39a37c9acefcffbca9818bbc1992a2dc09a1` | 394936 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_04_photo_west_facade.jpg` |
| `lj_05_photo_inside_east_roof.jpg` | `5f52f9beda09f8e9ddc0e4088f614b6f11cb0827b95a8684b135eb7b5915c853` | 453859 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_05_photo_inside_east_roof.jpg` |
| `lj_06_photo_view_fuchun.jpg` | `1e5ae30c808906f9e11009738de3262f987e060b801cebe3be1862392924ef84` | 384419 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_06_photo_view_fuchun.jpg` |
| `lj_07_drawing_village_master_plan.jpg` | `5fd557c8529fe33e9b288bc20cc4ffed8e1e239c325cf84fb90da8dd48948544` | 239484 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_07_drawing_village_master_plan.jpg` |
| `lj_08_drawing_plan.jpg` | `5b6d959bd0c694fdd9dee7a7845d3e39714d3382bfe79743076762034edf4868` | 385184 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_08_drawing_plan.jpg` |
| `lj_09_drawing_section_1-1.jpg` | `80eddaf3941364cb08cf9a3d098425f85cd6bd803876cefdd7de96998cb6b0a5` | 157362 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_09_drawing_section_1-1.jpg` |
| `lj_10_drawing_section_2-2.jpg` | `0e7af2ac8710f4f6736b051c22af14e5786fc98234616a58c92e908cd41abd98` | 199680 | 否 | `/workspace/landscape/2026-10-25/longjing_tea_pavilion/lj_10_drawing_section_2-2.jpg` |
