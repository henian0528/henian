# 龙南候车亭（江西龙南高铁东站）

- 归档编号：`longnan_waiting`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-11
  - 出处说明：日期目录 2026-11-11（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-11/longnan_waiting`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ln_01_photo_aerial_north.jpg` | `b95c25405196e5f730f48e0da46454ec4a11150958f03a0fff87600c72dea845` | 931469 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_01_photo_aerial_north.jpg` |
| `ln_02_photo_context_station.jpg` | `0d3c04d9c7297dc8dc2d6f2e761d66036589eff2e476539de2d59c6a099e8b3c` | 909704 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_02_photo_context_station.jpg` |
| `ln_03_photo_appearance.jpg` | `4f523c5f612f00d40bab187ec423aa0263c224f13b92aed5f11b9953098c8bcf` | 568860 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_03_photo_appearance.jpg` |
| `ln_04_photo_patio.jpg` | `e731c0e09a7224bc0f867bb75d1db994432442dc6c4133128326ee6b20ecb2cb` | 553411 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_04_photo_patio.jpg` |
| `ln_05_photo_south.jpg` | `4c24a4b99c38b928cb4ed88624908b8e2ae6e8c429cbb94402b0a790e34bf55b` | 457091 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_05_photo_south.jpg` |
| `ln_06_photo_node.jpg` | `eaa97b5048c61e0f00e13dc4e69d4c322b11c190f16e944b2edcb7ae44b5800c` | 542428 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_06_photo_node.jpg` |
| `ln_07_photo_patio_skylight.jpg` | `58721ca3b0b4fc6e29b0c523690089c7b8878614939939e6958838ae1bd7c882` | 356907 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_07_photo_patio_skylight.jpg` |
| `ln_08_drawing_siteplan.jpg` | `55f475d3b8cb00ea4eed542663298667e33e1922d2cc101647eec3279447ecc6` | 268593 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_08_drawing_siteplan.jpg` |
| `ln_09_drawing_unit.jpg` | `da3887ebf735d59bc3b824a0d25de915e77bc40a743c8e0de573e9d7e54a9a89` | 106211 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_09_drawing_unit.jpg` |
| `ln_10_drawing_assembly.jpg` | `0d07149938a801097beb30d328ccfd74dd13b108afc60bfdb281de297b608ebd` | 78577 | 否 | `/workspace/landscape/2026-11-11/longnan_waiting/ln_10_drawing_assembly.jpg` |
