# 佩雷公园 Paley Park（variety 早期批次）

- 归档编号：`paley_park`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：4 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `paley_park_1.jpg` | `11d7d4c5d6812da8ab87e922737b6799c7a1f4b2813ed81c3b88e00a5a208210` | 1424578 | 是 | `/workspace/landscape/variety/paley_park_1.jpg` |
| `paley_park_2.jpg` | `d24246b5ef5881264a676aa13715fe1e41715a843ab4fa08b8bb7cd8e9562c23` | 836103 | 是 | `/workspace/landscape/variety/paley_park_2.jpg` |
| `paley_park_3.jpg` | `b29d3bf29eba806fb0cdb44d295e996a8a888dc8e66cf8a895a417297cf26db0` | 995761 | 是 | `/workspace/landscape/variety/paley_park_3.jpg` |
| `paley_park_4.jpg` | `a57481aa7f0d107d3a0a2c0999adf08f84acd2056a36ee1ce585639d5cff932c` | 775154 | 是 | `/workspace/landscape/variety/paley_park_4.jpg` |
| `paley_park_5.jpg` | `956a8f638ebccde065de942e34dfd44091b518bfde715ce9de643581c359d4c5` | 812257 | 否 | `/workspace/landscape/variety/paley_park_5.jpg` |
