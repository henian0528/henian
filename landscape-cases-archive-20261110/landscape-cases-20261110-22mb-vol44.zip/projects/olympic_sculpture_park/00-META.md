# 西雅图奥林匹克雕塑公园 / Olympic Sculpture Park

- 归档编号：`olympic_sculpture_park`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：16
- 在 bot 附件库中匹配到的配图：12 / 16（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07
  - 出处说明：群聊工作日日推（期刊：已推送奥林匹克雕塑公园）
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/2026-10-07`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：16

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `olympic_sculpture_park_1.jpg` | `446a9ba3b295449149c4b4ccc729a47280275a64b26cf55d5fd5d54c51284dca` | 769912 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_1.jpg` |
| `olympic_sculpture_park_2.jpg` | `7c11e4b38cb314dcad4c56f9d5c9b00763b5a0d53f65a32361c0ca7b89c6638d` | 674109 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_2.jpg` |
| `olympic_sculpture_park_3.jpg` | `6aeaec998322fcc0e0621b31666159a0660dfb1597192b48bc58d9e2db4c2055` | 290329 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_3.jpg` |
| `olympic_sculpture_park_4.jpg` | `7f0bc46b85cc5ac2460ca1ff1aa780122cf1724b1450c283112dd3935b67d6ee` | 622129 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_4.jpg` |
| `olympic_sculpture_park_5.jpg` | `0c48aee0abdf0d1c3c0503205527618b745bc9787f9d041120b63d6759095b2c` | 310634 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_5.jpg` |
| `olympic_sculpture_park_6.jpg` | `ea75da690583be750a023186f59af91f7d15ecd850a743c68c7c1ff43bef9ec6` | 477535 | 是 | `/workspace/landscape/2026-10-07/olympic_sculpture_park_6.jpg` |
| `osp_1.jpg` | `7f0bc46b85cc5ac2460ca1ff1aa780122cf1724b1450c283112dd3935b67d6ee` | 622129 | 是 | `/workspace/landscape/2026-10-07/osp_1.jpg` |
| `osp_10.jpg` | `560857e19e2e9eb9f7c9e6b062ab6098b3a6a2bf695ec0ba36f8c53308c78c15` | 418356 | 否 | `/workspace/landscape/2026-10-07/osp_10.jpg` |
| `osp_2.jpg` | `446a9ba3b295449149c4b4ccc729a47280275a64b26cf55d5fd5d54c51284dca` | 769912 | 是 | `/workspace/landscape/2026-10-07/osp_2.jpg` |
| `osp_3.jpg` | `19fd2a5169ffc7a1db6c114550cdf449470dd425e983d073540439b39d9a22cd` | 860297 | 否 | `/workspace/landscape/2026-10-07/osp_3.jpg` |
| `osp_4.jpg` | `46355a0ea2ae747384bb1909b144ac3ea0ee9537fa774ebbca0ab1a7ca692bbd` | 1007129 | 否 | `/workspace/landscape/2026-10-07/osp_4.jpg` |
| `osp_5.jpg` | `9b31f862e64d2e51f0a00f1b6b241258d58cb3df5ba4b467a67c275e3c7e33b1` | 2542368 | 否 | `/workspace/landscape/2026-10-07/osp_5.jpg` |
| `osp_6.jpg` | `ea75da690583be750a023186f59af91f7d15ecd850a743c68c7c1ff43bef9ec6` | 477535 | 是 | `/workspace/landscape/2026-10-07/osp_6.jpg` |
| `osp_7.jpg` | `6aeaec998322fcc0e0621b31666159a0660dfb1597192b48bc58d9e2db4c2055` | 290329 | 是 | `/workspace/landscape/2026-10-07/osp_7.jpg` |
| `osp_8.jpg` | `0c48aee0abdf0d1c3c0503205527618b745bc9787f9d041120b63d6759095b2c` | 310634 | 是 | `/workspace/landscape/2026-10-07/osp_8.jpg` |
| `osp_9.jpg` | `7c11e4b38cb314dcad4c56f9d5c9b00763b5a0d53f65a32361c0ca7b89c6638d` | 674109 | 是 | `/workspace/landscape/2026-10-07/osp_9.jpg` |
