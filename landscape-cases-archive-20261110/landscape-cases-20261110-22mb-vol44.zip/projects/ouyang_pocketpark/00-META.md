# 欧阳路祥德路转角口袋公园（山水秀）

- 归档编号：`ouyang_pocketpark`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：14
- 在 bot 附件库中匹配到的配图：10 / 14（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch10`
  - 本记录配图文件数：14

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ouyang_pocketpark_1.jpg` | `4ff416e6e58da131161ce037be46e52802da4d64d7cbf2b9e9667ad207528f3e` | 205138 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_1.jpg` |
| `ouyang_pocketpark_10.jpg` | `1b4f6760723960bb188340156dc29374e314869cedbcb0c1d33e2e46f1ffe0d0` | 144296 | 否 | `/workspace/landscape/batch10/ouyang_pocketpark_10.jpg` |
| `ouyang_pocketpark_11.jpg` | `f2f158cc51b10142cf191ed6fbd157cc45c477906dec19fb686b6bdcd7e15a52` | 105879 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_11.jpg` |
| `ouyang_pocketpark_12.jpg` | `88d74f9099c8cab3b0ecf6ad4e867d4459a7b5464d5d77c0a6926cbaf0a514a5` | 82551 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_12.jpg` |
| `ouyang_pocketpark_13.jpg` | `cf45fe6ac81bd797ec4f82a5146859c1889467c241816dda7a770425e2f0ab0d` | 45309 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_13.jpg` |
| `ouyang_pocketpark_14.jpg` | `da0212ee1c158e7be34cb86399798e3d3cd14db8ba192f61535ca846bac09359` | 87039 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_14.jpg` |
| `ouyang_pocketpark_2.jpg` | `14c2eaf00df935c3eae00f4939ad3e032a6d6e00385452c70bb3de4a118ab7f3` | 193975 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_2.jpg` |
| `ouyang_pocketpark_3.jpg` | `6cfb287688ca772b516501d5c014e247200e0002da8d65ad1a3306065884b913` | 258608 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_3.jpg` |
| `ouyang_pocketpark_4.jpg` | `184184123a978269191cfc86ed354f116887fbff148f6b6bb4f2aca0108a8335` | 253552 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_4.jpg` |
| `ouyang_pocketpark_5.jpg` | `c6ef8d76852413cac60b0f1176df236ee07d71a97ca12cc9d0f10c191429ea59` | 324598 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_5.jpg` |
| `ouyang_pocketpark_6.jpg` | `a8f6b50ccefb824e4154d20ccdb01a8a897064939b2dff2c4e7cc2b076f1fe71` | 330037 | 是 | `/workspace/landscape/batch10/ouyang_pocketpark_6.jpg` |
| `ouyang_pocketpark_7.jpg` | `324bb035a0df940f04ab759f316305b01a33a86b809f63f5b155c30f8c3ce96c` | 197174 | 否 | `/workspace/landscape/batch10/ouyang_pocketpark_7.jpg` |
| `ouyang_pocketpark_8.jpg` | `07efe6f6713bfb0e38f736bc8d5bc99b549dc7a88ae4cfccc8072b8e410aa33e` | 272923 | 否 | `/workspace/landscape/batch10/ouyang_pocketpark_8.jpg` |
| `ouyang_pocketpark_9.jpg` | `85a15c510eb0dbfa2b3f78d7689ca142216a1ffac5967ccef3fc7cf4d9202b9e` | 308566 | 否 | `/workspace/landscape/batch10/ouyang_pocketpark_9.jpg` |
