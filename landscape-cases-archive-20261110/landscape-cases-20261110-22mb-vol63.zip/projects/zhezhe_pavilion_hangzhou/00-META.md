# 运河褶褶亭

- 归档编号：`zhezhe_pavilion_hangzhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zhezhe_pavilion_hangzhou_1.jpg` | `93792e4b31e76a8ab77cf97409077d89cb83df141ee587a89f39d9045fde4f36` | 263452 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_1.jpg` |
| `zhezhe_pavilion_hangzhou_10.jpg` | `133a920b56f58d32acc606231c6ef48ecdf0aea1bc5ff4c0d6f69bc4e1935edc` | 317679 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_10.jpg` |
| `zhezhe_pavilion_hangzhou_2.jpg` | `b83caa013fb206c0c798db9900881ca3b491ba45c9e40da775495665ac5585cb` | 251637 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_2.jpg` |
| `zhezhe_pavilion_hangzhou_3.jpg` | `0dd008ab0bce32f8e19a5379c2d1adb1a80124061eed484c1ed96c71ee6934f2` | 175948 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_3.jpg` |
| `zhezhe_pavilion_hangzhou_4.jpg` | `db46a9432eef68fabb8f5ec234c55d5c993a676c6e14c631dad2cf40c8b9c724` | 162745 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_4.jpg` |
| `zhezhe_pavilion_hangzhou_5.jpg` | `8c32f0ebece28d3f06aba196527c5467768b778cbb544ccaeb3578707dd427ac` | 209669 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_5.jpg` |
| `zhezhe_pavilion_hangzhou_6.jpg` | `bee90cb7da54ecd709361b2351a0ac047f58b8982f98b389d6268ae16dade2bc` | 305774 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_6.jpg` |
| `zhezhe_pavilion_hangzhou_7.jpg` | `b60f2a31abd77e92c5ae95a5e1059673e4e45bc3d34a988355030a9c926c887f` | 249121 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_7.jpg` |
| `zhezhe_pavilion_hangzhou_8.jpg` | `3ff13908d99ab6e46a50a1b56268d706d2a57dcaadbfcfda51125b7e3e71afb4` | 181528 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_8.jpg` |
| `zhezhe_pavilion_hangzhou_9.jpg` | `04367a69e2b62f1e3116870386f82564e199fdd194667d363c0e94c0070b8242` | 171028 | 是 | `/workspace/landscape/batch8/zhezhe_pavilion_hangzhou_9.jpg` |
