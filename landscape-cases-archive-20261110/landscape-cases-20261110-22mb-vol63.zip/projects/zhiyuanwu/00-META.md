# 知园坞相关遮阳案例（china-canopy）

- 归档编号：`zhiyuanwu`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·国内折板/伞状遮阳及棚架案例（目录 china-canopy-cases；期刊有「答应找国内类似 Superkilen 案例」）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases`
  - 注：来源 china-canopy-cases
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zhiyuanwu_1.jpg` | `f8084cec7171b4aa1b0ebea5ca10eb8934299273b204ab3c7a9d97d92d3e056d` | 192268 | 是 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_1.jpg` |
| `zhiyuanwu_2.jpg` | `245d62a6385f0d397f6539d460be080cf820d1a758f1006358980eec65cbfa1f` | 1037214 | 是 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_2.jpg` |
| `zhiyuanwu_3.jpg` | `d59ab396478af4536a1fca966abe19a08eb8c7c22f6110dd032206cec9dae6d3` | 666325 | 否 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_3.jpg` |
| `zhiyuanwu_4.jpg` | `bb45b0443cfd90063c7056a733a444932d83fdab6bc7f881462a24f82da7d5a2` | 283199 | 是 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_4.jpg` |
| `zhiyuanwu_5.jpg` | `97e3f874c32d8afeb6a98dcbcc572a4e359f631ef7b325746bf9e869805f1d2c` | 716870 | 否 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_5.jpg` |
| `zhiyuanwu_6.jpg` | `b0d1baec1f0f7705eab4473bd76d65188fcf6f6f88bdfdeee4979f493190e637` | 351000 | 是 | `/workspace/landscape/china-canopy-cases/zhiyuanwu_6.jpg` |
