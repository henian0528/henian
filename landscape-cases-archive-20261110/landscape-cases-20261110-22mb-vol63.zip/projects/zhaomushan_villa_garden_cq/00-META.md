# 照母山天玺别墅南岑（重庆，木守）

- 归档编号：`zhaomushan_villa_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch19`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zhaomushan_villa_garden_cq_1.jpg` | `d8289dece94b7b0f0821017cfa864bce1c6e9aa6a7bf898385c41568a310f5fc` | 601227 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_1.jpg` |
| `zhaomushan_villa_garden_cq_10.jpg` | `5fb72c82b0596f3e7e26866ed3edecb46524cbf754f9fc846396999fe2e57ba8` | 517444 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_10.jpg` |
| `zhaomushan_villa_garden_cq_2.jpg` | `e00e9c94a492e7b5ddda695a0e48d8fc095df16b78c3363907f1f1e073b28dfe` | 489530 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_2.jpg` |
| `zhaomushan_villa_garden_cq_3.jpg` | `77e8743c0a127737bf460b1f5d9fb4e9e8f2918ee3f033d3e53b382217c032d1` | 613600 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_3.jpg` |
| `zhaomushan_villa_garden_cq_4.jpg` | `afd9bf7ec4a52a11ccb2953fcc57a129f9cc08ca1061e9b7e0c5b22d43bb8ae0` | 500995 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_4.jpg` |
| `zhaomushan_villa_garden_cq_5.jpg` | `899dc1b924bdf8a9bf00532f8299454d0db7713a9156818c75996b05941de063` | 458883 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_5.jpg` |
| `zhaomushan_villa_garden_cq_6.jpg` | `9d8a3a47551cfe78fe5fa32725b40a2fa5818c663f43915689c16a06adb04bfc` | 529247 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_6.jpg` |
| `zhaomushan_villa_garden_cq_7.jpg` | `6f84987bba36d29b72695bbec64bf0ff5facccbf7a96e48787e9a738bddb5efc` | 504687 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_7.jpg` |
| `zhaomushan_villa_garden_cq_8.jpg` | `f153daf0ce670343ead1284d7095e65458b1a765fdc6fc45a49a60fe82b41731` | 373494 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_8.jpg` |
| `zhaomushan_villa_garden_cq_9.jpg` | `a09a008228c894f388092da054b6fdb6442ac24b968eb17590675b78414c907c` | 590659 | 是 | `/workspace/landscape/batch19/zhaomushan_villa_garden_cq_9.jpg` |
