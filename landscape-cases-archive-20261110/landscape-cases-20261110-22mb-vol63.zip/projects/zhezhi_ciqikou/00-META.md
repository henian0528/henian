# 折纸轻亭（重庆磁器口东门旅游服务驿站）

- 归档编号：`zhezhi_ciqikou`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-01
  - 出处说明：日期目录 2026-11-01（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-01/zhezhi_ciqikou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zz_01_photo_aerial.jpg` | `2e363e12ae65a376fda6eda56ca9ff917232213c2c1e5dc16de83529dee1a194` | 648892 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_01_photo_aerial.jpg` |
| `zz_02_photo.jpg` | `f9bd7fbc070cd8aaa59b54aa8f4dc6092ede50fe12746f2ca0c5986b7042568f` | 932732 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_02_photo.jpg` |
| `zz_03_photo.jpg` | `0accbf31dd386cf7d1f173f5feb9346df0f4121e49a41f19a2a8cec9613b655e` | 725032 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_03_photo.jpg` |
| `zz_04_photo.jpg` | `59970eb4cf7a7b30a29bdb3f92303fffeb2874be1a7e96e7d6f6b3ce14c66e77` | 637807 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_04_photo.jpg` |
| `zz_05_photo.jpg` | `7750b4fc1f56a6ee54de4d74f085468f5f37056fe49d0de2388d8af657772b3e` | 599345 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_05_photo.jpg` |
| `zz_06_photo.jpg` | `4e9f0f4a523ba3b702492d8a21270bf2d8249d1c67d260719d9898550fcd610e` | 280340 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_06_photo.jpg` |
| `zz_07_drawing_location.jpg` | `8f850cef565138c362f7dfc2be4da215473daef785256bc83ed02098aa4401b0` | 368220 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_07_drawing_location.jpg` |
| `zz_08_drawing_generate_logic.jpg` | `22a6f7107a2358dd050c5be661eaa88089d345659437f199f97dcecdba2a88e5` | 180997 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_08_drawing_generate_logic.jpg` |
| `zz_09_drawing_section_ew.jpg` | `44788b45eef879c7297d00b6eb19c6e9d790e3b6dd803bce651431d101979a60` | 211643 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_09_drawing_section_ew.jpg` |
| `zz_10_drawing_plan.jpg` | `e2e0d62cd87898d27c354c56dd0435c8e230067c1d7064e47ac5c1d507bb727f` | 280408 | 否 | `/workspace/landscape/2026-11-01/zhezhi_ciqikou/zz_10_drawing_plan.jpg` |
