# 云山（重庆园博园，多义景观，临时）

- 归档编号：`cloudy_mountain_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch13`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `cloudy_mountain_cq_1.jpg` | `e3e6fd3c9abc7dfc4008d8c61c961fbeaa6fc533dbaa747c6ccdfcac560ea357` | 911868 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_1.jpg` |
| `cloudy_mountain_cq_10.jpg` | `8d60f1cd4480eb1bffbfe37715612fd5cc9f0d6489515a9d03796d8f2afdcd16` | 369632 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_10.jpg` |
| `cloudy_mountain_cq_2.jpg` | `0b923c3191c0c01ab4bed12bf1dd4076fbccf53e31c8433abad4e6bd2a143e45` | 702560 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_2.jpg` |
| `cloudy_mountain_cq_3.jpg` | `2458301e6d82ab7858095b63dd5b06d5018fa3742f65c46303f7757f3a0e34d8` | 580537 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_3.jpg` |
| `cloudy_mountain_cq_4.jpg` | `dfbd40a2c8ce70aeb8f992b74b5425d0280ca416154ad898e1ba1fbc2ac88f59` | 1140738 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_4.jpg` |
| `cloudy_mountain_cq_5.jpg` | `e1a252b9b3f38a95500a17e717ae714f86cf563a8f27d2f33cb13bbb03c9b663` | 823858 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_5.jpg` |
| `cloudy_mountain_cq_6.jpg` | `eb46bce7803d7870ba98e623ec812a0a8298dbfe99bf132eb7c90c28fc54deeb` | 930420 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_6.jpg` |
| `cloudy_mountain_cq_7.jpg` | `f06ffb1e7de4c2ad456492dc82ff7917194f3955eecc34a010ec85800e07165c` | 951602 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_7.jpg` |
| `cloudy_mountain_cq_8.jpg` | `e24ee9a7d99c65ef8e2d198de44a0434785dc258d8f1a1257831972b7fabfa12` | 869219 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_8.jpg` |
| `cloudy_mountain_cq_9.jpg` | `01c161c898fa95eb58fb982014b01a74f62f7788b0b3af469f44a9d0f8dc17e2` | 893092 | 是 | `/workspace/landscape/batch13/cloudy_mountain_cq_9.jpg` |
