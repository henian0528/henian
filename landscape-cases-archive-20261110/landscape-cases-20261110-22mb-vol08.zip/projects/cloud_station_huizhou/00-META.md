# 半山云海驿站（南昆山）

- 归档编号：`cloud_station_huizhou`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-26
  - 出处说明：日期目录 2026-10-26（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-26/cloud_station_huizhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `cs_01_photo.jpg` | `28901d1890b9f01c87a6afe8ccd38a1e88aed18b6c5c4129f1fa37f6aa278370` | 747204 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_01_photo.jpg` |
| `cs_02_photo.jpg` | `7572136904a17c886ff7eadd5acc8f79b78cf736948ac4bb0e1e0efd036f36e2` | 812921 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_02_photo.jpg` |
| `cs_03_photo.jpg` | `005e065a3e5798b6e5a4845b3511d27b3857b8f0114969bfa8fbe2146f9b51f3` | 853374 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_03_photo.jpg` |
| `cs_04_photo.jpg` | `9e172345e07536a2e6e92801272a8fefb939d0a245ca341fea594c5575d52e52` | 468778 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_04_photo.jpg` |
| `cs_05_photo.jpg` | `02583c53edf81b084f863a10351f0358846538ad2b1f9feb1fd739082cc79ab1` | 792471 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_05_photo.jpg` |
| `cs_06_photo.jpg` | `1e8e3c8b237a5e4d3f5a4ab69671bc82d4cb561d77f495c712859d6a597e2b59` | 653507 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_06_photo.jpg` |
| `cs_07_photo.jpg` | `ff662e38a94aaf1edad194646d33b61d8a8d708b6b8216c4f8f7df38b68cb065` | 628013 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_07_photo.jpg` |
| `cs_08_drawing_site_plan.jpg` | `a29e97ac38edd965198d75dd689846e8ad1b3f4c2c1b8d9da1dbc6c0336124b3` | 549941 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_08_drawing_site_plan.jpg` |
| `cs_09_drawing_site_plan2.jpg` | `cde01c05312425100c46ce05c02cfafd77b448eeed8788375ecad82f9a5eeafe` | 550269 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_09_drawing_site_plan2.jpg` |
| `cs_10_drawing_section.jpg` | `4aacf7834d7a82fc95a16ff9aa005c1fc7916414c300107a2c580357f8956daf` | 219174 | 否 | `/workspace/landscape/2026-10-26/cloud_station_huizhou/cs_10_drawing_section.jpg` |
