# Come on Calm on 疗愈花园（曼谷，Shma）

- 归档编号：`come_on_calm_on_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `come_on_calm_on_bkk_1.jpg` | `0381eb97822f50dc666a3d25126fdad12af1e9a0c2aa9e48040fae3526a3fe90` | 181207 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_1.jpg` |
| `come_on_calm_on_bkk_10.jpg` | `a678dd442c0ae76ae50ce538ac9d0a326413e2c852e0b6105f51cdb563cb2bc3` | 238802 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_10.jpg` |
| `come_on_calm_on_bkk_2.jpg` | `a5c184b451904a0265ba09a61aa051d63dd92cb76c230975a8b040a47bf8f881` | 242453 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_2.jpg` |
| `come_on_calm_on_bkk_3.jpg` | `c66a16053c2ad8e39b989d426b0d88dc53dd1d8ed952f4cbf3ae984ec96a3fa2` | 145998 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_3.jpg` |
| `come_on_calm_on_bkk_4.jpg` | `e21b58cb76ae25c1df8ffc8c35ab17e197d20a9549e35acdba8a1f0ac1f1dc05` | 260846 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_4.jpg` |
| `come_on_calm_on_bkk_5.jpg` | `e7791d97bc0791573583af1e5dd85c017af1375b7e1a1befc257fa988c3d6000` | 223123 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_5.jpg` |
| `come_on_calm_on_bkk_6.jpg` | `c4a06073287e6d5191a66d7b99046302944545c61f0cdb6d561dcf6ac8e5bedf` | 436643 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_6.jpg` |
| `come_on_calm_on_bkk_7.jpg` | `be63630d201e917db14636185753cbfd9669128ec49876b3d2b165ad92cfcee0` | 238183 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_7.jpg` |
| `come_on_calm_on_bkk_8.jpg` | `482795bbf2c698559de381786ad066d28ae4e95dd67e848542a6a059224d773c` | 304958 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_8.jpg` |
| `come_on_calm_on_bkk_9.jpg` | `e3db52e01a5ebd8ace01d3510a589f7d63436b76f1e17f165343169bd5e3368a` | 153353 | 是 | `/workspace/landscape/batch12/come_on_calm_on_bkk_9.jpg` |
