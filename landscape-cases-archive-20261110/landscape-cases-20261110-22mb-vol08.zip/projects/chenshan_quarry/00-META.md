# 辰山矿坑花园（variety2 早期批次）

- 归档编号：`chenshan_quarry`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `chenshan_quarry_1.jpg` | `4044a6f478aed8fc38813318acd07eb553275285d36d6d0e1e19a004dd6f97ea` | 192863 | 否 | `/workspace/landscape/variety2/chenshan_quarry_1.jpg` |
| `chenshan_quarry_2.jpg` | `fbb4955f1069bf05e84a90ed912d60017d4d8d28711d959fc6497b28c6a44b60` | 245986 | 是 | `/workspace/landscape/variety2/chenshan_quarry_2.jpg` |
| `chenshan_quarry_3.jpg` | `301416fbe5d1c027495bfdd5a2844e18b1ac1bbd6c816da1d357b2ebd4c132cb` | 299546 | 是 | `/workspace/landscape/variety2/chenshan_quarry_3.jpg` |
| `chenshan_quarry_4.jpg` | `72ef7ac3fc874c6089ef673b1f73ca738e27f2a45992f478a8c9a8784ae87474` | 170775 | 否 | `/workspace/landscape/variety2/chenshan_quarry_4.jpg` |
| `chenshan_quarry_5.jpg` | `d8e884c855ceeca2ba288d56fbc98f89d93b6edc6626e2f48be99ce7d8274b54` | 146187 | 是 | `/workspace/landscape/variety2/chenshan_quarry_5.jpg` |
| `chenshan_quarry_6.jpg` | `f4e53c156918c227bdac5651032313edbe0e62469ce308664cdc269915ec3a72` | 271949 | 是 | `/workspace/landscape/variety2/chenshan_quarry_6.jpg` |
