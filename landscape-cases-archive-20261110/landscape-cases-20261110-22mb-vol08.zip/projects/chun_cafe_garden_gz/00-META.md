# 春咖啡花园（广州，batch18）

- 归档编号：`chun_cafe_garden_gz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `chun_cafe_garden_gz_1.jpg` | `b5f95dbe8907acf01900a2073c93977cd83224b30aa223991839c8468e277627` | 268851 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_1.jpg` |
| `chun_cafe_garden_gz_2.jpg` | `90cc5542a4f5ba734202824455aa66f786ed3835e9c012973c1b070f5e7f4204` | 255132 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_2.jpg` |
| `chun_cafe_garden_gz_3.jpg` | `2cdc8004076e0f78ea0215706c6d3f1ad2a71654fe4415d05cce0309ea0c7b7c` | 435681 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_3.jpg` |
| `chun_cafe_garden_gz_4.jpg` | `5ee11e1d6f112bbec9e0053a6f58d986d119f32a98556374712e033fa279fbfb` | 197635 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_4.jpg` |
| `chun_cafe_garden_gz_5.jpg` | `882bb86b79908bcf69705b60cbb2c627ca8494de01c917b7222278de0a757622` | 177850 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_5.jpg` |
| `chun_cafe_garden_gz_6.jpg` | `130cd27b40e03a2d1f1b3d27a03444b0810d6550b26dcd8685e8020e03863421` | 283156 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_6.jpg` |
| `chun_cafe_garden_gz_7.jpg` | `0a425a47d751833737c0d5d2ce59e0b33a7a7012e22fb2bef83c52b7b66c8509` | 200285 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_7.jpg` |
| `chun_cafe_garden_gz_8.jpg` | `34d2a328245c03326189d16794fb3024ab2fe2ab8183e8d257c2ccd810c8e55b` | 91077 | 是 | `/workspace/landscape/batch18/chun_cafe_garden_gz_8.jpg` |
