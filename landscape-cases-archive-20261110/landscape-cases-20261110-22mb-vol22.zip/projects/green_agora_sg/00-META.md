# Green Agora（新加坡，Spatial Anatomy）

- 归档编号：`green_agora_sg`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch13`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `green_agora_sg_1.jpg` | `3124accf957f89728bbdfc6b63a1c6f78d8a93338764a2ae7d6be53f488371e9` | 506813 | 是 | `/workspace/landscape/batch13/green_agora_sg_1.jpg` |
| `green_agora_sg_10.jpg` | `7bc2680d4cb1ac48d4ec18e9e47e0b120636f39605b14a566204d345c6c7c3c9` | 141900 | 是 | `/workspace/landscape/batch13/green_agora_sg_10.jpg` |
| `green_agora_sg_2.jpg` | `59f712b0874ddd3b500520bb9953787dbfe2abd8eb7c16927a37dd44d380d858` | 663470 | 是 | `/workspace/landscape/batch13/green_agora_sg_2.jpg` |
| `green_agora_sg_3.jpg` | `4bfca96061a4272b6e740617a32f16b18bbf5ec0677ecbe921168a34aae64250` | 717951 | 是 | `/workspace/landscape/batch13/green_agora_sg_3.jpg` |
| `green_agora_sg_4.jpg` | `0bf408ac8515d585ee9e4c17aeb76c87f0ce44ea8ce3f51f7258d5c6a8f4ce2f` | 643369 | 是 | `/workspace/landscape/batch13/green_agora_sg_4.jpg` |
| `green_agora_sg_5.jpg` | `c21a09bdf6a1fc154b201da65783c92df5598a97cc1e7a9ff0bfec05ad03745a` | 619833 | 是 | `/workspace/landscape/batch13/green_agora_sg_5.jpg` |
| `green_agora_sg_6.jpg` | `2e6d6be2c0ebe7ea7244e95f56d14a4952b746585e28863f1fb84d70b6d2f793` | 691129 | 是 | `/workspace/landscape/batch13/green_agora_sg_6.jpg` |
| `green_agora_sg_7.jpg` | `07ac8cd0b54c3c84190b17ed674f193735c30b6cf2f8ac6a9b33426dd0dea3be` | 292960 | 是 | `/workspace/landscape/batch13/green_agora_sg_7.jpg` |
| `green_agora_sg_8.jpg` | `c2a625c13db9fadd849d987c10c513d4c49add30296aa9aa4b7838a1f1f34b27` | 144378 | 是 | `/workspace/landscape/batch13/green_agora_sg_8.jpg` |
| `green_agora_sg_9.jpg` | `85d155fe8663d529f4a0dcf5efacb3bb676a10e2c05b8cdfc5c4307faf67fbaf` | 170599 | 是 | `/workspace/landscape/batch13/green_agora_sg_9.jpg` |
