# 你的温室厨房（广州扉美术馆）

- 归档编号：`greenhouse_kitchen_gz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch13`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `greenhouse_kitchen_gz_1.jpg` | `56d534b0a060f5cbcc358e31f29c543cc54f094e879042d5fba3849ad59bc4f8` | 969909 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_1.jpg` |
| `greenhouse_kitchen_gz_10.jpg` | `f312dc4558d6580c39b3f05377eb65dd7f9fc650bce39d9f8387b3b1932a6e95` | 803967 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_10.jpg` |
| `greenhouse_kitchen_gz_2.jpg` | `5c24cde57410a9a5ee3b737462098d846d330976c522182ab7327c9ea61f51f7` | 1088925 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_2.jpg` |
| `greenhouse_kitchen_gz_3.jpg` | `a165a6561f5379444469b9f2dee96b17bde3be472ed90aa4d3be5c2f7b3ab93a` | 771276 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_3.jpg` |
| `greenhouse_kitchen_gz_4.jpg` | `09aa6f47b8cdb49cc9d260a4d0e7acf2d17fa6b8315796420db69523b6e3f4b2` | 640406 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_4.jpg` |
| `greenhouse_kitchen_gz_5.jpg` | `4148ae44ccc0d94454b1209884dec5051cf06c6d1d0deb92afeafe198788c59c` | 680228 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_5.jpg` |
| `greenhouse_kitchen_gz_6.jpg` | `7f370944352d918cca91de85c1c10665d502fc0823c35c2d21337aade0efc218` | 942215 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_6.jpg` |
| `greenhouse_kitchen_gz_7.jpg` | `09f56e568728ff89d517e284b182712df642300e0c616f1791c013ea63330486` | 837429 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_7.jpg` |
| `greenhouse_kitchen_gz_8.jpg` | `1ee8b5f1b16f0ad30e3b69fb4d910fba8446771587b8319b140589c3e7ee1fdd` | 1042999 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_8.jpg` |
| `greenhouse_kitchen_gz_9.jpg` | `2f3b6e212885f899c9b93aa5a3219a496722fdd474acc18c46e6ce5020dd454f` | 897393 | 是 | `/workspace/landscape/batch13/greenhouse_kitchen_gz_9.jpg` |
