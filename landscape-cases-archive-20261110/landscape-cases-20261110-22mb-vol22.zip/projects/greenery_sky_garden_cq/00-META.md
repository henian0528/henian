# 翠微堤别墅庭院（MUSO 木守）

- 归档编号：`greenery_sky_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `greenery_sky_garden_cq_1.jpg` | `19e8c9e8c0524237b52fa2241c8aacac786e7eb67ee4de4fd04a6eea707c1d81` | 529971 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_1.jpg` |
| `greenery_sky_garden_cq_2.jpg` | `b602e1848a4e87a02bc1fc86f9768f142a27d299b7b9d0759321958cacb7cae3` | 578170 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_2.jpg` |
| `greenery_sky_garden_cq_3.jpg` | `c455c4f8052745325965821af55bbd7898c112720b6156705dc6d90980dddd22` | 415601 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_3.jpg` |
| `greenery_sky_garden_cq_4.jpg` | `57750f17696bfb435c779b4f1f5d5b3b4f186ab7caeeda8ea02de45a6ec763d5` | 478134 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_4.jpg` |
| `greenery_sky_garden_cq_5.jpg` | `a76939b197944b0bcad888c943ac5f75213f588480d342f285b2d48602220700` | 464792 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_5.jpg` |
| `greenery_sky_garden_cq_6.jpg` | `69105702e5936e57295826af24bfab909fa72f7cfb4343044ec923058a256a52` | 546327 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_6.jpg` |
| `greenery_sky_garden_cq_7.jpg` | `3a91a5236563f898b0535f0123e5ee89a24708c76da5126b6c2891999379cf0a` | 565435 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_7.jpg` |
| `greenery_sky_garden_cq_8.jpg` | `a4301881205d3c56d58d91a15ee9162ae435516a07dd75464435598c56b207f4` | 574015 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_8.jpg` |
| `greenery_sky_garden_cq_9.jpg` | `4da3a785c7eb00a99ef27ff8c16532f28fe48cc4db9f2880d90307e432e2736b` | 446341 | 是 | `/workspace/landscape/batch20/greenery_sky_garden_cq_9.jpg` |
