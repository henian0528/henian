# 景观案例查询 · 已推荐项目归档索引

主清单只含已推荐或有发出记录的项目。期刊标明未发、且未见补发的 6 项在 `appendix-candidates/`，标为「仅候选」，不计入已推荐。
按日期可检索的全部已发出原文见 `sent-originals-by-date/`（不只按项目匹配）。

主清单项目数：**220**
其中有当时原文：**195**；仍缺原文：**25**；缺图片：**0**；附录仅候选：**6**

「缺原文 / 缺图片 / 仅候选」已在备注列标明，未编造补全。部分同项目分置于两个目录（不同配图批次），原文已互见。

| 编号 | 名称 | 状态 | 日期 | 图数 | 原文 | 摘要 | 备注 |
|---|---|---|---|---:|---|---|---|
| `550_madison_garden_nyc` | 550 Madison Avenue Garden（纽约，Snøhetta） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `ankaret_trellis_roof` | Ankaret 白色棚架屋顶花园（Guise） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `atlas_garden_eindhoven` | Atlas Garden（埃因霍温） | `sent` | 2026-10-10 | 8 | 有 | 缺 | — |
| `azabudai_cloud` | 麻布台之云（white3） | `likely_sent` | 2026-10-07前后（早期主题） | 4 | 有 | 缺 | — |
| `baihuayuan_xinyang` | 百花园书屋与曲廊廊架（信阳，刘宇扬） | `briefed` | 2026-11-01 | 10 | 有 | 有（未纳入公开包） | — |
| `baishuidong` | 白水洞村石瀑间的线性钢亭组群（有田设计） | `likely_sent` | 2026-10-20 | 10 | 有 | 缺 | — |
| `baiyun_courtyard` | 白云庭院（长阳路138弄，Wutopia Lab） | `sent` | 2026-10-08 | 12 | 有 | 缺 | — |
| `balfour_st_sydney` | Balfour St（期刊记因图片拦截未发） | `sent` | 2026-10-16 | 4 | 有 | 缺 | — |
| `bananaleaf` | 芭蕉叶亭／相关遮阳案例（china-canopy） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `benthemplein_water_square` | 鹿特丹 Benthemplein 水广场 | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `berresgasse_vienna` | Berresgasse（维也纳，期刊记图片曾被拦截） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `berry_square_sydney` | Berry Square（悉尼，ASPECT） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `bishan` | 新加坡碧山宏茂桥公园 / Bishan-Ang Mo Kio Park | `sent` | 2026-10-06 | 6 | 有 | 缺 | — |
| `blank_garden_tokyo` | Blank Garden（东京，Unemori） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `bloom_box_kunshan` | 花盒咖啡（昆山） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `bodil_koch_garden_cph` | Bodil Koch's Garden（哥本哈根） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `bojuebao_garden_cq` | 博爵堡别墅庭院（重庆，MUSO 木守） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `boundless_garden_sz` | 无界 Boundless（深圳仙湖，造源） | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `breeze_hall` | Breeze Hall（white3） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `brnox_patch_brno` | Brnox 街角公园（布尔诺） | `sent` | 2026-10-15 | 9 | 有 | 缺 | — |
| `buhuahui_huizhou` | 步花洄／铁岗河驿站（惠州，大料建筑） | `likely_sent` | 2026-11-09 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `busstop_krumbach` | BUS:STOP Krumbach（奥地利） | `sent` | 2026-10-08 | 8 | 有 | 缺 | — |
| `canal_post_hangzhou` | 运河小亭驿（杭州拱宸桥） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `caoxi_pocket_park` | 上海漕溪路口袋公园（清风驿站） | `briefed` | 2026-10-24 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `caoyuan_hutong` | 草园胡同（courtyard 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `carl_nielsens_alle_cph` | Carl Nielsens Allé（哥本哈根） | `sent` | 2026-10-15 | 8 | 有 | 缺 | — |
| `cbd_rooftop_bj` | 北京 CBD 屋顶花园（甲南园林） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `chaishan` | 舟山柴山岛海边长亭（GN 栖城设计） | `uncertain` | 2026-10-18 | 10 | 缺 | 缺 | 缺原文 |
| `changli_garden_shanghai` | 昌里花园（上海，TM Studio） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `changning_service_stations_sh` | 长宁外环市民服务驿站（上海，致正） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `changting_hangzhou` | 长亭驿（杭州滨江钱塘江，同济原作） | `likely_sent` | 2026-11-10 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `chashan_fu_pavilion` | 茶山浮亭（杭州长埭村，由牧） | `likely_sent` | 2026-10-07前后（早期主题） | 10 | 有 | 缺 | — |
| `chengdu_expo` | 成都园博相关白色亭（white） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `chenshan_quarry` | 辰山矿坑花园（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `chun_cafe_garden_gz` | 春咖啡花园（广州，batch18） | `likely_sent` | 2026-10-10 | 8 | 有 | 缺 | — |
| `cloud_station_huizhou` | 半山云海驿站（南昆山） | `likely_sent` | 2026-10-26 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `cloudy_mountain_cq` | 云山（重庆园博园，多义景观，临时） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `come_on_calm_on_bkk` | Come on Calm on 疗愈花园（曼谷，Shma） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `cool_calm_north_london` | Cool Calm（北伦敦，batch24） | `likely_sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `corner_garden_shanghai` | the CORNER garden（上海，VIA） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `cuiping_wuxi` | 无锡翠屏（white2；或与翡翠屏为同一/相关案） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `dayandnight_kiosk_beijing` | 日夜公园 jetlag books（三里屯） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `daydream_xiangshan` | 白日梦之径（象山滨海驿站） | `likely_sent` | 2026-10-08 | 2026-10-27 | 45 | 缺 | 有（未纳入公开包） | 缺原文 |
| `deck` | 上海甲板花园（VIA 维亚景观） | `likely_sent` | 2026-10-15 | 10 | 有 | 缺 | — |
| `den_bel_antwerp` | Den Bel（期刊记因图片拦截未发） | `sent` | 2026-10-16 | 5 | 有 | 缺 | — |
| `dengying_yancheng` | 登瀛小筑（盐城铜马广场，MUDO） | `sent` | 2026-10-08 | 2026-11-10 | 20 | 有 | 有（未纳入公开包） | — |
| `diagonal_house_tokyo` | Diagonal House（东京，永山祐子/荻野） | `sent` | 2026-10-10 | 6 | 有 | 缺 | — |
| `domus_houthavens_courtyard` | Domus Living Houthavens（阿姆斯特丹） | `sent` | 2026-10-19 | 10 | 有 | 缺 | — |
| `dongjiao_bus_stop` | 东角村乡村公交站（嵛山岛） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `dongshan_shaoye_square_guangzhou` | 东山少爷南广场（广州，哲迳） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `duisburg_nord` | 北杜伊斯堡景观公园（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `edinburgh_raingarden_melb` | Edinburgh Gardens Raingarden（墨尔本，GHD） | `sent` | 2026-10-16 | 9 | 有 | 缺 | — |
| `emerald_screen_wuxi` | 无锡渤公岛「翠屏花障」（Wutopia Lab） | `likely_sent` | 2026-10-08 | 2026-10-26 | 18 | 有 | 有（未纳入公开包） | — |
| `engawa_house_osaka` | Engawa House（大阪，nLDK） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `erheyuan_baitasi` | 二合院（白塔寺，courtyard 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `eyes_on_place_nanjing` | Eyes on Place（南京屋顶） | `sent` | 2026-10-13 | 10 | 有 | 缺 | — |
| `feiying_shiyaling` | 绯影驿站（深圳石芽岭，Studio 10） | `likely_sent` | 2026-11-09 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `fenggu_huizhou` | 凤谷驿／五指棚（惠州显岗水库） | `likely_sent` | 2026-11-02 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `fengmei_huizhou` | 风袂驿（惠州罗浮山显岗水库） | `briefed` | 2026-10-08 | 2026-11-01 | 20 | 有 | 有（未纳入公开包） | — |
| `fengxingxia_station_chengdu` | 丰行侠驿站（成都） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `fengzhiyuan_suzhou` | 风之园驿站（苏州金鸡湖，矶崎新+胡倩工作室） | `briefed` | 2026-11-08 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `float_flutter_flow_chaumont` | Float Flutter Flow（Chaumont，batch15） | `likely_sent` | 2026-10-09 | 7 | 有 | 缺 | — |
| `forest_garden_leytonstone` | Forest Garden（伦敦 Leytonstone，HÛT） | `sent` | 2026-10-13 | 10 | 有 | 缺 | — |
| `futing` | 浮亭相关（white；与茶山浮亭可能为同一方向） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `gardenful_beijing` | Gardenful（北京，TAOA） | `sent` | 2026-10-16 | 2026-10-19 | 20 | 有 | 缺 | — |
| `gent_townhouse_garden` | 根特 Garden Veerle and Rhida（Plant en Houtgoed） | `sent` | 2026-10-10 | 5 | 有 | 缺 | — |
| `glassfields` | Glassfields（期刊记因图片拦截未发） | `sent` | 2026-10-16 | 4 | 有 | 缺 | — |
| `green_agora_sg` | Green Agora（新加坡，Spatial Anatomy） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `greenery_sky_garden_cq` | 翠微堤别墅庭院（MUSO 木守） | `sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `greenhouse_kitchen_gz` | 你的温室厨房（广州扉美术馆） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `gugu_dapi` | 咕咕来仪·大伾山悬崖驿站（河南浚县） | `likely_sent` | 2026-11-11 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `guitou_wetland` | 龟头湿地（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `guiwan_qianhai` | 前海桂湾公园驿站三座（深圳） | `briefed` | 2026-11-08 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `h01_garden_sh` | H01 花园（上海，batch18） | `likely_sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `haian_lingang` | 上海临港「海岸生态驿站」（HCCH 合尘建筑） | `likely_sent` | 2026-11-02 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `haitang_jieyou_suzhou` | 海棠解忧铺（苏州） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `haizhixu_xiangshan` | 海之墟驿站（象山东旦，Mur Mur Lab） | `likely_sent` | 2026-11-09 | 10 | 有 | 有（未纳入公开包） | — |
| `harbour_kiosk_hk` | Harbour Kiosk（香港） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `hatt_street_garden` | 251 Hatt Street（Dundas） | `sent` | 2026-10-19 | 10 | 有 | 缺 | — |
| `heguang_garden` | 和光庭（上海，七月合作社） | `sent` | 2026-10-07前后（早期主题） | 2026-10-19 | 14 | 有 | 缺 | — |
| `heping_park_gate6_shanghai` | 和平公园六号门（上海，致正） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `hetu_luoshu_shanghai` | 河图洛书亭（上海西岸黄浦江畔） | `likely_sent` | 2026-10-07前后（早期主题） | 2026-10-27 | 40 | 有 | 有（未纳入公开包） | — |
| `hongxu_habitat_garden` | 虹旭生境花园（上海长宁） | `sent` | 2026-10-13 | 10 | 有 | 缺 | — |
| `hook_house_habikino` | Hook House（大阪羽曳野，ninkipen!） | `sent` | 2026-10-10 | 6 | 有 | 缺 | — |
| `hop_park_bkk` | Hop Park 天桥快闪花园（曼谷，Shma） | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `house_lw27_munich` | House LW27（慕尼黑，batch18） | `likely_sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `house_minami_senri` | House in Minami-Senri（大阪，FujiwaraMuro） | `sent` | 2026-10-10 | 6 | 有 | 缺 | — |
| `huangdeng_pocket_gz` | 黄登口袋花园（广州，UPON） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `hudie_hefei` | 蝴蝶驿站（合肥派园） | `likely_sent` | 2026-11-02 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `hudong_exp` | 沪东实验（浦东，VIA） | `sent` | 2026-10-08 | 11 | 有 | 缺 | — |
| `infinite_grove_sh` | 无限丛林／Infinite Grove（上海，batch15） | `likely_sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `inside_the_flower_berlin` | Inside the Flower（柏林 IGA，Janet Laurence 和 LAVA） | `sent` | 2026-10-09 | 6 | 有 | 缺 | — |
| `ishigami_water_garden` | 石上纯也水庭（batch7） | `uncertain` | 2026-10-08 | 8 | 缺 | 缺 | 缺原文 |
| `jiezi_pavilion_yandang` | 芥子亭（雁荡山） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `jingshan_cogarden_sz` | 鲸山别墅社区共建花园（深圳） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `jingyue_central_park` | 长春净月中央公园（水石设计） | `sent` | 2026-10-03 | 6 | 有 | 缺 | — |
| `jingzhai_garden_nj` | 静宅庭院（南京，boll是园） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `jinji_lake_pavilion` | 苏州金鸡驿（金鸡湖亭） | `likely_sent` | 2026-10-25 | 36 | 缺 | 有（未纳入公开包） | 缺原文 |
| `jinji_no1_suzhou` | 金鸡湖 1 号驿站（苏州） | `briefed` | 2026-11-08 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `juanzong_bookstore_shunyi` | 卷宗书店（顺义，batch24） | `likely_sent` | 2026-10-10 | 6 | 缺 | 缺 | 缺原文 |
| `kampung_admiralty` | Kampung Admiralty（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `klee_klee_shanghai` | klee klee & friends 店铺景观（上海，或然） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `klin_mai_hom_cnx` | Klin Mai Hom（清迈，batch15） | `likely_sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `kraffer_garden_jindrichuv` | Kraffer Community Garden（捷克） | `sent` | 2026-10-16 | 9 | 有 | 缺 | — |
| `lantern_garden_cd` | 灯笼花园（成都，batch15） | `likely_sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `lanxi_villa_garden_cq` | 华侨城岚溪云墅素园（重庆，木守） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `laoyuting` | 捞鱼亭 / Laoyuting Pavilion（大舍） | `likely_sent` | 2026-10-13 | 10 | 有 | 缺 | — |
| `leaf_structure_dallas` | Leaf Structure（达拉斯植物园，Legge Lewis Legge） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `leaf_vein_garden_nanping` | 叶脉花园（建瓯，大小景观） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `leuven_kw_garden` | 鲁汶 Garden Kathleen and Wim（Plant en Houtgoed） | `sent` | 2026-10-10 | 6 | 有 | 缺 | — |
| `leuven_townhouse_garden` | 鲁汶联排后院 Garden Dorien and Pierre-Yves | `sent` | 2026-10-10 | 4 | 有 | 缺 | — |
| `leyi_habitat_garden` | 乐颐生境花园（上海长宁） | `sent` | 2026-10-13 | 4 | 有 | 缺 | — |
| `liangjiang_xinchen_garden_cq` | 两江新宸别墅庭院（MUSO 木守） | `sent` | 2026-10-10 | 7 | 有 | 缺 | — |
| `lingjing_pocket_park` | 灵境胡同地铁口口袋公园 | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `linping` | 临平相关遮阳案例（china-canopy） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `london_woodland_garden` | 伦敦小林地花园（Alasdair Cameron） | `sent` | 2026-10-19 | 6 | 有 | 缺 | — |
| `long_heal_bkk` | LongiPark Long Heal（曼谷，Shma，临时） | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `longan_tree_yard_qz` | 龙眼树院（batch18） | `likely_sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `longcheng` | 龙城相关遮阳案例（china-canopy） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `longjing_tea_pavilion` | 杭州龙井茶亭（上埠头村） | `likely_sent` | 2026-10-25 | 32 | 缺 | 有（未纳入公开包） | 缺原文 |
| `longnan_waiting` | 龙南候车亭（江西龙南高铁东站） | `likely_sent` | 2026-11-11 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `longqiyuan_pavilion` | 龙麒源水之廊亭（温州） | `likely_sent` | 2026-10-26 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `luwan_waterbird_park` | 渌湾水鸟公园（batch7） | `uncertain` | 2026-10-08 | 10 | 缺 | 缺 | 缺原文 |
| `luxun_coffee_shed` | 上海鲁迅公园咖啡亭 | `briefed` | 2026-10-24 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `manyuan_beijing` | 满园（北京，TAOA） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `matrix_garden_sg` | The Matrix Garden（新加坡，Sanitas Studio） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `meiso_ito` | Meiso no Mori / Ito（white2） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `meiyuan_cafe_sh` | 梅园咖啡花园（上海，batch18） | `likely_sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `minami_machi_house_matsuyama` | House in Minami-machi（松山，Jun Yamaguchi + Chiba Plantation） | `sent` | 2026-10-10 | 6 | 有 | 缺 | — |
| `moonlight_pavilion` | 广州大金钟公园·月影亭 | `likely_sent` | 2026-10-12 | 8 | 有 | 缺 | — |
| `nanyuan_roof_garden_sz` | 南园绿云屋顶共建花园（深圳，一十一建筑） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `naoshima_sanaa` | 直岛 SANAA（white2） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `nature_blessings_house_aichi` | 受到自然祝福的住宅（爱知，TSC） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `nine_square_wuxi` | 无锡渤公岛「九宫亭」（非常建筑·张永和） | `likely_sent` | 2026-10-27 | 29 | 有 | 有（未纳入公开包） | — |
| `nuanting_pavilion` | 暖亭（浦东向东社区之家，VIA） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `ny_ostergade_rooftop` | Ny Østergade 屋顶花园（哥本哈根） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `o_building_kichijoji` | O_building（东京吉祥寺） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `oishii_park_shingu` | Oishii 公园（新宫，td-Atelier） | `sent` | 2026-10-16 | 9 | 有 | 缺 | — |
| `olympic_sculpture_park` | 西雅图奥林匹克雕塑公园 / Olympic Sculpture Park | `sent` | 2026-10-07 | 16 | 有 | 缺 | — |
| `ouyang_pocketpark` | 欧阳路祥德路转角口袋公园（山水秀） | `sent` | 2026-10-08 | 14 | 有 | 缺 | — |
| `paley_park` | 佩雷公园 Paley Park（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `peabody_plaza_nashville` | Peabody Plaza（纳什维尔） | `sent` | 2026-10-16 | 9 | 有 | 缺 | — |
| `penguin_garden_shekou` | 企鹅花园（深圳蛇口） | `sent` | 2026-10-13 | 7 | 有 | 缺 | — |
| `piazza_matteotti_gardens` | 马特奥蒂广场公共花园（意大利，Pool） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `piloti_bellevue` | Piloti Bellevue（white2） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `pingshan_kids` | 坪山儿童游乐（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `pk_house_bkk` | PK House（曼谷，batch18） | `likely_sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `pocket_campus_bernini_turin` | Pocket Campus Bernini（都灵，期刊记图片曾被拦截） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `pointe_liuying` | 台南柳营站前「蜻蜓，轻亭」（丁尺建筑师事务所，2023） | `likely_sent` | 2026-11-11 | 10 | 有 | 有（未纳入公开包） | — |
| `praca_da_arvore_recife` | Praça da Árvore（累西腓） | `sent` | 2026-10-16 | 9 | 有 | 缺 | — |
| `qh_urban_jungle_berlin` | QH Straight Urban Jungle（柏林） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `qijiang_park` | 歧江公园（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `quantum_pocketpark_cq` | 高新量子口袋公园（重庆，10Design） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `qunli` | 哈尔滨群力国家城市湿地公园 | `sent` | 2026-10-05 | 6 | 有 | 缺 | — |
| `resilience_garden_seoul` | Resilience Garden（首尔，batch15） | `likely_sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `sanaa_serpentine2009` | SERPENTINE 2009（SANAA，structures 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 7 | 有 | 缺 | — |
| `santing_garden` | 三亭园（北京，水行设计） | `sent` | 2026-10-08 | 11 | 有 | 缺 | — |
| `serpentine2013` | Serpentine 2013（white3） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `shadowplay_phoenix` | Shadowplay Phoenix（white） | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `shengjing_dongan_sh` | 生境东岸（上海） | `sent` | 2026-10-15 | 10 | 有 | 缺 | — |
| `shenyang_jianzhu_rice` | 沈阳建筑大学稻田校园（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `sheyun_tengchong` | 摄云（腾冲，white3） | `likely_sent` | 2026-10-07前后（早期主题） | 7 | 有 | 缺 | — |
| `shiguang_buyu_nanjing` | 时光补语（南京，batch24） | `likely_sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `shiguang_jiaxing` | 时光（嘉兴，courtyard 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `shuju_shanghai` | 「树」居（上海，大海小燕） | `sent` | 2026-10-10 | 5 | 有 | 缺 | — |
| `skyline_garden_cq` | 天樾私人住宅花园（MUSO 木守） | `sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `southwood_avenue_garden` | 北伦敦三角形小花园（Stefano Marinaz） | `sent` | 2026-10-19 | 10 | 有 | 缺 | — |
| `starfire` | 深圳大鹏新区星火探索营廊架（厘米制造） | `likely_sent` | 2026-10-21 | 10 | 有 | 缺 | — |
| `suan_san_bkk` | Suan San 口袋公园（曼谷，Shma） | `sent` | 2026-10-15 | 9 | 有 | 缺 | — |
| `superkilen` | 哥本哈根 SuperKilen 超级线性公园 | `prepared` | 2026-10-08 | 6 | 有 | 缺 | — |
| `swirl_garden_sz` | 漩花园（深圳，大小营造） | `sent` | 2026-10-10 | 9 | 有 | 缺 | — |
| `szplan_canopy` | 深圳规划相关棚（white3） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `taixing_canopy` | 泰兴运河畔「大船篷／大茶棚」 | `briefed` | 2026-10-24 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `taizhou_forest_box` | 台州森林盒子（batch7） | `uncertain` | 2026-10-08 | 10 | 缺 | 缺 | 缺原文 |
| `tank_shanghai` | 上海油罐艺术中心（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `taohuayuan_zen` | 桃花源（courtyard 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `tapestry_urban_greenery` | A Tapestry of Urban Greenery（Stefano Marinaz） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `terrazza_biandra_milan` | Terrazza Biandrà（米兰） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `tianrang_yunying_sz` | 天壤云影（深圳） | `sent` | 2026-10-15 | 10 | 有 | 缺 | — |
| `tofukuji_hojo` | 东福寺方丈庭园（courtyard 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `triangle_park_cambridge` | Triangle Park（剑桥，Stoss） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `tsuboniwa_retreat_london` | Tsuboniwa Retreat（伦敦，batch24） | `likely_sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `udaan_park_udaipur` | Udaan Park（乌代浦） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `unemori_houses_tokyo` | Unemori Houses（东京，batch24） | `likely_sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `velez_malaga_viewpoint_garden` | 韦莱斯-马拉加城堡观景花园（西班牙） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `vietnam_memorial` | 越战纪念碑（variety2 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `wangshan_huzhou` | 望山（湖州，white2） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `wastefree_ecoisland_sz` | 无废智能生态岛（深圳） | `sent` | 2026-10-16 | 7 | 有 | 缺 | — |
| `wat_hua_lamphong_bkk` | 华南蓬寺 Rukkhaniwet 公园（曼谷，Shma） | `sent` | 2026-10-15 | 8 | 有 | 缺 | — |
| `wave_garden_sz` | 浪花园（深圳，大小景观） | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `west_london_corner_garden` | 西伦敦转角花园（Stefano Marinaz） | `sent` | 2026-10-19 | 8 | 有 | 缺 | — |
| `westmoreland_dallas` | 达拉斯 Westmoreland Park Pavilion | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `white_sheet_tallinn` | 「一页白纸」阅读亭（塔林，Ninja Stuudio） | `sent` | 2026-10-08 | 13 | 有 | 缺 | — |
| `white_tangram_entrance` | 白色七巧板（华东师大一村入口） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `wuhan_fenghuang` | 武汉凤凰（white） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `wutong` | 梧桐亭，深圳（悉地国际东西影工作室） | `likely_sent` | 2026-10-19 | 10 | 有 | 缺 | — |
| `wuxi_changan_station` | 无锡惠山长安市民广场驿站（灰空间） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `xiaoliangtan_garden_chengdu` | 小亮滩花园（成都，West 8） | `sent` | 2026-10-16 | 8 | 有 | 缺 | — |
| `xinchang_back_garden_sh` | 新场古镇后花园（上海，UDG） | `sent` | 2026-10-16 | 10 | 有 | 缺 | — |
| `xinhua_mirror_garden` | 新华路∞花园口袋公园 | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `xinhua_rd_pocketpark` | 新华路∞花园口袋公园（batch12 配图） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `xinyang_pergola` | 信阳百花园曲廊与花亭（刘宇扬） | `likely_sent` | 2026-10-07前后（早期主题） | 10 | 有 | 缺 | — |
| `xuanting_shenzhen` | 轩亭（深圳，structures 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 10 | 有 | 缺 | — |
| `yangpu_riverside` | 杨浦滨江（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `yanweizhou` | 雁尾洲公园（variety 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 10 | 有 | 缺 | — |
| `yiye_tea_pavilion` | 一叶茶亭（structures 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 9 | 有 | 缺 | — |
| `yongjia_rd_pocketplaza` | 永嘉路口袋广场（阿科米星） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `youmu_tea_pavilion` | 杭州长埭村茶山浮亭（由牧） | `likely_sent` | 2026-10-25 | 34 | 有 | 有（未纳入公开包） | — |
| `yuandang_canopy` | 元荡棚（white2） | `likely_sent` | 2026-10-07前后（早期主题） | 5 | 有 | 缺 | — |
| `yuanyuan_garden_sz` | 缘圆园（深圳蔚蓝海岸社区） | `sent` | 2026-10-09 | 10 | 有 | 缺 | — |
| `yuniao_membrane_canopy` | 玉鸟集食集膜顶棚（良渚） | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `yunlu_stargazing` | 云麓观星（structures 早期批次） | `likely_sent` | 2026-10-07前后（早期主题） | 10 | 有 | 缺 | — |
| `yunzhiyuan` | 云之园（white） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `z_house_pinggu` | Z宅（平谷，Y+Y） | `sent` | 2026-10-10 | 8 | 有 | 缺 | — |
| `zhangjiagang_bus_stop` | 张家港高铁新城公交站台 | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `zhaomushan_villa_garden_cq` | 照母山天玺别墅南岑（重庆，木守） | `sent` | 2026-10-10 | 10 | 有 | 缺 | — |
| `zhezhe_pavilion_hangzhou` | 运河褶褶亭 | `sent` | 2026-10-08 | 10 | 有 | 缺 | — |
| `zhezhi_ciqikou` | 折纸轻亭（重庆磁器口东门旅游服务驿站） | `briefed` | 2026-11-01 | 10 | 缺 | 有（未纳入公开包） | 缺原文 |
| `zhiyuanwu` | 知园坞相关遮阳案例（china-canopy） | `likely_sent` | 2026-10-07前后（早期主题） | 6 | 有 | 缺 | — |
| `zhuzhiting` | 柱之亭（宁波象山，Found Projects + 明暗研究室） | `sent` | 2026-10-14 | 2026-11-10 | 20 | 有 | 有（未纳入公开包） | — |

## 附录：仅候选（未见发出记录）

- `anywhere_door_garden_sh`  任意门互动花园（期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
- `common_airea_bkk`  Common Air-rea（期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
- `membrane_roof_house_tokyo`  House with Membrane Roof（东京，期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
- `sikbang_maru_seoul`  Sikbang Maru Pavilion（期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
- `siu_kai_fong_hk`  小街坊 Siu Kai Fong（临时展，期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
- `wildlings_logrono`  Wildlings（洛格罗尼奥临时装置，期刊记未发）  — **仅候选**（期刊记为未发，已回读原文中无补发）
