# 覆盖范围与核查说明

## 已核查的本地位置

- `/workspace/landscape/` 日期目录、batch7–33、courtyard、structures、variety、variety2、china-canopy-cases（含 white/white2/white3）、gardenful_more（仅作来源注记；个人委托图纸与完整研究报告未纳入公开包）
- `/cursor/stores/store-e9ad9e1a-cf4d-4dfe-9c57-fbba4ced80c4` 与 user store、`/home/box/agent-data/agents/1879095d-b707-48b8-8a64-4d22b9a1a6d1` 附件（只做 SHA256 命中对照，不另拷无关附件）
- bot 记忆/日记中带「私聊已发第 N 批」「已推送案例」的条目
- 本轮父对话里可见的群聊配图说明

## 对话记录

已按任务要求尝试 SearchTranscripts / 记忆检索。记忆可用于核对手册化的已发名单；SearchTranscripts 在本执行器中未能打开该 bot 的历史会话，故**不能声称历史原文已全部回读**。

## 第 1–6 批

本地没有 `batch1`–`batch6` 目录。早期材料落在 `structures` / `china-canopy-cases` / `white*` / `variety` / `variety2` / `courtyard`。这些很可能对应编号批次开始前的私聊推荐，但缺少「第 N 批已发」逐项日记，项目级发送确认弱于 batch8 起有日记的批次。

## 重复项目

已合并目录但保留各次出现记录与全部精选图：柱之亭（2026-10-14 与 2026-11-10）、登瀛小筑（batch8 与 2026-11-10）、白日梦步道（batch7 与 2026-10-27）、翠屏/翡翠屏（batch7 与 2026-10-26）、风袂驿（batch7 与 2026-11-01）、河图洛书（china-canopy 与 2026-10-27）、和光庭（courtyard 与 batch33）、Gardenful（batch29 与 gardenful_more）。

## 父 bot 会话访问核验（2026-11-10 续，America/Los_Angeles）

本执行器按要求使用 `in='1879095d-b707-48b8-8a64-4d22b9a1a6d1'`（父 bot / 景观案例查询 agent id），**不能把它当成父会话没有内容**。实际结果如下：

1. `SearchTranscripts(in='1879095d-b707-48b8-8a64-4d22b9a1a6d1', query='第', limit=200)` 返回原文：`This session has no record of what was said to read.`
2. `ReadTranscript(in='1879095d-b707-48b8-8a64-4d22b9a1a6d1', around=400, limit=5)` 返回同一句：`This session has no record of what was said to read.`
3. `ReadTranscript(in='1879095d-b707-48b8-8a64-4d22b9a1a6d1', before=420, limit=200)` 且 `write_to_file=true` 时，写出的不是父会话 1294 条记录，而是**本执行器自己的当前 run**：文件头显示为本执行器自己的当前 run（约 94 条），不是父会话记录。

因此本执行器**无法自行分页读取父会话**。已发出原文只能来自父会话导出的两份文件：SearchTranscripts 81 条匹配、ReadTranscript positions 361–419 / 1294。完整导出（含推理与工具）未放入归档，只提取了发出文字和配图路径。

请父会话继续导出（均用父侧 `in=session`）：

- `ReadTranscript(in=session, before=361, limit=200)`，再 `before` 该页起始，直到 1。此段应含第 8 批各案 SendToUser 正文（本页只有发送回执，没有参数正文），以及更早的日推与主题批次。
- 从最新向前：`ReadTranscript(in=session, limit=200)`，再按返回页起始翻到 420 为止。此段应含 10 月下旬至 11 月群推主文（检索里 441、440、433、399、403、316 等为截断，需全文）。

在上述页到齐之前，不得声称原文已全部回读完成。

## 父会话导出回读（2026-11-10 晚，America/Los_Angeles）

已按导出文件头中的 positions 区间核验父会话 0–1299 的覆盖。本执行器自身的短会话导出、检索摘录与网页抓取未当作发出原文，亦未把完整会话记录放入公开包。

- 文件头声明的页区间合计覆盖 **positions 0–1299，无缝**（1300 之后为本轮整理过程，未纳入）。
- 按文件内实际 JSON 消息计数，仍有 **53** 个位置没有对应对象，多为分页文件末尾截断，簇为：[[47, 48], [142, 144], [187, 191], [245, 247], [303, 306], [358, 360], [708, 709], [763, 765], [828, 828], [878, 879], [979, 979], [1073, 1073], [1121, 1131], [1176, 1179], [1234, 1236], [1295, 1299]]。其中较大的是 **1121–1131**（约在 10-31 用量说明与 11-08「海之墟」之间）和 **1295–1299**（最后一页尾部）。这些位置没有发出正文可提取，未编造。
- 实际解析到的消息位置：1247；重叠位置（相邻页重复）已去重。
- 已确认发出的 SendToUser：344 条（含文字 337，含配图 200）。未确认的 13 条中，除空消息外均有后来成功重发或同文已确认版本，故只收录确认发出的一条。
- 发出配图路径在磁盘上均能找到（1694 次引用）。`/workspace/cases/today` 仅用于长春净月（文件名与内容相符）。
- 完整会话导出未放入归档。
