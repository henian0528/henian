# 缺失与未决清单

本清单只记录查到的缺口，不编造配图或原文。

## 长春净月中央公园（`jingyue_central_park_changchun`）

- 问题：缺图且缺原文
- 说明：期刊 2026-10-05：已推过的项目还有 2026-10-04 长春净月中央公园。本地 /workspace/landscape 无 2026-10-04 目录，也未找到配图或当时原文。

## （工作日日推日历空档）（`_calendar_gaps`）

- 问题：可能漏档或仅私聊批次、无独立日期目录
- 说明：在本地日期目录中，未见 2026-10-16、2026-10-22、2026-10-23、2026-10-28～10-31、2026-11-03～11-07 的案例日推目录。其中 10-16 前后有大量私聊批次；10-28～10-31、11-03～11-07 是否漏推未从对话记录完全核实。不要把空档自动写成「没有推荐」。

## （绝大多数项目的当时推荐原文）（`_original_texts`）

- 问题：原文未回读
- 说明：本执行器对 SearchTranscripts 传入本 bot / agent id 时得到「This session has no record」。因此除本轮对话上下文里两条群聊配图说明（柱之亭 11-10、蜻蜓轻亭 11-11）外，未能提取历史群聊或私聊的逐字推荐正文。日记/记忆只有项目名单，不是原文。10-24 起的 summary.md 是要点摘要，已原样保存但标明不得冒充原文。

## 缺当时逐字原文的项目（名单）

除 `zhuzhiting`、`pointe_liuying` 有本轮上下文中的群聊配图说明原文外，其余项目均未回读到当时推荐正文。

- `550_madison_garden_nyc` 550 Madison Avenue Garden（纽约，Snøhetta）
- `ankaret_trellis_roof` Ankaret 白色棚架屋顶花园（Guise）
- `anywhere_door_garden_sh` 任意门互动花园（期刊记未发）
- `atlas_garden_eindhoven` Atlas Garden（埃因霍温）
- `azabudai_cloud` 麻布台之云（white3）
- `baihuayuan_xinyang` 信阳百花园书屋+曲廊廊架（刘宇扬）
- `baishuidong` 白水洞村石瀑间的线性钢亭组群（有田设计）
- `baiyun_courtyard` 白云庭院（长阳路138弄，Wutopia Lab）
- `balfour_st_sydney` Balfour St（期刊记因图片拦截未发）
- `bananaleaf` 芭蕉叶亭／相关遮阳案例（china-canopy）
- `benthemplein_water_square` 鹿特丹 Benthemplein 水广场
- `berresgasse_vienna` Berresgasse（维也纳，期刊记图片曾被拦截）
- `berry_square_sydney` Berry Square（悉尼，ASPECT）
- `bishan` 新加坡碧山宏茂桥公园 / Bishan-Ang Mo Kio Park
- `blank_garden_tokyo` Blank Garden（东京，Unemori）
- `bloom_box_kunshan` 花盒咖啡（昆山）
- `bodil_koch_garden_cph` Bodil Koch's Garden（哥本哈根）
- `bojuebao_garden_cq` 博爵堡别墅庭院（重庆，MUSO 木守）
- `boundless_garden_sz` 无界 Boundless（深圳仙湖，造源）
- `breeze_hall` Breeze Hall（white3）
- `brnox_patch_brno` Brnox 街角公园（布尔诺）
- `buhuahui_huizhou` 步花洄／铁岗河驿站（大料建筑，惠州）
- `busstop_krumbach` BUS:STOP Krumbach（奥地利）
- `canal_post_hangzhou` 运河小亭驿（杭州拱宸桥）
- `caoxi_pocket_park` 上海漕溪路口袋公园（清风驿站）
- `caoyuan_hutong` 草园胡同（courtyard 早期批次）
- `carl_nielsens_alle_cph` Carl Nielsens Allé（哥本哈根）
- `cbd_rooftop_bj` 北京 CBD 屋顶花园（甲南园林）
- `chaishan` 舟山柴山岛海边长亭（GN 栖城设计）
- `changli_garden_shanghai` 昌里花园（上海，TM Studio）
- `changning_service_stations_sh` 长宁外环市民服务驿站（上海，致正）
- `changting_hangzhou` 杭州滨江公共空间·长亭驿（同济原作）
- `chashan_fu_pavilion` 松阳茶山浮亭（Studio RE+N）
- `chengdu_expo` 成都园博相关白色亭（white）
- `chenshan_quarry` 辰山矿坑花园（variety2 早期批次）
- `chun_cafe_garden_gz` 春咖啡花园（广州，batch18）
- `cloud_station_huizhou` 惠州云站（见当日摘要）
- `cloudy_mountain_cq` 云山（重庆园博园，多义景观，临时）
- `come_on_calm_on_bkk` Come on Calm on 疗愈花园（曼谷，Shma）
- `common_airea_bkk` Common Air-rea（期刊记未发）
- `cool_calm_north_london` Cool Calm（北伦敦，batch24）
- `corner_garden_shanghai` the CORNER garden（上海，VIA）
- `cuiping_wuxi` 无锡翠屏（white2；或与翡翠屏为同一/相关案）
- `dayandnight_kiosk_beijing` 日夜公园 jetlag books（三里屯）
- `daydream_xiangshan` 象山白日梦步道 / Daydream Trail
- `deck` 上海甲板花园（VIA 维亚景观）
- `den_bel_antwerp` Den Bel（期刊记因图片拦截未发）
- `dengying_yancheng` 登瀛小筑城市驿站（盐城，MUDO）
- `diagonal_house_tokyo` Diagonal House（东京，永山祐子/荻野）
- `domus_houthavens_courtyard` Domus Living Houthavens（阿姆斯特丹）
- `dongjiao_bus_stop` 东角村乡村公交站（嵛山岛）
- `dongshan_shaoye_square_guangzhou` 东山少爷南广场（广州，哲迳）
- `duisburg_nord` 北杜伊斯堡景观公园（variety2 早期批次）
- `edinburgh_raingarden_melb` Edinburgh Gardens Raingarden（墨尔本，GHD）
- `emerald_screen_wuxi` 无锡翠屏廊架 / 翡翠屏
- `engawa_house_osaka` Engawa House（大阪，nLDK）
- `erheyuan_baitasi` 二合院（白塔寺，courtyard 早期批次）
- `eyes_on_place_nanjing` Eyes on Place（南京屋顶）
- `feiying_shiyaling` 绯影驿站（Studio 10，深圳石芽岭）
- `fenggu_huizhou` 凤谷驿（见当日摘要）
- `fengmei_huizhou` 风袂驿 / Floating Canopy Grove（众建筑，惠州显岗）
- `fengxingxia_station_chengdu` 丰行侠驿站（成都）
- `fengzhiyuan_suzhou` 苏州风之园驿站（矶崎新+胡倩工作室）
- `float_flutter_flow_chaumont` Float Flutter Flow（Chaumont，batch15）
- `forest_garden_leytonstone` Forest Garden（伦敦 Leytonstone，HÛT）
- `futing` 浮亭相关（white；与茶山浮亭可能为同一方向）
- `gardenful_beijing` Gardenful（北京，TAOA）
- `gent_townhouse_garden` 根特 Garden Veerle and Rhida（Plant en Houtgoed）
- `glassfields` Glassfields（期刊记因图片拦截未发）
- `green_agora_sg` Green Agora（新加坡，Spatial Anatomy）
- `greenery_sky_garden_cq` 翠微堤别墅庭院（MUSO 木守）
- `greenhouse_kitchen_gz` 你的温室厨房（广州扉美术馆）
- `gugu_dapi` 谷谷／大埤（见当日摘要）
- `guitou_wetland` 龟头湿地（variety 早期批次）
- `guiwan_qianhai` 前海桂湾公园驿站（成行工作室）
- `h01_garden_sh` H01 花园（上海，batch18）
- `haian_lingang` 海安／临港（见当日摘要）
- `haitang_jieyou_suzhou` 海棠解忧铺（苏州）
- `haizhixu_xiangshan` 海之墟驿站（Mur Mur Lab，象山东旦）
- `harbour_kiosk_hk` Harbour Kiosk（香港）
- `hatt_street_garden` 251 Hatt Street（Dundas）
- `heguang_garden` 和光庭（上海，七月合作社）
- `heping_park_gate6_shanghai` 和平公园六号门（上海，致正）
- `hetu_luoshu_shanghai` 上海河图洛书（见摘要/早期遮阳案例）
- `hongxu_habitat_garden` 虹旭生境花园（上海长宁）
- `hook_house_habikino` Hook House（大阪羽曳野，ninkipen!）
- `hop_park_bkk` Hop Park 天桥快闪花园（曼谷，Shma）
- `house_lw27_munich` House LW27（慕尼黑，batch18）
- `house_minami_senri` House in Minami-Senri（大阪，FujiwaraMuro）
- `huangdeng_pocket_gz` 黄登口袋花园（广州，UPON）
- `hudie_hefei` 合肥蝴蝶（见当日摘要）
- `hudong_exp` 沪东实验（浦东，VIA）
- `infinite_grove_sh` 无限丛林／Infinite Grove（上海，batch15）
- `inside_the_flower_berlin` Inside the Flower（柏林 IGA，Janet Laurence 和 LAVA）
- `ishigami_water_garden` 石上纯也水庭（batch7）
- `jiezi_pavilion_yandang` 芥子亭（雁荡山）
- `jingshan_cogarden_sz` 鲸山别墅社区共建花园（深圳）
- `jingzhai_garden_nj` 静宅庭院（南京，boll是园）
- `jinji_lake_pavilion` 金鸡湖驿站（见当日摘要）
- `jinji_no1_suzhou` 金鸡湖1号驿站／小木屋
- `juanzong_bookstore_shunyi` 卷宗书店（顺义，batch24）
- `kampung_admiralty` Kampung Admiralty（variety 早期批次）
- `klee_klee_shanghai` klee klee & friends 店铺景观（上海，或然）
- `klin_mai_hom_cnx` Klin Mai Hom（清迈，batch15）
- `kraffer_garden_jindrichuv` Kraffer Community Garden（捷克）
- `lantern_garden_cd` 灯笼花园（成都，batch15）
- `lanxi_villa_garden_cq` 华侨城岚溪云墅素园（重庆，木守）
- `laoyuting` 捞鱼亭 / Laoyuting Pavilion（大舍）
- `leaf_structure_dallas` Leaf Structure（达拉斯植物园，Legge Lewis Legge）
- `leaf_vein_garden_nanping` 叶脉花园（建瓯，大小景观）
- `leuven_kw_garden` 鲁汶 Garden Kathleen and Wim（Plant en Houtgoed）
- `leuven_townhouse_garden` 鲁汶联排后院 Garden Dorien and Pierre-Yves
- `leyi_habitat_garden` 乐颐生境花园（上海长宁）
- `liangjiang_xinchen_garden_cq` 两江新宸别墅庭院（MUSO 木守）
- `lingjing_pocket_park` 灵境胡同地铁口口袋公园
- `linping` 临平相关遮阳案例（china-canopy）
- `london_woodland_garden` 伦敦小林地花园（Alasdair Cameron）
- `long_heal_bkk` LongiPark Long Heal（曼谷，Shma，临时）
- `longan_tree_yard_qz` 龙眼树院（batch18）
- `longcheng` 龙城相关遮阳案例（china-canopy）
- `longjing_tea_pavilion` 龙井茶亭（见当日摘要）
- `longnan_waiting` 陇南等待亭（见当日摘要）
- `longqiyuan_pavilion` 龙圻园亭（见当日摘要）
- `luwan_waterbird_park` 渌湾水鸟公园（batch7）
- `luxun_coffee_shed` 上海鲁迅公园咖啡亭
- `manyuan_beijing` 满园（北京，TAOA）
- `matrix_garden_sg` The Matrix Garden（新加坡，Sanitas Studio）
- `meiso_ito` Meiso no Mori / Ito（white2）
- `meiyuan_cafe_sh` 梅园咖啡花园（上海，batch18）
- `membrane_roof_house_tokyo` House with Membrane Roof（东京，期刊记未发）
- `minami_machi_house_matsuyama` House in Minami-machi（松山，Jun Yamaguchi + Chiba Plantation）
- `moonlight_pavilion` 广州大金钟公园·月影亭
- `nanyuan_roof_garden_sz` 南园绿云屋顶共建花园（深圳，一十一建筑）
- `naoshima_sanaa` 直岛 SANAA（white2）
- `nature_blessings_house_aichi` 受到自然祝福的住宅（爱知，TSC）
- `nine_square_wuxi` 无锡九宫亭（见当日摘要）
- `nuanting_pavilion` 暖亭（浦东向东社区之家，VIA）
- `ny_ostergade_rooftop` Ny Østergade 屋顶花园（哥本哈根）
- `o_building_kichijoji` O_building（东京吉祥寺）
- `oishii_park_shingu` Oishii 公园（新宫，td-Atelier）
- `olympic_sculpture_park` 西雅图奥林匹克雕塑公园 / Olympic Sculpture Park
- `ouyang_pocketpark` 欧阳路祥德路转角口袋公园（山水秀）
- `paley_park` 佩雷公园 Paley Park（variety 早期批次）
- `peabody_plaza_nashville` Peabody Plaza（纳什维尔）
- `penguin_garden_shekou` 企鹅花园（深圳蛇口）
- `piazza_matteotti_gardens` 马特奥蒂广场公共花园（意大利，Pool）
- `piloti_bellevue` Piloti Bellevue（white2）
- `pingshan_kids` 坪山儿童游乐（variety 早期批次）
- `pk_house_bkk` PK House（曼谷，batch18）
- `pocket_campus_bernini_turin` Pocket Campus Bernini（都灵，期刊记图片曾被拦截）
- `praca_da_arvore_recife` Praça da Árvore（累西腓）
- `qh_urban_jungle_berlin` QH Straight Urban Jungle（柏林）
- `qijiang_park` 歧江公园（variety2 早期批次）
- `quantum_pocketpark_cq` 高新量子口袋公园（重庆，10Design）
- `qunli` 哈尔滨群力国家城市湿地公园
- `resilience_garden_seoul` Resilience Garden（首尔，batch15）
- `sanaa_serpentine2009` SERPENTINE 2009（SANAA，structures 早期批次）
- `santing_garden` 三亭园（北京，水行设计）
- `serpentine2013` Serpentine 2013（white3）
- `shadowplay_phoenix` Shadowplay Phoenix（white）
- `shengjing_dongan_sh` 生境东岸（上海）
- `shenyang_jianzhu_rice` 沈阳建筑大学稻田校园（variety2 早期批次）
- `sheyun_tengchong` 摄云（腾冲，white3）
- `shiguang_buyu_nanjing` 时光补语（南京，batch24）
- `shiguang_jiaxing` 时光（嘉兴，courtyard 早期批次）
- `shuju_shanghai` 「树」居（上海，大海小燕）
- `sikbang_maru_seoul` Sikbang Maru Pavilion（期刊记未发）
- `siu_kai_fong_hk` 小街坊 Siu Kai Fong（临时展，期刊记未发）
- `skyline_garden_cq` 天樾私人住宅花园（MUSO 木守）
- `southwood_avenue_garden` 北伦敦三角形小花园（Stefano Marinaz）
- `starfire` 深圳大鹏新区星火探索营廊架（厘米制造）
- `suan_san_bkk` Suan San 口袋公园（曼谷，Shma）
- `superkilen` 哥本哈根 SuperKilen 超级线性公园
- `swirl_garden_sz` 漩花园（深圳，大小营造）
- `szplan_canopy` 深圳规划相关棚（white3）
- `taixing_canopy` 泰兴运河畔「大船篷／大茶棚」
- `taizhou_forest_box` 台州森林盒子（batch7）
- `tank_shanghai` 上海油罐艺术中心（variety2 早期批次）
- `taohuayuan_zen` 桃花源（courtyard 早期批次）
- `tapestry_urban_greenery` A Tapestry of Urban Greenery（Stefano Marinaz）
- `terrazza_biandra_milan` Terrazza Biandrà（米兰）
- `tianrang_yunying_sz` 天壤云影（深圳）
- `tofukuji_hojo` 东福寺方丈庭园（courtyard 早期批次）
- `triangle_park_cambridge` Triangle Park（剑桥，Stoss）
- `tsuboniwa_retreat_london` Tsuboniwa Retreat（伦敦，batch24）
- `udaan_park_udaipur` Udaan Park（乌代浦）
- `unemori_houses_tokyo` Unemori Houses（东京，batch24）
- `velez_malaga_viewpoint_garden` 韦莱斯-马拉加城堡观景花园（西班牙）
- `vietnam_memorial` 越战纪念碑（variety2 早期批次）
- `wangshan_huzhou` 望山（湖州，white2）
- `wastefree_ecoisland_sz` 无废智能生态岛（深圳）
- `wat_hua_lamphong_bkk` 华南蓬寺 Rukkhaniwet 公园（曼谷，Shma）
- `wave_garden_sz` 浪花园（深圳，大小景观）
- `west_london_corner_garden` 西伦敦转角花园（Stefano Marinaz）
- `westmoreland_dallas` 达拉斯 Westmoreland Park Pavilion
- `white_sheet_tallinn` 「一页白纸」阅读亭（塔林，Ninja Stuudio）
- `white_tangram_entrance` 白色七巧板（华东师大一村入口）
- `wildlings_logrono` Wildlings（洛格罗尼奥临时装置，期刊记未发）
- `wuhan_fenghuang` 武汉凤凰（white）
- `wutong` 梧桐亭，深圳（悉地国际东西影工作室）
- `wuxi_changan_station` 无锡惠山长安市民广场驿站（灰空间）
- `xiaoliangtan_garden_chengdu` 小亮滩花园（成都，West 8）
- `xinchang_back_garden_sh` 新场古镇后花园（上海，UDG）
- `xinhua_mirror_garden` 新华路∞花园口袋公园
- `xinhua_rd_pocketpark` xinhua rd pocketpark
- `xinyang_pergola` 信阳廊架（structures 早期批次）
- `xuanting_shenzhen` 轩亭（深圳，structures 早期批次）
- `yangpu_riverside` 杨浦滨江（variety 早期批次）
- `yanweizhou` 雁尾洲公园（variety 早期批次）
- `yiye_tea_pavilion` 一叶茶亭（structures 早期批次）
- `yongjia_rd_pocketplaza` 永嘉路口袋广场（阿科米星）
- `youmu_tea_pavilion` 攸牧茶亭（见当日摘要）
- `yuandang_canopy` 元荡棚（white2）
- `yuanyuan_garden_sz` 缘圆园（深圳蔚蓝海岸社区）
- `yuniao_membrane_canopy` 玉鸟集食集膜顶棚（良渚）
- `yunlu_stargazing` 云麓观星（structures 早期批次）
- `yunzhiyuan` 云之园（white）
- `z_house_pinggu` Z宅（平谷，Y+Y）
- `zhangjiagang_bus_stop` 张家港高铁新城公交站台
- `zhaomushan_villa_garden_cq` 照母山天玺别墅南岑（重庆，木守）
- `zhezhe_pavilion_hangzhou` 运河褶褶亭
- `zhezhi_ciqikou` 折纸轻亭／磁器口东门驿站（悦集，重庆）
- `zhiyuanwu` 知园坞相关遮阳案例（china-canopy）

## 未打包的本地材料（有意排除）

- `/workspace/landscape/**/cand/` 候选下载图（海量未精选，约数 GB），未打包。
- 谷德/ArchDaily 等完整 HTML 抓取页（常含设计师邮箱、招聘广告等无关个人信息），未打包。
- `contact.jpg`、`_contact*.jpg`、`sheet_*.jpg`、`final_*.jpg` 等联系页或拼图联系表，默认未作为案例配图打包。
- `/workspace/daily/` 等其他 bot 的考研理论日推图，不是本 bot 的项目推荐，未打包。
- `/workspace/manduhai/`、思想讲解案例（煤气厂公园、波特兰序列等，属其他交接任务），未当作本 bot 推荐包。
- X 帖改写稿（`/workspace/xpost/`）是队友改写，不是本 bot 当时原文，未打包。
- 源目录本身未删除、未修改。

## 原文回读进度（续）

已从父会话导出中写入当时原文的项目，见各目录 `texts/original-*`。检索结果带省略号的条目（如金鸡湖 1 号驿站、蝴蝶驿站、Forest Garden、251 Hatt Street 所在批次的合并长文、Gardenful 补图更正等）**未当作原文**，仍待父会话补页。

第 8 批各案的发出正文不在 361–419 页内（仅有发送回执），仍缺逐字 SendToUser 参数。

未推候选已不在主清单，见 `appendix-candidates/`。

## 原文回读结果（0–1299）

已确认发出的原文按日期收入 `sent-originals-by-date/`，并在能唯一匹配时写入对应项目 `texts/original-SendToUser-*`。

主清单仍缺原文的项目见 `01-INDEX.md` 备注列「缺原文」——未编造。JSON 缺口见 `04-COVERAGE.md`。

公开包仅保留已发出的案例原文、批次说明，以及直接有助理解案例的技术/施工说明。个人委托图纸、整理过程与私人对话未纳入。

关于 Superkilen 白色折板遮阳棚无公开施工图的说明，已收入 `sent-originals-by-date/`（技术说明）。

## 主清单仍缺发出原文的 25 项（未编造）

这些项目在本地有精选配图（部分另有内部摘要，未纳入公开包），但在父会话 positions 0–1299 已确认的 SendToUser 中没有对应逐字推荐正文。其日期（如 10-18、10-24、10-25 部分日推、10-26、11-01、11-02、11-08 部分、11-09、11-10、11-11）当天或无本会话 SendToUser，或只见日目录/内部摘要（未纳入公开包）。未用摘要冒充原文。

buhuahui_huizhou, caoxi_pocket_park, chaishan, changting_hangzhou, cloud_station_huizhou, daydream_xiangshan, feiying_shiyaling, fenggu_huizhou, fengzhiyuan_suzhou, gugu_dapi, guiwan_qianhai, haian_lingang, hudie_hefei, ishigami_water_garden, jinji_lake_pavilion, jinji_no1_suzhou, juanzong_bookstore_shunyi, longjing_tea_pavilion, longnan_waiting, longqiyuan_pavilion, luwan_waterbird_park, luxun_coffee_shed, taixing_canopy, taizhou_forest_box, zhezhi_ciqikou
