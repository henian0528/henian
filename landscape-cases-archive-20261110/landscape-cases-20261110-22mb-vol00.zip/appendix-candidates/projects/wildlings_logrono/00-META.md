# Wildlings（洛格罗尼奥临时装置，期刊记未发）

- 归档编号：`wildlings_logrono`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：0 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch13`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wildlings_logrono_1.jpg` | `41aa498bae318ded30f964ce8979b6b9507f23319f116fbadd2db4027a4a6a34` | 248031 | 否 | `/workspace/landscape/batch13/wildlings_logrono_1.jpg` |
| `wildlings_logrono_2.jpg` | `84d56607722923e658a26cafca4c250da7ac8360460a327a1f18b774c77cdbc8` | 212848 | 否 | `/workspace/landscape/batch13/wildlings_logrono_2.jpg` |
| `wildlings_logrono_3.jpg` | `dda0665cb71590e729a6813fa294bb70f38236cdc921c0ea6d24d3d5f589cd4d` | 281399 | 否 | `/workspace/landscape/batch13/wildlings_logrono_3.jpg` |
| `wildlings_logrono_4.jpg` | `a4f7179d05fad83d4ceabeb3a1337c0fba566419550ce60553610ffb5ad0fcfc` | 257487 | 否 | `/workspace/landscape/batch13/wildlings_logrono_4.jpg` |
| `wildlings_logrono_5.jpg` | `d1e0b4eae76613b94193633df5ac2e4f0229bc690f4cbcf323b93e67af75bf86` | 226046 | 否 | `/workspace/landscape/batch13/wildlings_logrono_5.jpg` |
| `wildlings_logrono_6.jpg` | `3a47bc226c8bd98e6a727e4f7c6fe324f53a0a24ee348a1e0d8719e00af2f424` | 448617 | 否 | `/workspace/landscape/batch13/wildlings_logrono_6.jpg` |
| `wildlings_logrono_7.jpg` | `b082f4492392e55f18c4f117a8abac452784282ab7d8278f72e9e80a01de0235` | 273799 | 否 | `/workspace/landscape/batch13/wildlings_logrono_7.jpg` |
| `wildlings_logrono_8.jpg` | `9bb9fa38242c7b86eabf9eb1251b76db0d04c9bef1fcbee159b480b5571143d9` | 276897 | 否 | `/workspace/landscape/batch13/wildlings_logrono_8.jpg` |
