# Common Air-rea（期刊记未发）

- 归档编号：`common_airea_bkk`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：0 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch14`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `common_airea_bkk_1.jpg` | `8fd13a142fa7f42a49a3f6c356480ad71640495f5b0fbe726ccc1959899ccb6f` | 380438 | 否 | `/workspace/landscape/batch14/common_airea_bkk_1.jpg` |
| `common_airea_bkk_2.jpg` | `90a8833e7bc95d1bf8c430445ddfb8865a5b67448deb28b0f7dd51c97bff27ba` | 174937 | 否 | `/workspace/landscape/batch14/common_airea_bkk_2.jpg` |
| `common_airea_bkk_3.jpg` | `793f6ac8fbefb9d00b5a47a9a33cba14250bc9f56a1d1336fceaffebe8f111a7` | 193374 | 否 | `/workspace/landscape/batch14/common_airea_bkk_3.jpg` |
| `common_airea_bkk_4.jpg` | `3f90098d0c660b5caaa371dfaf1993087f5e54da469fb8180d6929ec0bfe8b03` | 156307 | 否 | `/workspace/landscape/batch14/common_airea_bkk_4.jpg` |
| `common_airea_bkk_5.jpg` | `bebee953c1bdfe47844d828fa3b343c2fac2f9a00acf80ab61d69cd3feadf011` | 139329 | 否 | `/workspace/landscape/batch14/common_airea_bkk_5.jpg` |
| `common_airea_bkk_6.jpg` | `40831532115d5d1d52a61052c32d7174a62179fcc617a557365873f43ddd670b` | 64161 | 否 | `/workspace/landscape/batch14/common_airea_bkk_6.jpg` |
| `common_airea_bkk_7.jpg` | `068f8f0028e78258e872548a5800b32dd6778e853ad20bed4de688471221b169` | 57670 | 否 | `/workspace/landscape/batch14/common_airea_bkk_7.jpg` |
