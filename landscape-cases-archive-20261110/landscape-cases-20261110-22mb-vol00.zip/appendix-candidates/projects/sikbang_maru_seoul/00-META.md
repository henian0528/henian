# Sikbang Maru Pavilion（期刊记未发）

- 归档编号：`sikbang_maru_seoul`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：0 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch17`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `sikbang_maru_seoul_1.jpg` | `e67da9714b6865f42f87a8d8acb958d51daccdd31144e8a734b2870bc6fe4d03` | 534403 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_1.jpg` |
| `sikbang_maru_seoul_2.jpg` | `4eaf36311f09ba8b4071e61f175f33b0235c4d373339f96c68cb0ff622b0946b` | 393952 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_2.jpg` |
| `sikbang_maru_seoul_3.jpg` | `1eabafc723f35fed0a1b38ab499155981eae17b9c2b6904975478d15d3e2228e` | 455749 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_3.jpg` |
| `sikbang_maru_seoul_4.jpg` | `5d2bea8700b6e2fb516649868431bcd697bd83ab870749fe3e269673e7e26e51` | 419150 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_4.jpg` |
| `sikbang_maru_seoul_5.jpg` | `415feb718ba2e25cfcf05cb04711b47e748a981d9600ded4bdeb193a493c94cf` | 350873 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_5.jpg` |
| `sikbang_maru_seoul_6.jpg` | `fd4152448f246c1efce47199ee4d36ce9c9e0edace257b8e8eadd45ba87249f6` | 152388 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_6.jpg` |
| `sikbang_maru_seoul_7.jpg` | `22fc5b8ecf859495a3650fde5f117c1cfb877164833083dd079efa8ffad4de0e` | 156264 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_7.jpg` |
| `sikbang_maru_seoul_8.jpg` | `742357e40963e6063f8fbef83e056ef28c96f849f32236268a6e4f6a385f40ba` | 291655 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_8.jpg` |
| `sikbang_maru_seoul_9.jpg` | `20c684b8333c8bf2eb3bb647c4406a0dfab575f95b80dd3489d3f01542c13685` | 270207 | 否 | `/workspace/landscape/batch17/sikbang_maru_seoul_9.jpg` |
