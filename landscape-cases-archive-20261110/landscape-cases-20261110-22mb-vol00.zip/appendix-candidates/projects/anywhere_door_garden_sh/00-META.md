# 任意门互动花园（期刊记未发）

- 归档编号：`anywhere_door_garden_sh`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：0 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch16`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `anywhere_door_garden_sh_1.jpg` | `aee8854ce4d79e2f2af90ce9526b12f34621dcdd65760e0b0c4f1369cf05d9b7` | 328684 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_1.jpg` |
| `anywhere_door_garden_sh_2.jpg` | `5781782fdcdfe1ad3d59f6d838e2887cbd64d9b68865b07ad50921f0dabc39d8` | 588217 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_2.jpg` |
| `anywhere_door_garden_sh_3.jpg` | `e8c01991afd3581e5b789ac982f4b7aa0de90519a4ba4e388066c93f26dd12cd` | 378319 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_3.jpg` |
| `anywhere_door_garden_sh_4.jpg` | `2f4d153bfbf1c9210a8a03e455baa8f26bc31f68dfbd959924f1e7cad896dc2c` | 333583 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_4.jpg` |
| `anywhere_door_garden_sh_5.jpg` | `70a2845528e3103448319ec812d5377e7c0e86f1a6e4805dd92b494811995f34` | 269297 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_5.jpg` |
| `anywhere_door_garden_sh_6.jpg` | `14bd12156f7a5046b5fcb2a34781db99dc5369b4ab9c779c86f84249957cc03b` | 382325 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_6.jpg` |
| `anywhere_door_garden_sh_7.jpg` | `3800925b44f8c883c23c5e7e7cbe1cccf8237d9e90bb47b28635b55b4c84548c` | 519291 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_7.jpg` |
| `anywhere_door_garden_sh_8.jpg` | `dcac1869e8094832cc9fa2d1f3efbf643847daba2a838e5569825fbfe40b3893` | 291899 | 否 | `/workspace/landscape/batch16/anywhere_door_garden_sh_8.jpg` |
