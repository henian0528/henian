# 小街坊 Siu Kai Fong（临时展，期刊记未发）

- 归档编号：`siu_kai_fong_hk`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `siu_kai_fong_hk_1.jpg` | `8aac0c2b795f8f42c2eac2f831972b24bdf0b99bef0f0f3d7b84a894568ed200` | 235171 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_1.jpg` |
| `siu_kai_fong_hk_10.jpg` | `db069a95f5b0ee26722e13adcaff6f33c864b702e09abf75082c3526fa8e4256` | 77276 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_10.jpg` |
| `siu_kai_fong_hk_2.jpg` | `4f0c1d8a9e86533bf7dd0cb96853e1aa9d596c0313f1648ef82161c079610929` | 245564 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_2.jpg` |
| `siu_kai_fong_hk_3.jpg` | `ced34e82c91e8296bc5dc90b68f1b361122ee843cf48c563241ef7a89fd2697a` | 237866 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_3.jpg` |
| `siu_kai_fong_hk_4.jpg` | `8d0385ffb2f404eb66a4a1c0c4e8716cd2262c0186acb2f0d85879bc2d7c1924` | 207062 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_4.jpg` |
| `siu_kai_fong_hk_5.jpg` | `9424a6038412bbb0fe3e8bf89851decf429861e16d574e11159db8f0621f009b` | 179994 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_5.jpg` |
| `siu_kai_fong_hk_6.jpg` | `fc6de4365c43929edc1f1de3a802b8540f8e812e7c0adc56d951ef35c8e64546` | 217353 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_6.jpg` |
| `siu_kai_fong_hk_7.jpg` | `75141e086cf6a8d97a602eecc44b868c5711e253959535fdea2e24d950c6db55` | 197247 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_7.jpg` |
| `siu_kai_fong_hk_8.jpg` | `c53a5491237bddffe278b2f43051f0d120832a219b14bb058ffeeb1d91ce8a4a` | 137444 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_8.jpg` |
| `siu_kai_fong_hk_9.jpg` | `e9dba14de583db4694bcb72d67368664b0e8bb02a5bcfabdd6d56c1bc9b9d880` | 188974 | 否 | `/workspace/landscape/batch12/siu_kai_fong_hk_9.jpg` |
