# House with Membrane Roof（东京，期刊记未发）

- 归档编号：`membrane_roof_house_tokyo`
- 推荐状态（汇总）：`not_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：0 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`not_sent`
  - 本地来源：`/workspace/landscape/batch21`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `membrane_roof_house_tokyo_1.jpg` | `f23b68e97012c8003614162b6a433bf891e17ad2a8b087e60be3c83b772da026` | 672512 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_1.jpg` |
| `membrane_roof_house_tokyo_2.jpg` | `ec6cc9f7f6d2a851d6090991467790286044f962f84b1755d7ff43a3d498b3f7` | 679577 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_2.jpg` |
| `membrane_roof_house_tokyo_3.jpg` | `2b652aa2d8a5418055462a2cd89979375193f44fbaddd2d34d251be283e64191` | 649280 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_3.jpg` |
| `membrane_roof_house_tokyo_4.jpg` | `e60d32f8d2731d0fa2ef702d32b186d936335ceb6156cc1667fa0cec9e657fb7` | 580371 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_4.jpg` |
| `membrane_roof_house_tokyo_5.jpg` | `f1f02f55a342532015dc8c43827a79ec9e4e4a6e902f659b603c077b70fb6c3b` | 362412 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_5.jpg` |
| `membrane_roof_house_tokyo_6.jpg` | `be90bf37c5e71abb7f0b75cfcd9187f83ef9bf01e6fb5d46722cd7c13ffb81b9` | 273217 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_6.jpg` |
| `membrane_roof_house_tokyo_7.jpg` | `b4352557dcdb4e174f4ab45876ea2c2bdce8520e2ed31916bfdaaf8ae2f9480c` | 134578 | 否 | `/workspace/landscape/batch21/membrane_roof_house_tokyo_7.jpg` |
