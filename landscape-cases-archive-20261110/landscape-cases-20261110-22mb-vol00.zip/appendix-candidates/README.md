# 附录：未确认 / 未推送候选（不计入主已推荐清单）

以下项目在本地有精选配图，但期刊明确记载当时未发，且本轮已回读的发出原文中未见补发。它们不是「已推荐」项目，仅作候选附件备查。图片保持原样，未改写。

曾被同一批准备、后来以「补发」形式发出的 Den Bell、Balfour Street、Glassfields 已留在主清单，不在本附录。

- `siu_kai_fong_hk`
- `wildlings_logrono`
- `common_airea_bkk`
- `anywhere_door_garden_sh`
- `sikbang_maru_seoul`
- `membrane_roof_house_tokyo`
