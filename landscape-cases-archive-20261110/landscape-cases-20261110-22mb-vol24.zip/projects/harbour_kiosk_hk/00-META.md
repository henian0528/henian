# Harbour Kiosk（香港）

- 归档编号：`harbour_kiosk_hk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `harbour_kiosk_hk_1.jpg` | `0c891a2b786c635fd7db22b8e4375611cf7e0deaeadb4f98b1a5f9c8d2b56849` | 319093 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_1.jpg` |
| `harbour_kiosk_hk_10.jpg` | `bac1c668c74fd81963a756e375f4db4672ad4a3b8a7f99f81f0951b24431b634` | 398806 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_10.jpg` |
| `harbour_kiosk_hk_2.jpg` | `c973cc62892c10f557664afa4942f1c40f9f0bfbec6bc7d63d7ceb61b6421a66` | 378652 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_2.jpg` |
| `harbour_kiosk_hk_3.jpg` | `7a8d9269ee71a001893475383ddcf053b36b0a28dd86bd24ca9d5089b5bc142a` | 383433 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_3.jpg` |
| `harbour_kiosk_hk_4.jpg` | `e8de1e9ce4308417f1892afff612ea4761598d2efb488a712d20f3f7e3e32199` | 356352 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_4.jpg` |
| `harbour_kiosk_hk_5.jpg` | `1c5030074a273a9695f17acf571ac85aab0e5cdc6469c00a952a13a2699155fd` | 413345 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_5.jpg` |
| `harbour_kiosk_hk_6.jpg` | `b1182a9897c71efe95e0bd99016c8ba926f8072769845d0cd0832393368f40e9` | 462993 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_6.jpg` |
| `harbour_kiosk_hk_7.jpg` | `3ff4019e56a9aeb8be1e4e4d2dd54db637e076695333e5c380fc32345df1f7eb` | 626329 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_7.jpg` |
| `harbour_kiosk_hk_8.jpg` | `e4949c3a5606cf9083e0fad79c58e6b1b4fcc1250eb1d92a9da0c46c6589a127` | 384668 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_8.jpg` |
| `harbour_kiosk_hk_9.jpg` | `f4198ada5172de4ee6d6a11b98b489acdfc7a67cf64f4d7b00482d919195cf46` | 247329 | 是 | `/workspace/landscape/batch9/harbour_kiosk_hk_9.jpg` |
