# 海棠解忧铺（苏州）

- 归档编号：`haitang_jieyou_suzhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `haitang_jieyou_suzhou_1.jpg` | `de0a0e4dde10ae29a12cb5707f496ac8852d77415b6fb352db50d9e77ec6bd24` | 240250 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_1.jpg` |
| `haitang_jieyou_suzhou_10.jpg` | `77c522297e45445d63fe4657f15356a8dbec60576ab426cb6091532215dad610` | 70313 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_10.jpg` |
| `haitang_jieyou_suzhou_2.jpg` | `70adbbea5c6d16aaf49e86897d1cd6f80bfa1d35119efb57b342cf7faa6d2f60` | 346199 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_2.jpg` |
| `haitang_jieyou_suzhou_3.jpg` | `9df526806dbc60a72fa130f5dd1aac5e44a1b367625df9ae3ddcc20d00c0657e` | 226871 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_3.jpg` |
| `haitang_jieyou_suzhou_4.jpg` | `bc1ba68b9743a5a705362352e2f5fd5751617105a8b3650206431758b6182768` | 252544 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_4.jpg` |
| `haitang_jieyou_suzhou_5.jpg` | `3bddea0b682d207b62cf18a6e3ad27e3d76d2a6e8462eb94c57b515c6b371862` | 218796 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_5.jpg` |
| `haitang_jieyou_suzhou_6.jpg` | `98e8726f6711930dda7f9e1f6eee304142a6184356dc015b15633a689352bf77` | 186042 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_6.jpg` |
| `haitang_jieyou_suzhou_7.jpg` | `f16d430cd0e2714785c272bfd100b055febdb254cb1494ae0871874b451d046a` | 253800 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_7.jpg` |
| `haitang_jieyou_suzhou_8.jpg` | `afd1351c189321402e3d15872ee5be3e16ba442332767981357bc4f3ae8e53b5` | 232046 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_8.jpg` |
| `haitang_jieyou_suzhou_9.jpg` | `4137d9b5e70b4d7ff6577c64d33b271077f08ec14d478811cfea368f59cfa07d` | 59884 | 是 | `/workspace/landscape/batch8/haitang_jieyou_suzhou_9.jpg` |
