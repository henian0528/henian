# 海之墟驿站（象山东旦，Mur Mur Lab）

- 归档编号：`haizhixu_xiangshan`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-09
  - 出处说明：日期目录 2026-11-09（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-09/haizhixu_xiangshan`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hz_01_photo_aerial.jpg` | `2c911d7d7f64c46c101d14ea61fa57b7af62fd496c0823074d2ba2d91af6a3fa` | 799583 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_01_photo_aerial.jpg` |
| `hz_02_photo_distant.jpg` | `96ed21905725534aed7f0cf797519b240f96cbd06bb50ba7697ffd3b7f5d2a5e` | 475098 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_02_photo_distant.jpg` |
| `hz_03_photo_hills.jpg` | `cbe88cf10967dc2534eeebe5634643b66a0bece9b8b07b87d970f362da7d32bf` | 452372 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_03_photo_hills.jpg` |
| `hz_04_photo_aerial2.jpg` | `17cdfcbc6518684e2960882176181ba3da90e0c1925d78d1fe4f52a7ad0c6010` | 563228 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_04_photo_aerial2.jpg` |
| `hz_05_photo_facade.jpg` | `3b227415278030fc841101a2177630bac2dc517a4adb72c538ccc5a18a382c27` | 672180 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_05_photo_facade.jpg` |
| `hz_06_photo_roof.jpg` | `6dfb82d93eddd6762edf278f80443719678965c118ce2f5390600b8c08c90e63` | 807694 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_06_photo_roof.jpg` |
| `hz_07_photo_night.jpg` | `5c34c423e5cc6389acbcd575ba63222f76609cd560b43d196a2a691dd9e19a9a` | 460467 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_07_photo_night.jpg` |
| `hz_08_drawing_siteplan.jpg` | `aaa9da68f666b62bb67f829cf4a35ca09cbb5846e48d24665093f12b51d1366a` | 262649 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_08_drawing_siteplan.jpg` |
| `hz_09_drawing_plan.jpg` | `48df9736969da34d23b5f4290e6e5d5710b8478a23bbf928d9732c89b4dddb18` | 138513 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_09_drawing_plan.jpg` |
| `hz_10_drawing_section.jpg` | `0cf153ba10c2c0ae0e2c3c8011405ff244425ac111b9e07f8d86315b43f830f7` | 65280 | 是 | `/workspace/landscape/2026-11-09/haizhixu_xiangshan/hz_10_drawing_section.jpg` |
