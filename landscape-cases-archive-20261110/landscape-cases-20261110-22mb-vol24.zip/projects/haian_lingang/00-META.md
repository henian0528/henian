# 上海临港「海岸生态驿站」（HCCH 合尘建筑）

- 归档编号：`haian_lingang`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-02
  - 出处说明：日期目录 2026-11-02（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-02/haian_lingang`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ha_01_photo_aerial_three.jpg` | `3b0c44351068f6d4f3369d0cdae54f7e745a59247020e51baa52da627932928e` | 753339 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_01_photo_aerial_three.jpg` |
| `ha_02_photo_snail_aerial.jpg` | `579c266fa1bb7ab036bc66d54fa222bb2757214ebfb7d3d0e4be2571283e27a1` | 800708 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_02_photo_snail_aerial.jpg` |
| `ha_03_photo_snail.jpg` | `994419f27f8dc8b322cd1cc1798e12c273b2c63380b10f0507b9f972041dbbdb` | 473743 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_03_photo_snail.jpg` |
| `ha_04_photo_membrane.jpg` | `3ca7859cadd04f837e27b52a3b10c888e3088eb6a81db3addbb8819297eaac79` | 471581 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_04_photo_membrane.jpg` |
| `ha_05_photo_snail_interior.jpg` | `4d692ff3b877de94c01d3e28755cf9ee8a917c4a0037acfd7345511663801dfc` | 427167 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_05_photo_snail_interior.jpg` |
| `ha_06_photo_membrane_detail.jpg` | `db253a7491e3bc726b76ef6aa6226b69cadbf363d39754b823f6dd56826e7f54` | 329185 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_06_photo_membrane_detail.jpg` |
| `ha_07_photo_wave_units.jpg` | `649b0e4e159311782d0163b96aaf081c62057d53f54a1dccbc769f885249e515` | 260199 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_07_photo_wave_units.jpg` |
| `ha_08_photo_coral_aerial.jpg` | `5185bc724e6e30993631c22abc6871b68d34432ad786f46b58766f851eb90df8` | 784160 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_08_photo_coral_aerial.jpg` |
| `ha_09_drawing_location.jpg` | `d227bf0c6096746ff3751aa1bca5c53582f788f4347a07354a50c58997ae687b` | 345103 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_09_drawing_location.jpg` |
| `ha_10_drawing_axon.jpg` | `07be23905cad5da1dbc92f06dd8d4e591d400e8b9483dce75135a9a263150545` | 953703 | 否 | `/workspace/landscape/2026-11-02/haian_lingang/ha_10_drawing_axon.jpg` |
