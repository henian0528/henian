# 苏州金鸡驿（金鸡湖亭）

- 归档编号：`jinji_lake_pavilion`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：36
- 在 bot 附件库中匹配到的配图：0 / 36（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-25
  - 出处说明：日期目录 2026-10-25（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-25/jinji_lake_pavilion`
  - 注：项目子目录精选图
  - 本记录配图文件数：36

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `_raw_000.jpg` | `4de4ecdbe6ee1a56e18e1a07e3505a096c2100ccf6cedc27ac1bc8586439f6d6` | 157124 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_000.jpg` |
| `_raw_001.jpg` | `52cd855d5422c293bacaadbb8fc8e4725c629e6e81e0d6533ba001f7c8247d41` | 581026 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_001.jpg` |
| `_raw_002.jpg` | `64e6b629660d137339a7bf84ec90dc671f1b9627d320d7fa4420a14bd5c78bc7` | 768026 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_002.jpg` |
| `_raw_003.jpg` | `b6167d1495f4ae8a9695fc3885d6e6332362c39ffce94e0c414c2e5de4cd1768` | 735283 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_003.jpg` |
| `_raw_004.jpg` | `3994de9f037ee90b984c5e2ca8734aef5c89d1c11c448fb4262a4bd0201cf84d` | 527750 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_004.jpg` |
| `_raw_005.jpg` | `2a4bd364e3e8ee5d8600ccba62bee4ebc17ff24ea1ae48be3774035c2bded36a` | 528324 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_005.jpg` |
| `_raw_006.jpg` | `10d750c8e9acbc3ff3b8cb0572df955d62106d8d1a3207f48b9a03cdb7f5b35e` | 657236 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_006.jpg` |
| `_raw_007.jpg` | `eea0abcbec987ce179927e4776712262da4dc42df4469f9d7c031f52645cd172` | 518506 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_007.jpg` |
| `_raw_008.jpg` | `e407aa29a09ccee5eee0f9e328c91fcbd3a59c0a18c7d9eefa26504f546ac228` | 625110 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_008.jpg` |
| `_raw_009.jpg` | `fc5109d6f1249680fe06325dc661e6cf9da03559db7fd1d7535170f201a0f6a1` | 537337 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_009.jpg` |
| `_raw_010.jpg` | `db6b8195e8df5dfb28ab8fa19b3da30e2ebb5adb50498826c58473245e12a91a` | 758843 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_010.jpg` |
| `_raw_011.jpg` | `60b9eadf9f95b69ca58383bfa6a6a521c7b25ee92564f888ed76848cfd54b957` | 727508 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_011.jpg` |
| `_raw_012.jpg` | `09f77c525a49e2c8ed3f8f03cde9af9f61c6b1cd0bbdd1f562a3931ebe779591` | 479283 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_012.jpg` |
| `_raw_013.jpg` | `e5d97ae923f5f4dc6670d8a392edc134c3eb2ebd6e3485137f13cf441c5e38d0` | 492127 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_013.jpg` |
| `_raw_014.jpg` | `6efc13c89684dffc9d567dd01d2b5717a560818d3378aefddeba3d51796300d2` | 333146 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_014.jpg` |
| `_raw_015.jpg` | `62f26a2e075e631a8864b1afe90979dd71a791a6aea449f40cd9434bc50fbf81` | 584456 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_015.jpg` |
| `_raw_016.jpg` | `e5d5d469d473c7490b13dd88b3920a2b7420c54f745717eb162b33b5edb69ac5` | 586554 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_016.jpg` |
| `_raw_017.jpg` | `3e77ad3ca4a4178cea47fc3c7774f11ca60991892ac61fc0edcb3eece5b5009c` | 649119 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_017.jpg` |
| `_raw_018.jpg` | `8c19781bc70ff93bcdfc73b3c951cc5466c287e63f469d2ba0a4541dbbafb890` | 699737 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_018.jpg` |
| `_raw_019.jpg` | `169b4243021d13b8d2fece2a8b048b38dcac7371cfe401b5b99f42cd34ca9127` | 485212 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_019.jpg` |
| `_raw_020.jpg` | `6a2c15483a7fc645cc0832d2f62825907d5ce2d69299fc2125877903894567a9` | 92104 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_020.jpg` |
| `_raw_021.jpg` | `2193501ab30ae80a17bacf6683cc956e515a9431058e4d090890b04065f67fbe` | 82796 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_021.jpg` |
| `_raw_022.jpg` | `12b227079da3a38b6071e969e23b7bb539bbebbb0e7241bf2952438f516d34d5` | 80552 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_022.jpg` |
| `_raw_023.jpg` | `7c828c9e2561b0d8170924e3962b95e20c79428d2e679b22b0b50d83a2f2c125` | 66326 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_023.jpg` |
| `_raw_024.jpg` | `4ebaadd19f6a17a74275cd55647bb8d70a093ae4fb0257abacb00740b56981e0` | 863807 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_024.jpg` |
| `_raw_025.jpg` | `05592d3203bbb06807702a6ce15e84420f4cd9ddfe792018516438ade2dd8e9e` | 745650 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/_raw_025.jpg` |
| `jj_01_photo_overall.jpg` | `52cd855d5422c293bacaadbb8fc8e4725c629e6e81e0d6533ba001f7c8247d41` | 581026 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_01_photo_overall.jpg` |
| `jj_02_photo_aerial_site.jpg` | `64e6b629660d137339a7bf84ec90dc671f1b9627d320d7fa4420a14bd5c78bc7` | 768026 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_02_photo_aerial_site.jpg` |
| `jj_03_photo_exterior_trees.jpg` | `10d750c8e9acbc3ff3b8cb0572df955d62106d8d1a3207f48b9a03cdb7f5b35e` | 657236 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_03_photo_exterior_trees.jpg` |
| `jj_04_photo_glass_facade.jpg` | `e407aa29a09ccee5eee0f9e328c91fcbd3a59c0a18c7d9eefa26504f546ac228` | 625110 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_04_photo_glass_facade.jpg` |
| `jj_05_photo_roof_lifted_entrance.jpg` | `db6b8195e8df5dfb28ab8fa19b3da30e2ebb5adb50498826c58473245e12a91a` | 758843 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_05_photo_roof_lifted_entrance.jpg` |
| `jj_06_photo_courtyard.jpg` | `e5d97ae923f5f4dc6670d8a392edc134c3eb2ebd6e3485137f13cf441c5e38d0` | 492127 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_06_photo_courtyard.jpg` |
| `jj_07_photo_interior.jpg` | `e5d5d469d473c7490b13dd88b3920a2b7420c54f745717eb162b33b5edb69ac5` | 586554 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_07_photo_interior.jpg` |
| `jj_08_drawing_elevation.jpg` | `6a2c15483a7fc645cc0832d2f62825907d5ce2d69299fc2125877903894567a9` | 92104 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_08_drawing_elevation.jpg` |
| `jj_09_drawing_section.jpg` | `2193501ab30ae80a17bacf6683cc956e515a9431058e4d090890b04065f67fbe` | 82796 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_09_drawing_section.jpg` |
| `jj_10_drawing_diagram.jpg` | `4ebaadd19f6a17a74275cd55647bb8d70a093ae4fb0257abacb00740b56981e0` | 863807 | 否 | `/workspace/landscape/2026-10-25/jinji_lake_pavilion/jj_10_drawing_diagram.jpg` |
