# 龙城相关遮阳案例（china-canopy）

- 归档编号：`longcheng`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·国内折板/伞状遮阳及棚架案例（目录 china-canopy-cases；期刊有「答应找国内类似 Superkilen 案例」）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases`
  - 注：来源 china-canopy-cases
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `longcheng_1.jpg` | `94f783e579acd7fa6d876e927bfad7ae0ab75eb5cafaba29d5049626eb73f949` | 1285120 | 是 | `/workspace/landscape/china-canopy-cases/longcheng_1.jpg` |
| `longcheng_2.jpg` | `0dc493970f2b179ac0150f15a5c912b69760f2a94c5a12edd38aed2edf7af288` | 1554516 | 是 | `/workspace/landscape/china-canopy-cases/longcheng_2.jpg` |
| `longcheng_3.jpg` | `3e72e07cf8835faee5e9e50f4a5b113db1e2d0758d38a89f7e4f1cfdd1925c6f` | 1543140 | 是 | `/workspace/landscape/china-canopy-cases/longcheng_3.jpg` |
| `longcheng_4.jpg` | `5d3ca1b0a1cf1bc7ae234ad58e2ceabc402f660465076e348bd8a0d0e2508344` | 564802 | 是 | `/workspace/landscape/china-canopy-cases/longcheng_4.jpg` |
| `longcheng_5.jpg` | `679c75d24c47912d1ebe41d40caecbb98c4a1ced69c8c657ab9e870d478a0790` | 2080547 | 否 | `/workspace/landscape/china-canopy-cases/longcheng_5.jpg` |
| `longcheng_6.jpg` | `e5aee3877ac03b0c7a72f3b4c1063d4c383e20a04dc3caf260f5a1fc0eb2660a` | 1375130 | 否 | `/workspace/landscape/china-canopy-cases/longcheng_6.jpg` |
