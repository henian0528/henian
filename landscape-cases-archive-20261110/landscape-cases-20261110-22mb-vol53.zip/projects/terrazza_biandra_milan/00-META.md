# Terrazza Biandrà（米兰）

- 归档编号：`terrazza_biandra_milan`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch29`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `terrazza_biandra_milan_1.jpg` | `ee908f71eb9c3517e63312a22230563cc6fa2c5e901fd96d8e291e53b0101de5` | 482912 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_1.jpg` |
| `terrazza_biandra_milan_10.jpg` | `b9881b3f424f0b3b4a2359e5541db6b0cc1c8925050e71ea813d19bfa7d9d2cf` | 297103 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_10.jpg` |
| `terrazza_biandra_milan_2.jpg` | `6c9434b6fb0a162906f491a23bc0574cf681be8f45d5ceeea174bd5cbd357b1e` | 846377 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_2.jpg` |
| `terrazza_biandra_milan_3.jpg` | `8e1d2575a2df5157f56a93486c44c6b6e460f7398b5c31be5e9a388f83c6dcc3` | 453194 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_3.jpg` |
| `terrazza_biandra_milan_4.jpg` | `002a6c006129821d1f8b72c17c8d9045144125bcfcb8b4a8beac155c51a233e5` | 444324 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_4.jpg` |
| `terrazza_biandra_milan_5.jpg` | `d4592d3c433f2fd8ecec378f31d98b613e0ed31c50dd08a372179d6633c9e739` | 470730 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_5.jpg` |
| `terrazza_biandra_milan_6.jpg` | `b5a2c065a3e530701e37778ed296d473ab0ffda2238d3cb4efc9ef7f48e0863d` | 625373 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_6.jpg` |
| `terrazza_biandra_milan_7.jpg` | `f9715d804fa311b396c2959a94232120e76c1fafe791e810de6e70f8fed67756` | 643858 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_7.jpg` |
| `terrazza_biandra_milan_8.jpg` | `0f5f49b936b8e416ccd4f377ba5e7f2e37ce93b0a5cf280a60f8077c5400751c` | 362967 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_8.jpg` |
| `terrazza_biandra_milan_9.jpg` | `53efdeb13495d3ab99866793eea768a6f439b94b38b5b0256dda155cedcc605a` | 392638 | 是 | `/workspace/landscape/batch29/terrazza_biandra_milan_9.jpg` |
