# A Tapestry of Urban Greenery（Stefano Marinaz）

- 归档编号：`tapestry_urban_greenery`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：9 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `tapestry_urban_greenery_1.jpg` | `8b54b1fd3494e27b82ee81e34391d1280df78d1078b50d27a5638d7c8f80066d` | 498328 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_1.jpg` |
| `tapestry_urban_greenery_10.jpg` | `49b9e28be4f428108560a8a48b5dbd62e69ad5c4583ebec06d2ec352ee88f683` | 699348 | 否 | `/workspace/landscape/batch23/tapestry_urban_greenery_10.jpg` |
| `tapestry_urban_greenery_2.jpg` | `ed533045b21e53d5188e66cfcd22058d83669c7a711367218874be8bf881c9c2` | 906370 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_2.jpg` |
| `tapestry_urban_greenery_3.jpg` | `a43d1c40f887e9e2820eb47930e0e9187b4241d1aba9a2821b145eef10cc8324` | 909575 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_3.jpg` |
| `tapestry_urban_greenery_4.jpg` | `069868ed6eb10b56e6632a71a1cb9694842bdba4012cb1a5148d6bad4b6729f4` | 903871 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_4.jpg` |
| `tapestry_urban_greenery_5.jpg` | `6fa67d2dd40be8c4d994a1eba6f2dba8910c97d2e7b353659d809b479b054df1` | 1002408 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_5.jpg` |
| `tapestry_urban_greenery_6.jpg` | `18f633776e07a3dc5253c4d92273e76e4b27e72ca60cffcc3bb7f70bc6bbcdfb` | 818444 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_6.jpg` |
| `tapestry_urban_greenery_7.jpg` | `195dbadb6f03fc38bb6e23290e367d6cc66dd22c96d789b16d18f7c55e7c12ff` | 538575 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_7.jpg` |
| `tapestry_urban_greenery_8.jpg` | `a1027d5fb24a5390a177da47d4fce9d7010aa87903d989bd3c8b5f4f7df766c8` | 940935 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_8.jpg` |
| `tapestry_urban_greenery_9.jpg` | `18d3c6802502cc61c58875409bec338745da210f9e58d0f33fe18b8768907256` | 1013794 | 是 | `/workspace/landscape/batch23/tapestry_urban_greenery_9.jpg` |
