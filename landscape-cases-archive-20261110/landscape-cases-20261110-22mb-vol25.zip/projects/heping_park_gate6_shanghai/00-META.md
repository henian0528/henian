# 和平公园六号门（上海，致正）

- 归档编号：`heping_park_gate6_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch32`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `heping_park_gate6_shanghai_1.jpg` | `3777c10a94b793a53b1c0f47dca9cd9311a7f8ac486b69ea3a05e3886d34716c` | 987492 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_1.jpg` |
| `heping_park_gate6_shanghai_10.jpg` | `d6644b9723de1ab1cb7c67d98b565e873489ada360e2b6ac79a78a92a860ce6a` | 174930 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_10.jpg` |
| `heping_park_gate6_shanghai_2.jpg` | `7a21db07f6edbe91fed9ad5e01835f08e979f7304dc8367547c0353b1a40ae02` | 898576 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_2.jpg` |
| `heping_park_gate6_shanghai_3.jpg` | `5e3fd9e67b9040442326db2ccaf2205d7cfe8f837a4493256019ea3ea0dae99c` | 918186 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_3.jpg` |
| `heping_park_gate6_shanghai_4.jpg` | `432580d312c3dfcccb052497503c8a1d737bf14a5cca463bb87c7455501f797a` | 1076205 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_4.jpg` |
| `heping_park_gate6_shanghai_5.jpg` | `a59b4e7e772d4e36f825abad2eb4122eccbe2c48c06d06e1abd27ce4b9a6f918` | 945971 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_5.jpg` |
| `heping_park_gate6_shanghai_6.jpg` | `4f005823556fad7c1aec02350cf452cac0f9e0e894f4230a16af5637139ebbeb` | 1165874 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_6.jpg` |
| `heping_park_gate6_shanghai_7.jpg` | `17f39094aebfe815ec0e6b8842cb358c9914f9d5ecc182b7fa817baa160a603d` | 904951 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_7.jpg` |
| `heping_park_gate6_shanghai_8.jpg` | `5ca4ca4bdb5c152445bd335400160a27d4984747135d39d511f25e02eba33932` | 963929 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_8.jpg` |
| `heping_park_gate6_shanghai_9.jpg` | `36e1fe150d9aa7ccdafed824a0b1d28f837e740a1b31760a709053ca0dfefa89` | 683799 | 是 | `/workspace/landscape/batch32/heping_park_gate6_shanghai_9.jpg` |
