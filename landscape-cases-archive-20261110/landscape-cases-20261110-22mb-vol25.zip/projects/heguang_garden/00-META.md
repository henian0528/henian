# 和光庭（上海，七月合作社）

- 归档编号：`heguang_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：14
- 在 bot 附件库中匹配到的配图：12 / 14（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：8

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `heguang_garden_1.jpg` | `5a31c2331af8f86e07ad125e17b10d38d7c7e077fd08a80bb471fdcb9b1a71aa` | 423754 | 是 | `/workspace/landscape/batch33/heguang_garden_1.jpg` |
| `heguang_garden_2.jpg` | `ea1eee9c4ea903b8f5c5bc6ee9ba58b72c8ea78bf9ee69de3c8dfa8545518597` | 472304 | 是 | `/workspace/landscape/batch33/heguang_garden_2.jpg` |
| `heguang_garden_3.jpg` | `40f4000643423ccc8bdad92c03c073393eb8019688ae8abf4c51760d1a142a8b` | 605699 | 是 | `/workspace/landscape/batch33/heguang_garden_3.jpg` |
| `heguang_garden_4.jpg` | `6e08862cbfdd8793afd9e9d906005b8c356788f22796db3a4503a2eb6c06d5c7` | 576290 | 是 | `/workspace/landscape/batch33/heguang_garden_4.jpg` |
| `heguang_garden_5.jpg` | `918849de34fb91d61f254d9cd7bbdbe11ef650e2bc3aecb558e439b4fd5418ab` | 530780 | 是 | `/workspace/landscape/batch33/heguang_garden_5.jpg` |
| `heguang_garden_6.jpg` | `0cb7f4f7458cced8a4feb2655343b3930a664c833320685dfd20ca4400cfc216` | 327717 | 是 | `/workspace/landscape/batch33/heguang_garden_6.jpg` |
| `heguang_garden_7.jpg` | `9667756b14fcca1c89425bed3b99c324fd14c0890b83f62bb37f20e1255d0907` | 648576 | 是 | `/workspace/landscape/batch33/heguang_garden_7.jpg` |
| `heguang_garden_8.jpg` | `412803cfadead7166fbbf865ddc8b8d066ba60aadb70c967963ac5e19d014a4f` | 348440 | 是 | `/workspace/landscape/batch33/heguang_garden_8.jpg` |
| `heguang_garden_1__2.jpg` | `b510e30d5ecee3dc92636b45f56d36433fc2149b2cf0d39d2fa1c3fb3ee07b23` | 312649 | 是 | `/workspace/landscape/courtyard/heguang_garden_1.jpg` |
| `heguang_garden_2__2.jpg` | `ac3d8d21ce23be6947b017fbbf742ccdd0d77b39b1aadf213e685b7619d47bd2` | 441166 | 是 | `/workspace/landscape/courtyard/heguang_garden_2.jpg` |
| `heguang_garden_3__2.jpg` | `1d6a1c30a980f5705ec9b6dc739376874372a46ee4d9baff8474907925c7e91a` | 478436 | 是 | `/workspace/landscape/courtyard/heguang_garden_3.jpg` |
| `heguang_garden_4__2.jpg` | `0ef84fadfb5dba3aa56301555bd10c11866ec8448244f95e224385fa66126dca` | 263266 | 否 | `/workspace/landscape/courtyard/heguang_garden_4.jpg` |
| `heguang_garden_5__2.jpg` | `9547d467ca3f4799eb25f7e619eddcc6f95d48fdc1a5af064eedb691de910414` | 194276 | 否 | `/workspace/landscape/courtyard/heguang_garden_5.jpg` |
| `heguang_garden_6__2.jpg` | `d843614044b74ece7cd05d007db7f31fdfec2140b4927d0bcca4f7a4bfedc1c2` | 157490 | 是 | `/workspace/landscape/courtyard/heguang_garden_6.jpg` |
