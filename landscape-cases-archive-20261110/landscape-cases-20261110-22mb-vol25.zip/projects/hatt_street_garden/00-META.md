# 251 Hatt Street（Dundas）

- 归档编号：`hatt_street_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hatt_street_garden_1.jpg` | `fc080200c61e76dd8ec172d62c34c6d5acbdfc027589446d2d75213b406bd94c` | 641509 | 是 | `/workspace/landscape/batch33/hatt_street_garden_1.jpg` |
| `hatt_street_garden_10.jpg` | `9ddeb15b3936873acd02f523f3b0e65b3bf4f7d73ef1cfa9f96a392ad04a244f` | 384349 | 是 | `/workspace/landscape/batch33/hatt_street_garden_10.jpg` |
| `hatt_street_garden_2.jpg` | `c50638bc88c0a55282fa3e1a510cf7f6246e68cd42d622d17ed5fa017024ab99` | 471432 | 是 | `/workspace/landscape/batch33/hatt_street_garden_2.jpg` |
| `hatt_street_garden_3.jpg` | `706d52855800df862e6e0109afcaa83a7f478d3bcbdaf4100a03817d0f5f5612` | 462563 | 是 | `/workspace/landscape/batch33/hatt_street_garden_3.jpg` |
| `hatt_street_garden_4.jpg` | `afffe4b14efa472d066d9ae7b2e6dfa57809695e08d91801ed1a0ff063809207` | 575964 | 是 | `/workspace/landscape/batch33/hatt_street_garden_4.jpg` |
| `hatt_street_garden_5.jpg` | `a440bd92177dc42984a0f885c4628a9d6ed3944c411612fd4b1a8edd0f6bfb0c` | 583780 | 是 | `/workspace/landscape/batch33/hatt_street_garden_5.jpg` |
| `hatt_street_garden_6.jpg` | `694c8ee4b5a76f43307efb8c00974dc1d8733b2cf8498aa02a7958a04b670034` | 604663 | 是 | `/workspace/landscape/batch33/hatt_street_garden_6.jpg` |
| `hatt_street_garden_7.jpg` | `fd4ec3c03575309005e4fd45d6dc05ae0d153dbaa6c25040103fd6d2253919e8` | 529751 | 是 | `/workspace/landscape/batch33/hatt_street_garden_7.jpg` |
| `hatt_street_garden_8.jpg` | `18235d617f6e0dd7d82494b25fe26d9d54e4582e8a5a770b3d5045a447852991` | 260645 | 是 | `/workspace/landscape/batch33/hatt_street_garden_8.jpg` |
| `hatt_street_garden_9.jpg` | `52e2463d33ef05ceacf8cf1ab02ee76d20fe0f3820a0cd7a5807e9f4241ead4d` | 282488 | 是 | `/workspace/landscape/batch33/hatt_street_garden_9.jpg` |
