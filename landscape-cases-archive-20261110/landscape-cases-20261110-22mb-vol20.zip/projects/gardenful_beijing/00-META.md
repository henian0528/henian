# Gardenful（北京，TAOA）

- 归档编号：`gardenful_beijing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：20
- 在 bot 附件库中匹配到的配图：20 / 20（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch29`
  - 本记录配图文件数：10

- 日期/标记：2026-10-19
  - 出处说明：2026-10-19 补发 Gardenful 更多图（期刊）
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/gardenful_more`
  - 注：来源 gardenful_more
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `gardenful_beijing_1.jpg` | `090999406f4336dd8935d9c201d00e9ec1904e9a86324b78e5820e0631315d92` | 752628 | 是 | `/workspace/landscape/batch29/gardenful_beijing_1.jpg` |
| `gardenful_beijing_10.jpg` | `d9bc6dbb26008c1fa81b94f407803387347cb002b6c78bd9520445d410531116` | 868543 | 是 | `/workspace/landscape/batch29/gardenful_beijing_10.jpg` |
| `gardenful_beijing_2.jpg` | `7b40bedd5fc95074f975b50b2c04febefb083b058b0c48ca953817952620eeeb` | 675135 | 是 | `/workspace/landscape/batch29/gardenful_beijing_2.jpg` |
| `gardenful_beijing_3.jpg` | `f39edbcae64b3c6afb94a5964b7bf08f61791a151de16f816106ea9a4a5e86e4` | 1165622 | 是 | `/workspace/landscape/batch29/gardenful_beijing_3.jpg` |
| `gardenful_beijing_4.jpg` | `1fe12a1d258069bcf1047175efa8612804d4689b2c5bb50ec59a9f548162bacd` | 1196101 | 是 | `/workspace/landscape/batch29/gardenful_beijing_4.jpg` |
| `gardenful_beijing_5.jpg` | `9bb715a4f46d5c14a64dae2e1dde918274955b809b49d54437cc38ee9fb093fe` | 676117 | 是 | `/workspace/landscape/batch29/gardenful_beijing_5.jpg` |
| `gardenful_beijing_6.jpg` | `d7ac1c4b959553fe00d051b2c80d50b3e9e582bc7c962cbd9aecad804a708060` | 676616 | 是 | `/workspace/landscape/batch29/gardenful_beijing_6.jpg` |
| `gardenful_beijing_7.jpg` | `0e95b86934d11c7807e63c604c2d7af06787a368e90a7d2f3c91391541dc74d3` | 732318 | 是 | `/workspace/landscape/batch29/gardenful_beijing_7.jpg` |
| `gardenful_beijing_8.jpg` | `a40454b04c4cc1d00ebeaf31abbd419c1495dfa2e475f890dcf1469f4374d195` | 571483 | 是 | `/workspace/landscape/batch29/gardenful_beijing_8.jpg` |
| `gardenful_beijing_9.jpg` | `64c9041f67b5b90f59a993d29b4943924f661c113bc8c94b5ce385c24e46651f` | 881969 | 是 | `/workspace/landscape/batch29/gardenful_beijing_9.jpg` |
| `gardenful_more_01.jpg` | `55886a9fd499688c0112ef867be62c29061117e55f88718d6cec0146559c0ea1` | 2366884 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_01.jpg` |
| `gardenful_more_02.jpg` | `cb6ccc9c435ce4eb094ccc42e9f0ae0cfca2f6235fcbc652706664b3cca15311` | 4480292 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_02.jpg` |
| `gardenful_more_03.jpg` | `cb20b5d038d8e16ea25f2de263e1349f3f0a5b7ffc1eea2266da43edc36107e9` | 4903491 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_03.jpg` |
| `gardenful_more_04.jpg` | `11d8cb510b130ad9f391845241842fb4bf29cf0d8d1b71a5b46b4fcc6cdd3fec` | 2211121 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_04.jpg` |
| `gardenful_more_05.jpg` | `9d074623de3c208b01838f852b63ed1d7c0183a2d59919387ed35b5d7c31689c` | 3241074 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_05.jpg` |
| `gardenful_more_06.jpg` | `379d96f8f6e6b3adeb20629da80322dfba73c82b51fa087b1a6b2eda199692b9` | 4409335 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_06.jpg` |
| `gardenful_more_07.jpg` | `50dab628584783ba23108694a1251f5158f6006e7bad44d806854df6d111a375` | 738789 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_07.jpg` |
| `gardenful_more_08.jpg` | `0cbb1dddfe7f7347f9ea86bb6f5795037b9172a3b64349118938ff05adfbb320` | 912730 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_08.jpg` |
| `gardenful_more_09.jpg` | `04cca2913609f3ad26a0f83d34490943615f518ab69e3e5ecbe94a3043e53c7c` | 694046 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_09.jpg` |
| `gardenful_more_10.jpg` | `88c75e548f67fed4d839c83b6cc11bc8cb5037316e36bcf3cd8b8a75b63f3285` | 390405 | 是 | `/workspace/landscape/gardenful_more/gardenful_more_10.jpg` |
