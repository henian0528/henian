# Shadowplay Phoenix（white）

- 归档编号：`shadowplay_phoenix`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：5 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shadowplay_phoenix_1.jpg` | `32124152d64c735490650b2e47b8c92f5c28fb64bb05496303cdecc4652d4b73` | 87048 | 是 | `/workspace/landscape/china-canopy-cases/white/shadowplay_phoenix_1.jpg` |
| `shadowplay_phoenix_2.jpg` | `674e51745b10c6e663199e61a8427ad51a7bb0773699a2b18d04a25e5f273882` | 122316 | 是 | `/workspace/landscape/china-canopy-cases/white/shadowplay_phoenix_2.jpg` |
| `shadowplay_phoenix_3.jpg` | `67fde094a8ec6651cf91dc0982a6c1de84b9ff465fda326fede0c27c2d3bc963` | 108262 | 是 | `/workspace/landscape/china-canopy-cases/white/shadowplay_phoenix_3.jpg` |
| `shadowplay_phoenix_4.jpg` | `add2635aa9fbbd3d9b4e98817ad51e4308db621565eaf850c6b6d2f40e6c0c35` | 80322 | 是 | `/workspace/landscape/china-canopy-cases/white/shadowplay_phoenix_4.jpg` |
| `shadowplay_phoenix_5.jpg` | `00fa0f0079159bed134c386eebc135b53146efa55c6307b77c838b2a5c99c68d` | 91728 | 是 | `/workspace/landscape/china-canopy-cases/white/shadowplay_phoenix_5.jpg` |
