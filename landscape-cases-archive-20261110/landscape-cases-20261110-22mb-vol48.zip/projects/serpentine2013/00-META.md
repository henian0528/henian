# Serpentine 2013（white3）

- 归档编号：`serpentine2013`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white3）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white3`
  - 注：来源 china-canopy-cases/white3
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `serpentine2013_1.jpg` | `270b500321cea510bb953dedf0f238a7ece7c38e373fcb884859b51ef998b62b` | 755084 | 是 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_1.jpg` |
| `serpentine2013_2.jpg` | `5f9ce6c8280db68d982dff824b6ddb8f0537cdfee5959d2aff6b4c2decfebcaf` | 799353 | 是 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_2.jpg` |
| `serpentine2013_3.jpg` | `3db2c1572f81b37e91563f0aad88878ca6db941771df68ec7bd33c81443b5ecd` | 996547 | 是 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_3.jpg` |
| `serpentine2013_4.jpg` | `bf8192c2d1b1d751ac5ff32152b66473ad2ca1f7bbeb31ada7a2f3d5adb48bd2` | 960559 | 是 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_4.jpg` |
| `serpentine2013_5.jpg` | `b1652da000610507e1a14d73a6c65e73af9d53b138b3d9aa2173b40966977961` | 987568 | 否 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_5.jpg` |
| `serpentine2013_6.jpg` | `f94a8bf49559bda570c8ad332d33178db0edd704f1ed8b94f48a7e8b40f632a3` | 715530 | 否 | `/workspace/landscape/china-canopy-cases/white3/serpentine2013_6.jpg` |
