# 三亭园（北京，水行设计）

- 归档编号：`santing_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：11
- 在 bot 附件库中匹配到的配图：10 / 11（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch10`
  - 本记录配图文件数：11

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `santing_garden_1.jpg` | `1928f560ed13f64727c3627f05fb8813c32240ae84cf3c096e92cbf8a6f2bb3d` | 143115 | 是 | `/workspace/landscape/batch10/santing_garden_1.jpg` |
| `santing_garden_10.jpg` | `d7c5b450d648d4d4110209476d2279eb450325e76c684538539769e5fbaffdba` | 134367 | 是 | `/workspace/landscape/batch10/santing_garden_10.jpg` |
| `santing_garden_11.jpg` | `96f14959d94a53ff265c8e89ff2a55881d0ca6130877c857bd01e09a0c7f1a0b` | 61755 | 是 | `/workspace/landscape/batch10/santing_garden_11.jpg` |
| `santing_garden_2.jpg` | `66e4c02c8522623b2484284d6850af6efce4d13df4805c47ba2f1a8c2766681e` | 133152 | 是 | `/workspace/landscape/batch10/santing_garden_2.jpg` |
| `santing_garden_3.jpg` | `f1affd9623be75e46af64b11ea3a9af9fe6221c46e2cc19bacf5eacc7b353656` | 126848 | 是 | `/workspace/landscape/batch10/santing_garden_3.jpg` |
| `santing_garden_4.jpg` | `f4f504b65cad94c90873114458765ae56551fd1e6a904bd0de2ad2667c2564ce` | 94108 | 是 | `/workspace/landscape/batch10/santing_garden_4.jpg` |
| `santing_garden_5.jpg` | `9fee8c131c0f87f532074123fc1f4eac26e66bcbc61d24cad14d84276275b7bd` | 77817 | 是 | `/workspace/landscape/batch10/santing_garden_5.jpg` |
| `santing_garden_6.jpg` | `5d7fb29a1ca14f9fe98f4de0d0cbc556410c43e5e6b69724d79c932b7dd53bfb` | 107552 | 是 | `/workspace/landscape/batch10/santing_garden_6.jpg` |
| `santing_garden_7.jpg` | `08ec985ddc4179e3827ae82f2bf332eb5748f144a037b8a66876bea1c426a2a7` | 105199 | 是 | `/workspace/landscape/batch10/santing_garden_7.jpg` |
| `santing_garden_8.jpg` | `7249f96114948691387315c75c5589be8283f87dd67e67d58bdcc6340054a5c3` | 89263 | 是 | `/workspace/landscape/batch10/santing_garden_8.jpg` |
| `santing_garden_9.jpg` | `3bdfdba467b95f62c7166e947ae4e51dad2efd203f3c88086714cfe882c48f95` | 99659 | 否 | `/workspace/landscape/batch10/santing_garden_9.jpg` |
