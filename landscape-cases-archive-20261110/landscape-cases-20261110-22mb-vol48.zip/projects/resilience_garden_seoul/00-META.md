# Resilience Garden（首尔，batch15）

- 归档编号：`resilience_garden_seoul`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch15`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `resilience_garden_seoul_1.jpg` | `658aa77018ec6be4222aa1f13758451da2c47e15998fea18de7849cb3b2a776e` | 1097670 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_1.jpg` |
| `resilience_garden_seoul_10.jpg` | `0faa8af7b9ca1b22bcf7eff15c659f5e82d857e84ec8fbe652c9afabba679018` | 1162080 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_10.jpg` |
| `resilience_garden_seoul_2.jpg` | `3c645b180a57edd320511c2000d10624be5a579b9d606cb4b2b242e6c3f0be70` | 1117852 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_2.jpg` |
| `resilience_garden_seoul_3.jpg` | `b1bc05936f3444c35da28fd0dba67707c2243e364ce79e2589622fe1b5924c0c` | 1246150 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_3.jpg` |
| `resilience_garden_seoul_4.jpg` | `a6ad36ed7b3e415c5431a6f95ed123204eef45824292ac9c2d2c4fc96e562ca6` | 1189364 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_4.jpg` |
| `resilience_garden_seoul_5.jpg` | `62a19ed531925c052100f956875395214632a30bb7a0aab642180c1f1d920c42` | 1135313 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_5.jpg` |
| `resilience_garden_seoul_6.jpg` | `8795d4a6839e6bd65375c6332055a9597f0826ae58d655eba4a11c0291c3d303` | 890085 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_6.jpg` |
| `resilience_garden_seoul_7.jpg` | `ba3547a79d5e1b8ab353eef749fc32f6a0b904128f8a9fc839090c0b7f8f48cf` | 1004805 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_7.jpg` |
| `resilience_garden_seoul_8.jpg` | `105a3e8708addc602a758cc7227129fdbf076a9c69b76363f07956e1330beeeb` | 781241 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_8.jpg` |
| `resilience_garden_seoul_9.jpg` | `b26040f7798de1a9087015f9db230e3b74998377ece5ed49d9419030dc0057a6` | 1123863 | 是 | `/workspace/landscape/batch15/resilience_garden_seoul_9.jpg` |
