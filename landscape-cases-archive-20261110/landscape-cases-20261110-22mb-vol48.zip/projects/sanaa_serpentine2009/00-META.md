# SERPENTINE 2009（SANAA，structures 早期批次）

- 归档编号：`sanaa_serpentine2009`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：7 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `sanaa_serpentine2009_1.jpg` | `b2ddc94a2c4611c38c139dffd01af6d7e9c586e043fcf0acf36a9928700623a6` | 823288 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_1.jpg` |
| `sanaa_serpentine2009_2.jpg` | `b4d09e3d4a8970365f9ba680dcdc3211c18638b8353cbf99a49228252cd4f426` | 767012 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_2.jpg` |
| `sanaa_serpentine2009_3.jpg` | `c44b945796b58fd5ceddd7c9fc9329a2dfb51ec9601610abb3c3d86f0d7b3ad4` | 127378 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_3.jpg` |
| `sanaa_serpentine2009_4.jpg` | `35e8b26de5abb2a9f3b0cfc88e3e0c95444f4ecd511c9eac564f61aa2414c6c3` | 82534 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_4.jpg` |
| `sanaa_serpentine2009_5.jpg` | `26fee3856a9fc92b10ea6372a8d6282551748793de2c8d32162b0bedf4f46698` | 107284 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_5.jpg` |
| `sanaa_serpentine2009_6.jpg` | `444d938435f0462c12534b2f238416b8df6c170182c8013bef8ed4b72ba1b856` | 131868 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_6.jpg` |
| `sanaa_serpentine2009_7.jpg` | `20894c0d68a240f77868c486dc92dbaa23acd0e061b8b109c918d769af6ee895` | 85296 | 是 | `/workspace/landscape/structures/sanaa_serpentine2009_7.jpg` |
