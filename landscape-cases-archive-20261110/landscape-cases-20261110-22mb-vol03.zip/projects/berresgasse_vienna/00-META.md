# Berresgasse（维也纳，期刊记图片曾被拦截）

- 归档编号：`berresgasse_vienna`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch28`
  - 注：期刊记载当时图片下载受阻；本地后来有精选图，是否补发未从对话记录确认。
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `berresgasse_vienna_1.jpg` | `fa6448b5ab38f53475508a39e11bc2bf0517a9b74b05d2f1f4e4c23e74df216c` | 591028 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_1.jpg` |
| `berresgasse_vienna_10.jpg` | `22c04046ac8edc434bc112b53dd7e454e716736b5b56b5abc08b2bdf8d4de5a6` | 505673 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_10.jpg` |
| `berresgasse_vienna_2.jpg` | `c0e97496b2c04a8def8687ee68681f79da2bb81143dde4f2093c6416a83894e8` | 286952 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_2.jpg` |
| `berresgasse_vienna_3.jpg` | `b476413247ac8f2d95a84232278624539bc2cc813439c8adfcab29c31a058b2c` | 355105 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_3.jpg` |
| `berresgasse_vienna_4.jpg` | `fb52a75f09635bb155029e96fdc152d49b505a9ea497e9f1fc8e1ea3ee9eca93` | 640088 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_4.jpg` |
| `berresgasse_vienna_5.jpg` | `8d7304940b2a6bd39f17ffd2c33acc8ee787c58d6e281657604c612e89a675a7` | 634150 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_5.jpg` |
| `berresgasse_vienna_6.jpg` | `00d45898e11f27f0ddb88ee7db2d674079c33e79380a6dc2dd10b989b8958f4b` | 860144 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_6.jpg` |
| `berresgasse_vienna_7.jpg` | `0154818a4374d7932920d8ac8f2acbe34d2e5841a19745ff3e8e17f340d7fe8e` | 474707 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_7.jpg` |
| `berresgasse_vienna_8.jpg` | `18e1941e03474b5d5bf3c61a2c48cc904a304308610bf9c72ac56383f9369f15` | 566491 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_8.jpg` |
| `berresgasse_vienna_9.jpg` | `60155b0387922159072cedf135d93bd0795937f3a9ce6e33cc6972f8e410aee4` | 538687 | 是 | `/workspace/landscape/batch28/berresgasse_vienna_9.jpg` |
