# Berry Square（悉尼，ASPECT）

- 归档编号：`berry_square_sydney`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `berry_square_sydney_1.jpg` | `770b2b4af86fde419cc58bdadfcc16872d0b0ec70d3de9859f8514be04ea0d44` | 1113712 | 是 | `/workspace/landscape/batch27/berry_square_sydney_1.jpg` |
| `berry_square_sydney_10.jpg` | `5fdf8a9d8172cf78c28f9b85b4201296460b97f1bdf9b9649371eddecc7b1ecb` | 428072 | 是 | `/workspace/landscape/batch27/berry_square_sydney_10.jpg` |
| `berry_square_sydney_2.jpg` | `c9856a2afb6735b0b49f2e8bca42c8a70600e16b1fc009505a7195714d1c013a` | 724568 | 是 | `/workspace/landscape/batch27/berry_square_sydney_2.jpg` |
| `berry_square_sydney_3.jpg` | `7fb3c6ace31240d69da79678c89e24583c44f5de534633c097b98501ac4949e5` | 568558 | 是 | `/workspace/landscape/batch27/berry_square_sydney_3.jpg` |
| `berry_square_sydney_4.jpg` | `f22895a305b646801baff6412108c288c6f68452e68676686a2441d0ac177e81` | 886168 | 是 | `/workspace/landscape/batch27/berry_square_sydney_4.jpg` |
| `berry_square_sydney_5.jpg` | `d9abb2c5379aa090b2889b0993092c03225eb3d872e01b23b200c94cf8c58fa3` | 336208 | 是 | `/workspace/landscape/batch27/berry_square_sydney_5.jpg` |
| `berry_square_sydney_6.jpg` | `3fa2f979b67ed50476a8aa9ebe78c919dae180f69ba396135c97d5da3aed0d65` | 526387 | 是 | `/workspace/landscape/batch27/berry_square_sydney_6.jpg` |
| `berry_square_sydney_7.jpg` | `2bc2bb12b1605d82ed550f44b7b8b8f8c5bc1885ef09b9685bd82839fb2e14e3` | 622211 | 是 | `/workspace/landscape/batch27/berry_square_sydney_7.jpg` |
| `berry_square_sydney_8.jpg` | `d0302e6425729422579b5af611d049625eaacd5696d26d89e09149fe5794c38b` | 415408 | 是 | `/workspace/landscape/batch27/berry_square_sydney_8.jpg` |
| `berry_square_sydney_9.jpg` | `236d01b94605ab3c54412d667542f674586452d4317f4bfd27c41918f5897af8` | 618715 | 是 | `/workspace/landscape/batch27/berry_square_sydney_9.jpg` |
