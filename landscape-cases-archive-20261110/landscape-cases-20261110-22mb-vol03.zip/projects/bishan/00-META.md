# 新加坡碧山宏茂桥公园 / Bishan-Ang Mo Kio Park

- 归档编号：`bishan`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-06
  - 出处说明：群聊工作日日推（期刊：10-07 补发配图）
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/2026-10-06`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bishan_1_aerial.jpg` | `11a80f31ff42ac59eaa91c02dc472134e67ddfcfb70626027d72d295927c5ea6` | 920676 | 是 | `/workspace/landscape/2026-10-06/bishan_1_aerial.jpg` |
| `bishan_2_river.jpg` | `85776d2781afcddbb4f2eae765d44879980bf9e5b5f722b80d270fb61ef133ce` | 886238 | 是 | `/workspace/landscape/2026-10-06/bishan_2_river.jpg` |
| `bishan_3_park.jpg` | `08539cea192cab3721987c83715f020d69ee783f20f1cc97a14a035836360f89` | 655124 | 是 | `/workspace/landscape/2026-10-06/bishan_3_park.jpg` |
| `bishan_4_biotope.jpg` | `345db0d8bf7b9e953381c8324e67a0f72985794c0101b4843e09cae7d6986135` | 348355 | 是 | `/workspace/landscape/2026-10-06/bishan_4_biotope.jpg` |
| `bishan_5_pond.jpg` | `807ca7fc9829dec3792f80cbe64d397a46656bec4dece704858a44c7bc862f7b` | 873075 | 是 | `/workspace/landscape/2026-10-06/bishan_5_pond.jpg` |
| `bishan_6_before_after.jpg` | `eebee0f55ea5ebdedc8fcf76309f67ed514bcfcc4e97ebcf4bde0b112dcdcea9` | 896803 | 是 | `/workspace/landscape/2026-10-06/bishan_6_before_after.jpg` |
