# Tsuboniwa Retreat（伦敦，batch24）

- 归档编号：`tsuboniwa_retreat_london`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch24`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `tsuboniwa_retreat_london_1.jpg` | `60a8546fdbf5d8812260635cb87fb17186c7d8eece334957c6f15392533f3ba3` | 700261 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_1.jpg` |
| `tsuboniwa_retreat_london_10.jpg` | `ae6b9346e340965b265a5f80e93608af2dd7946f7f9b8da859074ec1a2c3421b` | 453194 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_10.jpg` |
| `tsuboniwa_retreat_london_2.jpg` | `e34813a60264a64b62e4e2285192094cebdbc1d5004769d7f90ab0c28c3cb199` | 575555 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_2.jpg` |
| `tsuboniwa_retreat_london_3.jpg` | `387fe79ed529b55cfffb4a3cfb8d584db25824d92f15821db9d4fd877a4b7d56` | 514186 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_3.jpg` |
| `tsuboniwa_retreat_london_4.jpg` | `7217abce158c32019b7c2f53f2719ad3d429bef4123751390f2d898355625d22` | 599211 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_4.jpg` |
| `tsuboniwa_retreat_london_5.jpg` | `f4c940771b4f6a054c1cd866b344c23688926238519e9b87bc8099a5d9e0e961` | 660862 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_5.jpg` |
| `tsuboniwa_retreat_london_6.jpg` | `2fd1f2fc2c3f6fd5ec7d04fac007f5b092e89c2e205d3e84f0c2e283899e5b9a` | 553301 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_6.jpg` |
| `tsuboniwa_retreat_london_7.jpg` | `3e26232ea3d210714ddefcd1e0f7ef6c9eff517314549a569aee4a88734d96fa` | 612778 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_7.jpg` |
| `tsuboniwa_retreat_london_8.jpg` | `952d00a32498dfa7f24452a3b928c9d92c8be4adff268b5c1532952ab9f39802` | 568722 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_8.jpg` |
| `tsuboniwa_retreat_london_9.jpg` | `4500c97f837d02e3454c10a89fa80e37fbc3a531449844b0d32a94df0629fb92` | 477065 | 是 | `/workspace/landscape/batch24/tsuboniwa_retreat_london_9.jpg` |
