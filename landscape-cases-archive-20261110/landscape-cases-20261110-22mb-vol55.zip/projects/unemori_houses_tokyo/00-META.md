# Unemori Houses（东京，batch24）

- 归档编号：`unemori_houses_tokyo`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch24`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `unemori_houses_tokyo_1.jpg` | `f4af571e3ccdad65962d180c15f3598e51544eb8cd4078d212645af4d6fd0584` | 607882 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_1.jpg` |
| `unemori_houses_tokyo_10.jpg` | `88aa352742191a666baf98b5bc612c840bfd45ddc7e1e9abcbcda8a6b3657bda` | 168570 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_10.jpg` |
| `unemori_houses_tokyo_2.jpg` | `da07559feb4e902ab9f144a87adac0f00942d22f3ac55606eef4ab83ca8d1eca` | 504679 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_2.jpg` |
| `unemori_houses_tokyo_3.jpg` | `e913467dde9dc933794576878cd8e61b317e48914805828363fdd03cd8a77be8` | 493056 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_3.jpg` |
| `unemori_houses_tokyo_4.jpg` | `ff3293c2e138e607525287048841d8fac4c69bc8e13169a9d3f39047a9e8858c` | 455920 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_4.jpg` |
| `unemori_houses_tokyo_5.jpg` | `4dccd7a6c58048486c16f025b820dcbed257e5736dc8f7ea859a1dc3c7f2de3a` | 379060 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_5.jpg` |
| `unemori_houses_tokyo_6.jpg` | `ed5301328af760bad4c96bdc001458ee413b750ac78e31a2e723d5fd44deba78` | 515746 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_6.jpg` |
| `unemori_houses_tokyo_7.jpg` | `d315d40bb45f7baebb244ebed7f1eaeb8dbac6ec302beefd946c5c7cdd398387` | 431370 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_7.jpg` |
| `unemori_houses_tokyo_8.jpg` | `dbbe30104aef435c55b47699d34bc0e530a2d3223df212951bc45cddbe24ecbc` | 514011 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_8.jpg` |
| `unemori_houses_tokyo_9.jpg` | `34b48811de46cef4810068d6bc479c1137e5730e60048b5920622516cf74fa55` | 166258 | 是 | `/workspace/landscape/batch24/unemori_houses_tokyo_9.jpg` |
