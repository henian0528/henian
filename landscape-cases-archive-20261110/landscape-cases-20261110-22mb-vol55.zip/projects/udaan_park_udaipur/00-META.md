# Udaan Park（乌代浦）

- 归档编号：`udaan_park_udaipur`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch32`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `udaan_park_udaipur_1.jpg` | `37d213614d12f3696b6c41818498760a24d6e91095e1ef0b0dcefdf1264b493d` | 810256 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_1.jpg` |
| `udaan_park_udaipur_10.jpg` | `f310f80c9642de6a0f35ee1cd4bae8af0cdaf3411d975e988f75b636e3b027b8` | 323124 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_10.jpg` |
| `udaan_park_udaipur_2.jpg` | `e4516d19b6fefb3a277b46f19c425b110478557bced72dd65f1e6c5016c35bea` | 549147 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_2.jpg` |
| `udaan_park_udaipur_3.jpg` | `bb7f74d072d9a7aed36ec27f4f428a21f72de823992608ae16d61c21e86fae51` | 944749 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_3.jpg` |
| `udaan_park_udaipur_4.jpg` | `ce1fb589ad2b6fcdb86dd2c74654b55a029a6b2d671eb24c8a07f1d0b8305990` | 630165 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_4.jpg` |
| `udaan_park_udaipur_5.jpg` | `c700964ad2d45068564f746a32875b8fd7a796b30de631ad4fb5f88932300a2d` | 644098 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_5.jpg` |
| `udaan_park_udaipur_6.jpg` | `9c5d5033e42b23121d6c3436f3d40f3ce5671f748323ac64b70cca0ad7b7338c` | 820903 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_6.jpg` |
| `udaan_park_udaipur_7.jpg` | `f425caa1fb18e02421317ac59adef46c1b60234df287c4ab87a99d3b8e340bbe` | 727461 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_7.jpg` |
| `udaan_park_udaipur_8.jpg` | `fd6dd36b803d03fa044bf52554e7e1c2fc20e42ba09f95b0dd50f38f982c47a3` | 797573 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_8.jpg` |
| `udaan_park_udaipur_9.jpg` | `0520fcecc244c6d1c57cde72802430ce5425855c4606b6180c098c5179309303` | 897693 | 是 | `/workspace/landscape/batch32/udaan_park_udaipur_9.jpg` |
