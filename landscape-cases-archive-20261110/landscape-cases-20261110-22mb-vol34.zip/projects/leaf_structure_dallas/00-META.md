# Leaf Structure（达拉斯植物园，Legge Lewis Legge）

- 归档编号：`leaf_structure_dallas`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch11`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `leaf_structure_dallas_1.jpg` | `4931995c3c1778ee6a06b0ea8957a2dc9b9227164f9ec1d210e40612f8003132` | 359891 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_1.jpg` |
| `leaf_structure_dallas_10.jpg` | `c10db3e90faa2ee0ddc892d5a222348c44b24083f6fc7756e91f5bdb943d3e83` | 152468 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_10.jpg` |
| `leaf_structure_dallas_2.jpg` | `13898e8d40f87259be4978ca879cc6ae554698a4e0496b08c2e0636f7a738bf4` | 349675 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_2.jpg` |
| `leaf_structure_dallas_3.jpg` | `5ca1c7b645ac04310622811696a6496ee35a19eae7fae387b6929c866086ff06` | 494193 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_3.jpg` |
| `leaf_structure_dallas_4.jpg` | `a0d9ff005d666c7f6716ec6ff9c06e729bd8b60d1c0e47edfb8586ae402633c5` | 531401 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_4.jpg` |
| `leaf_structure_dallas_5.jpg` | `b359fd7219c6ee017afa5c433996581701e12733dac32dce2c9616f7ea131747` | 225177 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_5.jpg` |
| `leaf_structure_dallas_6.jpg` | `19186895a3ad4eaf80eaa9a70fb80d04f2fe94dda67e7f4935ce2dd251ba1e99` | 411991 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_6.jpg` |
| `leaf_structure_dallas_7.jpg` | `1ba14761e96634af5fe4a5e5c5eb1440a0e00daf735dd9c2e3eec2a2a6474f0f` | 223041 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_7.jpg` |
| `leaf_structure_dallas_8.jpg` | `e0bcae88f7ef08cb24cfd9b5db8ce9bbcdd521d89c2e50f7d544ecfc37e77f93` | 212243 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_8.jpg` |
| `leaf_structure_dallas_9.jpg` | `4ccc4d973210074a99ae0f3cfe8d5ef46eab2dfb178fd59232235243025d9479` | 206758 | 是 | `/workspace/landscape/batch11/leaf_structure_dallas_9.jpg` |
