# 鲁汶联排后院 Garden Dorien and Pierre-Yves

- 归档编号：`leuven_townhouse_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：4
- 在 bot 附件库中匹配到的配图：4 / 4（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch19`
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `leuven_townhouse_garden_1.jpg` | `ba6ed87797f485d294f76fba2f654663ab86ff67aa122d5aef27d98254c82de6` | 463167 | 是 | `/workspace/landscape/batch19/leuven_townhouse_garden_1.jpg` |
| `leuven_townhouse_garden_2.jpg` | `325b5a344c7954597bf8481d26a2b86a5c2102772aadfb4aed26b0892697b1d2` | 333888 | 是 | `/workspace/landscape/batch19/leuven_townhouse_garden_2.jpg` |
| `leuven_townhouse_garden_3.jpg` | `cc61da40cba395920cfd3f1491f4a4cbed73ca1b000cbe4bc2adb1bf9ed5abbc` | 655318 | 是 | `/workspace/landscape/batch19/leuven_townhouse_garden_3.jpg` |
| `leuven_townhouse_garden_4.jpg` | `707b8a7c20fcdc69039c4d650c85133571f7d21809ccb3a57f8d0e3c2199aa44` | 386781 | 是 | `/workspace/landscape/batch19/leuven_townhouse_garden_4.jpg` |
