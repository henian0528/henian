# 鲁汶 Garden Kathleen and Wim（Plant en Houtgoed）

- 归档编号：`leuven_kw_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `leuven_kw_garden_1.jpg` | `49c5be2dcaa6e7a9ef7198c525e19c413bab03190aae2dca5b42c2d5f4153d3c` | 569615 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_1.jpg` |
| `leuven_kw_garden_2.jpg` | `d1fdf1754f223d332b4a8ab8b6ddab69526ef0716b19d68fd7f36d890261f626` | 680642 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_2.jpg` |
| `leuven_kw_garden_3.jpg` | `48c90dfbf944d61b01b315f7b2c026f438bfdc5bdd589a9dcc65438332e67eac` | 710326 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_3.jpg` |
| `leuven_kw_garden_4.jpg` | `2737c1b2e9b923ffb11c675941c885fe1e50b5906217e4ee1c9b9a08bb7736e1` | 652904 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_4.jpg` |
| `leuven_kw_garden_5.jpg` | `27ff5909dc3ba9063561d7fd9c2781d86411677197404c38199c4372e0e5beb5` | 602769 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_5.jpg` |
| `leuven_kw_garden_6.jpg` | `8225c1abd480760d29bb687ce09d5a159671764e0ae2df1addf48d1ab4966b2c` | 238384 | 是 | `/workspace/landscape/batch20/leuven_kw_garden_6.jpg` |
