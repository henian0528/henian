# 叶脉花园（建瓯，大小景观）

- 归档编号：`leaf_vein_garden_nanping`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch28`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `leaf_vein_garden_nanping_1.jpg` | `bb572eb03cabaceea2e425592227cd2326f2e80d0213b91012681436c3b9304b` | 878939 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_1.jpg` |
| `leaf_vein_garden_nanping_10.jpg` | `718583af68bcf2b6f2883cf298a4b84504b28d9db28f8b29cd16a578d35b6913` | 763173 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_10.jpg` |
| `leaf_vein_garden_nanping_2.jpg` | `56a6b0b05dbe7296be3698325e35fddf8cc98452a23bad834d4c8ccb271f1c5e` | 743060 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_2.jpg` |
| `leaf_vein_garden_nanping_3.jpg` | `87504f6956aca2a5a7171c9f9f0ee9359ede72d6b9d194a4ede09acfe4a1fd60` | 754941 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_3.jpg` |
| `leaf_vein_garden_nanping_4.jpg` | `56df7843edf51434ab4d54e1ffa73c84bc6b97b8451e5402e86cb5dae535d42e` | 632643 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_4.jpg` |
| `leaf_vein_garden_nanping_5.jpg` | `f63515eba67730e9d45bb9afb1e50b41d89c253cb318f6e741e74618f380a612` | 788868 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_5.jpg` |
| `leaf_vein_garden_nanping_6.jpg` | `49373fdda7638b2c7384a7f9cf0e8f295aa0b95a65dc0ca233ccbcc03aa20743` | 566430 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_6.jpg` |
| `leaf_vein_garden_nanping_7.jpg` | `fc3cb5ce3e3e0654cc86a57812b147724504f3942fb174040c70edd06782492f` | 679885 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_7.jpg` |
| `leaf_vein_garden_nanping_8.jpg` | `71cc100f14aab34c7dfadf2b64579605240bb41cf550b45b8480c797997f4a92` | 655941 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_8.jpg` |
| `leaf_vein_garden_nanping_9.jpg` | `21a97189721d1b130518ebf9b6e64da90ad64eef1649ca7ead25e1c7507c717f` | 612580 | 是 | `/workspace/landscape/batch28/leaf_vein_garden_nanping_9.jpg` |
