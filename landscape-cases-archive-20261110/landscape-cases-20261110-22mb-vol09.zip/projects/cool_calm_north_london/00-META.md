# Cool Calm（北伦敦，batch24）

- 归档编号：`cool_calm_north_london`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch24`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `cool_calm_north_london_1.jpg` | `49b96c4ab04766ae45345736211e0bd3038cc33f63fa552bf9d06bfb4c3fb00c` | 778848 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_1.jpg` |
| `cool_calm_north_london_2.jpg` | `844219cac6dfefa6d152d3ef5a30e0f0ff99fd6dd7a36dbfc1f93d6a3296992a` | 658482 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_2.jpg` |
| `cool_calm_north_london_3.jpg` | `e94f05faf6c19fc90a1dfa288cfd4424a0b0836d72411e92ea72066309faed62` | 618153 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_3.jpg` |
| `cool_calm_north_london_4.jpg` | `6ea044c0e7ea14c8399238646189fb5230594bdf17421a89b44928996cbbc992` | 699325 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_4.jpg` |
| `cool_calm_north_london_5.jpg` | `4ec19504ff7c7ce78e3ff747744fbbd320d727aa522f2de2ebfdf4a76385ddcb` | 656415 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_5.jpg` |
| `cool_calm_north_london_6.jpg` | `4ee756f7ee55c523fcf448f972b5905150d5b8b62aec42f2adffcc16afa13a69` | 366390 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_6.jpg` |
| `cool_calm_north_london_7.jpg` | `49e1fcbb0a786211904c99aea05e0420a292ddec0b6007598073fbb5759d373e` | 475168 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_7.jpg` |
| `cool_calm_north_london_8.jpg` | `536e72ac1a554ad35d4c4b52954dcc8afd0f3068e08aec54855f39e81024d31a` | 429758 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_8.jpg` |
| `cool_calm_north_london_9.jpg` | `94d7165f5d812a01e11d3a7451d9d5438a51566f95e1b71feddecfb9d8a1a214` | 604384 | 是 | `/workspace/landscape/batch24/cool_calm_north_london_9.jpg` |
