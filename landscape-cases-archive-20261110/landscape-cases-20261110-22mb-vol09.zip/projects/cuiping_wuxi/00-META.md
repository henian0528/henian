# 无锡翠屏（white2；或与翡翠屏为同一/相关案）

- 归档编号：`cuiping_wuxi`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `cuiping_wuxi_1.jpg` | `ad137364561e9bf2e16ae82ac0430051eb76990cc2becded110350a2dac4007b` | 1180170 | 是 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_1.jpg` |
| `cuiping_wuxi_2.jpg` | `e83fe05aa4019189c16b90c38c4bb00fddab1136104464352f718c0ffcd661ec` | 762819 | 是 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_2.jpg` |
| `cuiping_wuxi_3.jpg` | `8367716452f263acf532af67d60cf617fa1307cfaf5316e1077ab12029a9155a` | 1724422 | 是 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_3.jpg` |
| `cuiping_wuxi_4.jpg` | `705b7973fc661dccbd7dfc623076cf6d84b072a40b7a699709fe11d77f91ee23` | 1001609 | 是 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_4.jpg` |
| `cuiping_wuxi_5.jpg` | `5cb5fdc9bf07d689a155b849aef18b44c3339f95d752699e962d96d8e21ec838` | 599799 | 否 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_5.jpg` |
| `cuiping_wuxi_6.jpg` | `abffae5681266de9ff1e1b3a1fc4ed077120dca88685a1d6f2ab31106df6867b` | 939093 | 否 | `/workspace/landscape/china-canopy-cases/white2/cuiping_wuxi_6.jpg` |
