# the CORNER garden（上海，VIA）

- 归档编号：`corner_garden_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch30`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `corner_garden_shanghai_1.jpg` | `cc75c14283fed07ac7e26d9372cab3c8afcf25b912ed6e0c19803f548b333210` | 865856 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_1.jpg` |
| `corner_garden_shanghai_10.jpg` | `67c7a7394444f516deae5c549f826dded69227191020cf25512268827419bc80` | 391994 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_10.jpg` |
| `corner_garden_shanghai_2.jpg` | `70aa13a25a9a0b6d40998e870283c4fb9d8781b2594635fd6bd636f6fac89561` | 872201 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_2.jpg` |
| `corner_garden_shanghai_3.jpg` | `78d858eac9a4b3bad74e9511dd16d148d4e175076568646444af0170d48b0690` | 801039 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_3.jpg` |
| `corner_garden_shanghai_4.jpg` | `f17b4824cafe5e06d8ca24973190b814792f350d2140700f8acab3c8db2fa7a0` | 888401 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_4.jpg` |
| `corner_garden_shanghai_5.jpg` | `ddce311c7a8c911f6e4b33105b5d2196d7283c9fcf87e006cabc79bb34e08bb0` | 884942 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_5.jpg` |
| `corner_garden_shanghai_6.jpg` | `557f2e173bb90c1d66d73f51f14668286baccf3445214a0ff65c9e7a417e3366` | 826358 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_6.jpg` |
| `corner_garden_shanghai_7.jpg` | `bd04792487d0f57f7c9c4f75768c0748623bf86b66fae5c7060c164606f9e1de` | 864967 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_7.jpg` |
| `corner_garden_shanghai_8.jpg` | `674d71f7640e63bfe3747cf2e923d394ac965170aaecc5bd7fef0d8ec6949c34` | 825205 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_8.jpg` |
| `corner_garden_shanghai_9.jpg` | `4d239a64f9428b523e31725a5cb2ea8c648529e1baeab121712fee5bc7a3da4e` | 1146868 | 是 | `/workspace/landscape/batch30/corner_garden_shanghai_9.jpg` |
