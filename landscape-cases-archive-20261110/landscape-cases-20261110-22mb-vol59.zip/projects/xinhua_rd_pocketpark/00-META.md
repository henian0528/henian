# xinhua rd pocketpark

- 归档编号：`xinhua_rd_pocketpark`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：3 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（与 xinhua_mirror_garden 为同一项目，见 texts/original-*）
- 已有摘要：无本地 summary.md

## 同项目互见

与 `xinhua_mirror_garden` 为同一项目（新华路∞花园口袋公园）。2026-10-08 已发原文见该目录；本目录来自 batch12，部分配图哈希与 batch8 重合。

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xinhua_rd_pocketpark_1.jpg` | `95e25f555dd87d1e8344c557df44389466ceb0f0d4b31e573d5d285e4c35213f` | 320239 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_1.jpg` |
| `xinhua_rd_pocketpark_10.jpg` | `cbed74a3f67bc6452a2ec0de9b1d13078442de0ac77a117871976bda2845eeaf` | 512301 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_10.jpg` |
| `xinhua_rd_pocketpark_2.jpg` | `dff059562b2cba028c0611acb8e60d5e2e6c3012e02e7f717194bef360268b89` | 376497 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_2.jpg` |
| `xinhua_rd_pocketpark_3.jpg` | `bdce9919b3b578879844a2b19a895b7c9476e0a30e64c3343ee19b556f6e2639` | 292828 | 是 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_3.jpg` |
| `xinhua_rd_pocketpark_4.jpg` | `fd036e927c72f172b58545edb0addf782283a0e3240dc700551008d158f376c0` | 331380 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_4.jpg` |
| `xinhua_rd_pocketpark_5.jpg` | `8be663c5c77722380f377b82766d87e5a11337b21e6159c8d0565ee9408f8105` | 224037 | 是 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_5.jpg` |
| `xinhua_rd_pocketpark_6.jpg` | `6fed5777175d1bf486d4f293fe830a4924f90b5f7d70981e1f06b1f4a8728e2f` | 298855 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_6.jpg` |
| `xinhua_rd_pocketpark_7.jpg` | `fd89b42bc1eb002abc2902ad83a75edb1e39ca1e41f01dc53a976338ba023136` | 194693 | 是 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_7.jpg` |
| `xinhua_rd_pocketpark_8.jpg` | `4585279138beb19d9d4df7f844cd87b890b787cc13da794006a1146de18b7600` | 162998 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_8.jpg` |
| `xinhua_rd_pocketpark_9.jpg` | `739723ae846f259800546bec9fa1ab68ad1957def78c0d500cf57625fedabe34` | 284911 | 否 | `/workspace/landscape/batch12/xinhua_rd_pocketpark_9.jpg` |
