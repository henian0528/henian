# 新华路∞花园口袋公园

- 归档编号：`xinhua_mirror_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 同项目互见

本项目另有目录 `xinhua_rd_pocketpark`。与 `xinhua_mirror_garden` 为同一项目（新华路∞花园口袋公园）。2026-10-08 已发原文见该目录；本目录来自 batch12，部分配图哈希与 batch8 重合。

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xinhua_mirror_garden_1.jpg` | `1e01b98c251c5b37bfd2c125a39bb4240a44347efcb7a967d1c8e1ee12bd442f` | 287780 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_1.jpg` |
| `xinhua_mirror_garden_10.jpg` | `965bfe6a1995252364b62ca8b4d3e7e23b2e08bc30d2f970e30762efbe4c71bb` | 148041 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_10.jpg` |
| `xinhua_mirror_garden_2.jpg` | `bdce9919b3b578879844a2b19a895b7c9476e0a30e64c3343ee19b556f6e2639` | 292828 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_2.jpg` |
| `xinhua_mirror_garden_3.jpg` | `0bcd1eeff32e57689d8fe0ae113f7182004633b39cff8bd6e94586bf14cfb04b` | 260519 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_3.jpg` |
| `xinhua_mirror_garden_4.jpg` | `8be663c5c77722380f377b82766d87e5a11337b21e6159c8d0565ee9408f8105` | 224037 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_4.jpg` |
| `xinhua_mirror_garden_5.jpg` | `5335bb9826cc6e961d5ef0c271a498b948320dc8ca82235f266a0bf03afd5ddb` | 321837 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_5.jpg` |
| `xinhua_mirror_garden_6.jpg` | `fd89b42bc1eb002abc2902ad83a75edb1e39ca1e41f01dc53a976338ba023136` | 194693 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_6.jpg` |
| `xinhua_mirror_garden_7.jpg` | `b549c0561e095cf57e856ee6149b041c10c0cda43393ca019497c6e70adc7a64` | 231103 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_7.jpg` |
| `xinhua_mirror_garden_8.jpg` | `9b2d6ac67bebe9c0d44798066429e503d68da9cc70826c318c4f68ad67ecced9` | 302643 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_8.jpg` |
| `xinhua_mirror_garden_9.jpg` | `9a9c0c66d53d0ce781659308d9b10aca57569c39a889ea6bf121babbbdd3a7f4` | 141527 | 是 | `/workspace/landscape/batch8/xinhua_mirror_garden_9.jpg` |
