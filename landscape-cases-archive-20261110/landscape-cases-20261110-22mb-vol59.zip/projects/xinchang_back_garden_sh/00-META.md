# 新场古镇后花园（上海，UDG）

- 归档编号：`xinchang_back_garden_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch28`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xinchang_back_garden_sh_1.jpg` | `de0aa7f394d0eeac4fac524dc428352a817658f6358a1acd4e5bb183c60d44b4` | 279365 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_1.jpg` |
| `xinchang_back_garden_sh_10.jpg` | `c00eeeba4c4ba8aab59c3a220f11c0a7d7e87a68c220856aac8df83a59d50df6` | 196159 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_10.jpg` |
| `xinchang_back_garden_sh_2.jpg` | `deb41073405c114a41e002b26bbdd47186d70acec3dd748d43a0a2148fb7bcc6` | 275105 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_2.jpg` |
| `xinchang_back_garden_sh_3.jpg` | `fd07615838835063a2fba70dcd90a6cc3ba5d1680f8271b2c35768826f394e4e` | 282843 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_3.jpg` |
| `xinchang_back_garden_sh_4.jpg` | `ece6d5fa127fca3cd1492efcd419bfd8dede4cec45678f473c0252f3539da25e` | 251751 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_4.jpg` |
| `xinchang_back_garden_sh_5.jpg` | `1f3889b4642fff513fc9851a4a3cfc2cde3682b1d52a73fd3d7e0e8277f7ad9f` | 219177 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_5.jpg` |
| `xinchang_back_garden_sh_6.jpg` | `db7213f453cd0227edd5c93558bb79fa5a0ef045ce65904b690fca92f40042ac` | 247914 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_6.jpg` |
| `xinchang_back_garden_sh_7.jpg` | `b7479f5adf844a6be20ff4f97fcc4c30f81e80a07ea3f75378a68d608b61bd7c` | 187181 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_7.jpg` |
| `xinchang_back_garden_sh_8.jpg` | `0e43ccc8c5ed64016199f89b1a4dd6be715a1896e2be8713bb8f266f9a423872` | 158085 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_8.jpg` |
| `xinchang_back_garden_sh_9.jpg` | `2f6ddfeee625f4d022a10523a2d8d6de7e0232ef1611958daaced8686f8d8866` | 204156 | 是 | `/workspace/landscape/batch28/xinchang_back_garden_sh_9.jpg` |
