# 无锡惠山长安市民广场驿站（灰空间）

- 归档编号：`wuxi_changan_station`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch11`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wuxi_changan_station_1.jpg` | `5b14ad08d79c2e291f72b1fc7cf9ad38921ea59059d5d8248d63166cb66d4dc0` | 784920 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_1.jpg` |
| `wuxi_changan_station_10.jpg` | `35c727ba44636bf300c1a24227aead1164dd5df0011dcaadeb1872fab9cca1ac` | 242085 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_10.jpg` |
| `wuxi_changan_station_2.jpg` | `5391080831e77973179507f8bcda8a0d86d07ebef284fea8df3654876b3efb44` | 570316 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_2.jpg` |
| `wuxi_changan_station_3.jpg` | `e636762a06fe1048ac666bbeaa9ce7cdb8beab9090a94ef36e5ecafdb22dc6e9` | 668950 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_3.jpg` |
| `wuxi_changan_station_4.jpg` | `14755ce650c8f053eda02d7ee7f2c809b3e9dcd8da147050e8e9d985e090695f` | 1088702 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_4.jpg` |
| `wuxi_changan_station_5.jpg` | `a54c6ad700409501b98075a163ab0046f5f30aad289700e5bda9263cb8e1d88c` | 553219 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_5.jpg` |
| `wuxi_changan_station_6.jpg` | `3715904d1fd0d33701007a5ddc0ba2944dcf03d60d5483d75ef732d2d37347d8` | 464802 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_6.jpg` |
| `wuxi_changan_station_7.jpg` | `f3aabd18b281549664a87354cfaee3b968ad07eb342d1c7add3907461fcc805e` | 324439 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_7.jpg` |
| `wuxi_changan_station_8.jpg` | `31ca56a6a7f2d273926b06b0c18fd7a956291a81bd0e6055d47ab415d560acde` | 589789 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_8.jpg` |
| `wuxi_changan_station_9.jpg` | `f1a0940761e21ade70dfe7b984d22380c0f869c9641e0dfc79186f3c596b1775` | 200087 | 是 | `/workspace/landscape/batch11/wuxi_changan_station_9.jpg` |
