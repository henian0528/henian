# 小亮滩花园（成都，West 8）

- 归档编号：`xiaoliangtan_garden_chengdu`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch30`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xiaoliangtan_garden_chengdu_1.jpg` | `2d7b82dc90417a2e0fa1877ecf97d41455b31295160fd3110b1fe9d107b98720` | 759326 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_1.jpg` |
| `xiaoliangtan_garden_chengdu_2.jpg` | `59b22da35ca57365d97879863e6b72a0736ae3075009a9f044e5eb3e835ba133` | 923575 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_2.jpg` |
| `xiaoliangtan_garden_chengdu_3.jpg` | `71ed8a8b01344ed40ccc56cdaadd02407bac6d41aa25a489bd138ee114506f2a` | 486441 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_3.jpg` |
| `xiaoliangtan_garden_chengdu_4.jpg` | `44f171327a11f2f560490e4bc8aea7411f57b3ca6efcc7881a4c6eb18cd85427` | 481497 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_4.jpg` |
| `xiaoliangtan_garden_chengdu_5.jpg` | `c64fafcfe2c80e26cde409aa518e1205c90fa6572d35aa08d94e373e855b064c` | 682176 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_5.jpg` |
| `xiaoliangtan_garden_chengdu_6.jpg` | `38635c03eba32fa13b97f4009a7e1e7906720d5aebb18b800e9f93f3bdb80042` | 655843 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_6.jpg` |
| `xiaoliangtan_garden_chengdu_7.jpg` | `39404f859bbdd0527944e831c536e49396e27cbefc234aca497e4355987375a0` | 700368 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_7.jpg` |
| `xiaoliangtan_garden_chengdu_8.jpg` | `5eee17ddde2d859554b44a77d6aa09f86985ceb61e243ab3ed2f3a227960a2ff` | 377922 | 是 | `/workspace/landscape/batch30/xiaoliangtan_garden_chengdu_8.jpg` |
