# 信阳廊架（structures 早期批次）

- 归档编号：`xinyang_pergola`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 同项目互见

本项目另有目录 `baihuayuan_xinyang`。与 `xinyang_pergola` 为同一项目（信阳百花园曲廊与花亭，刘宇扬）。2026-10-08 已发原文见该目录；本目录为 2026-11-01 的另一批配图，哈希不同。

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xinyang_pergola_1.jpg` | `d4d6142f9b57989078d459184a48abfe50c80a6ab0df304b6736d5376ad7c642` | 205055 | 是 | `/workspace/landscape/structures/xinyang_pergola_1.jpg` |
| `xinyang_pergola_10.jpg` | `83741c083b3bb7739caaf0a1fce5419e822089f303c1e78ad45a4437f1f5de03` | 130640 | 是 | `/workspace/landscape/structures/xinyang_pergola_10.jpg` |
| `xinyang_pergola_2.jpg` | `433c3c50ed2f9acaf8cd2147f98f7956d735662b8ffb27e3d3c096d88be98b2d` | 176741 | 是 | `/workspace/landscape/structures/xinyang_pergola_2.jpg` |
| `xinyang_pergola_3.jpg` | `9b09966e5623cacadfa3767a0becb87adaffecae4aa608af183c3bb3401b5de9` | 172362 | 是 | `/workspace/landscape/structures/xinyang_pergola_3.jpg` |
| `xinyang_pergola_4.jpg` | `276f10972fd8177fd9ca8349cf490d516489e62d3052837a7271453fc754a97b` | 207313 | 是 | `/workspace/landscape/structures/xinyang_pergola_4.jpg` |
| `xinyang_pergola_5.jpg` | `f362782f411b42559b87d1049f05c7da629ed7c4df5a22af41bd3c8187a435af` | 190307 | 是 | `/workspace/landscape/structures/xinyang_pergola_5.jpg` |
| `xinyang_pergola_6.jpg` | `831db29d7bde0ccbf7a42ca4f5964fb8fdbbe49192a07fe4f44156ab983b9824` | 254929 | 是 | `/workspace/landscape/structures/xinyang_pergola_6.jpg` |
| `xinyang_pergola_7.jpg` | `e956cb1d825eb0d124ac29f1c7f79e16b1a0148cbea6bfa3510d47b30b2d00a3` | 235874 | 是 | `/workspace/landscape/structures/xinyang_pergola_7.jpg` |
| `xinyang_pergola_8.jpg` | `331e5502948b42735d258b8e1d92448ff77a6cd8e01f1ffca114c32abaa06dcc` | 184918 | 是 | `/workspace/landscape/structures/xinyang_pergola_8.jpg` |
| `xinyang_pergola_9.jpg` | `578f79e7514bfd97ea3e9152cafc6112ab0b44060075c7cfac8165b432a4b663` | 197741 | 是 | `/workspace/landscape/structures/xinyang_pergola_9.jpg` |
