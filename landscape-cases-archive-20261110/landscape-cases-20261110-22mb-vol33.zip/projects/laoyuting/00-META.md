# 捞鱼亭 / Laoyuting Pavilion（大舍）

- 归档编号：`laoyuting`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：群聊工作日日推（目录与来源页为捞鱼亭；原文未从对话记录回读）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-13`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `laoyuting_10_axono.jpg` | `8ce1c121b81115a3814c1f86f9785565e1c3908077bee3618c046648ca353c78` | 310262 | 是 | `/workspace/landscape/2026-10-13/laoyuting_10_axono.jpg` |
| `laoyuting_1_entrance_cypress.jpg` | `129c66f63b4859b6742f49b1656b7fecab7132d6d902a59198ccfe1619736b9e` | 3452151 | 是 | `/workspace/landscape/2026-10-13/laoyuting_1_entrance_cypress.jpg` |
| `laoyuting_2_aerial_wetland.jpg` | `f76387cb0e62b44dfbfc64eae7c9b6ef6eb2b4f1648c183750f2c21d38ffe5aa` | 1412909 | 是 | `/workspace/landscape/2026-10-13/laoyuting_2_aerial_wetland.jpg` |
| `laoyuting_3_hipped_silhouette.jpg` | `b414dcb932e714e15a7e406ffaae8626c56cca60e5b1d25145d678897ba6230d` | 3752193 | 是 | `/workspace/landscape/2026-10-13/laoyuting_3_hipped_silhouette.jpg` |
| `laoyuting_4_fragmented_roof.jpg` | `48e56b7e24e0627e74f8f48e27e1c68754f466ba637c90683a4547791e8953d9` | 2534517 | 是 | `/workspace/landscape/2026-10-13/laoyuting_4_fragmented_roof.jpg` |
| `laoyuting_5_column_field.jpg` | `e4ee6e6f32160a5db67642439941a1b1d00f2c9ee2c692741ff1efbab0c1bce6` | 3314447 | 是 | `/workspace/landscape/2026-10-13/laoyuting_5_column_field.jpg` |
| `laoyuting_6_inside_light.jpg` | `fbecf4e65447c7386242bce54e6aa9eea8e4748a2446547371d16e088e540f3c` | 3022543 | 是 | `/workspace/landscape/2026-10-13/laoyuting_6_inside_light.jpg` |
| `laoyuting_7_inside_path.jpg` | `70440e02656ae50d8c6943c067d62d8f235e074ca66058478e4c8403e67ae4ec` | 3106841 | 是 | `/workspace/landscape/2026-10-13/laoyuting_7_inside_path.jpg` |
| `laoyuting_8_site_plan.jpg` | `bf20af1dce1c101d428f622d30fd4ad8ff3199cb5007b07b6233461b6285ac7c` | 1388421 | 是 | `/workspace/landscape/2026-10-13/laoyuting_8_site_plan.jpg` |
| `laoyuting_9_plan.jpg` | `4dbb22db3fc614e6d76195597e51a1adcd987dbf25a4583f91f8a448a792c45b` | 212947 | 是 | `/workspace/landscape/2026-10-13/laoyuting_9_plan.jpg` |
