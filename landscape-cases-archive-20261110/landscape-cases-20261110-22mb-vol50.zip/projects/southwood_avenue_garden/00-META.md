# 北伦敦三角形小花园（Stefano Marinaz）

- 归档编号：`southwood_avenue_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `southwood_avenue_garden_1.jpg` | `767030d752b472d896bdd95d73113ca5a9ddf625db2bae65218e474239079022` | 681249 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_1.jpg` |
| `southwood_avenue_garden_10.jpg` | `7bf72fe4778486fd261b06d22c6ef41502c00170a834b5b23d4ee61a712b5fda` | 246824 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_10.jpg` |
| `southwood_avenue_garden_2.jpg` | `8c767b0f4ee6ab8d104f7b9ecef2a3481d88d3a02581bc90f8411b3ce6e8a9c5` | 532278 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_2.jpg` |
| `southwood_avenue_garden_3.jpg` | `c980aeee09770f631a4acde3ffa6d10d6b2c7a9bf1b4dc91552697dbe83dced0` | 228223 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_3.jpg` |
| `southwood_avenue_garden_4.jpg` | `0b3175db49ba56290714d998cd1ef58534c82e777c3610265d79cf9ba1a4a77d` | 222823 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_4.jpg` |
| `southwood_avenue_garden_5.jpg` | `799384a3f7b716751695f8876521742ea352c52736f87e47e89f254378b32ce1` | 231022 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_5.jpg` |
| `southwood_avenue_garden_6.jpg` | `64113e0dc06ae729c7227f344ce1799dda7aa0f158c21972f6783c7de7abdbca` | 205930 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_6.jpg` |
| `southwood_avenue_garden_7.jpg` | `ad8b6164b2e599fa8f4a4df59b149f32e5015950fb2efe6edb82147efbde43ae` | 124216 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_7.jpg` |
| `southwood_avenue_garden_8.jpg` | `315ef563688aa2e2afe1a7f1bc7f2026d7e3e4c0b8764d9a2585467cfbfc1e1b` | 109623 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_8.jpg` |
| `southwood_avenue_garden_9.jpg` | `032c91d7b7759628659d3f893fd89ae4801c27f6de0efa7fe359f199d23e51ad` | 281275 | 是 | `/workspace/landscape/batch33/southwood_avenue_garden_9.jpg` |
