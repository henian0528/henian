# 深圳大鹏新区星火探索营廊架（厘米制造）

- 归档编号：`starfire`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-21
  - 出处说明：工作日目录：星火探索营廊架。原文未从对话记录回读
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-21`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `starfire_10_section_details.jpg` | `9157a5297e75fa47b64640905687cf99eb95c89a7e188725f15627bb37dd4664` | 646537 | 是 | `/workspace/landscape/2026-10-21/starfire_10_section_details.jpg` |
| `starfire_1_hero.jpg` | `92ed97b96d585f1ef59b631c015f3108029d53468608c94f7738e66e86c39fd8` | 1086385 | 是 | `/workspace/landscape/2026-10-21/starfire_1_hero.jpg` |
| `starfire_2_aerial.jpg` | `4a2066f9bdbf5092e29e59beeaa3e657bb237ff620f8a8ed5c59f8ffe01905e9` | 867356 | 是 | `/workspace/landscape/2026-10-21/starfire_2_aerial.jpg` |
| `starfire_3_double_roof.jpg` | `7f92d95bfce670a2e8e6a22cba10293573c7903f4a00dcf85f89a1b6637be72a` | 1459922 | 是 | `/workspace/landscape/2026-10-21/starfire_3_double_roof.jpg` |
| `starfire_4_under_eaves.jpg` | `ce17f0f5efbce41c3ac20434b9f7ea4509a495744c1fd11e06110ccda57c0f12` | 1211664 | 是 | `/workspace/landscape/2026-10-21/starfire_4_under_eaves.jpg` |
| `starfire_5_translucent_bay.jpg` | `621cf6d15655b08ebabc3077275c42ac7a47095d6dba88ab6317fed5cf3af80d` | 1339487 | 是 | `/workspace/landscape/2026-10-21/starfire_5_translucent_bay.jpg` |
| `starfire_6_trees_through.jpg` | `74a01020871e2e9749b8f3cca5c6f969188e0d4cc3e45313ba9a069d3ee5b420` | 1195386 | 是 | `/workspace/landscape/2026-10-21/starfire_6_trees_through.jpg` |
| `starfire_7_column_head.jpg` | `34b8cdb4697362666bc7aa3cdfbca49c04d1f7db29887b388e3c4eae92d06478` | 1017549 | 是 | `/workspace/landscape/2026-10-21/starfire_7_column_head.jpg` |
| `starfire_8_site_plan.jpg` | `5e237dd67ba993ee3ef1ebc1f732fae50a26f4d102f6e125c711e3cc8a42995e` | 1319126 | 是 | `/workspace/landscape/2026-10-21/starfire_8_site_plan.jpg` |
| `starfire_9_plan_elevation.jpg` | `2ee7bf437c099b9fa940c3f62c50dd523416408bf93f7e86099f42a900829176` | 226395 | 是 | `/workspace/landscape/2026-10-21/starfire_9_plan_elevation.jpg` |
