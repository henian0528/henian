# 哥本哈根 SuperKilen 超级线性公园

- 归档编号：`superkilen`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：群聊工作日日推（期刊：当天早8:13群推失败，案例已准备；后补情况见缺失清单）
  - 发送判断：`prepared`
  - 本地来源：`/workspace/landscape/2026-10-08`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `superkilen_1.jpg` | `8edf58ba53c62f9879f0d089d0289eb24c349b5b8a9eb2b26d7f2eed03a72398` | 893355 | 是 | `/workspace/landscape/2026-10-08/superkilen_1.jpg` |
| `superkilen_2.jpg` | `26a4787f682ab6d121b3a95048f1b50fa74f8df15c71113529f67829e1ccc08a` | 768212 | 是 | `/workspace/landscape/2026-10-08/superkilen_2.jpg` |
| `superkilen_3.jpg` | `9bd902b21e2391e1db7aaa0d4f9acf00b06cb6683df0b8a6263b8fd1babbb7cb` | 560139 | 是 | `/workspace/landscape/2026-10-08/superkilen_3.jpg` |
| `superkilen_4.jpg` | `60139ed63144835a8bcaebef0a723df5039b81ebcc82f8c4ef48263a1fdc161d` | 698597 | 是 | `/workspace/landscape/2026-10-08/superkilen_4.jpg` |
| `superkilen_5.jpg` | `6ec70a2de800898c66d78bd3e823622722e56819b9dc73a461342be7c74f6d13` | 911267 | 是 | `/workspace/landscape/2026-10-08/superkilen_5.jpg` |
| `superkilen_6.jpg` | `da13e1f15f5af622762cbd73611eaa4adcb4711d5eb0b7ec85520b1702dc6892` | 710540 | 是 | `/workspace/landscape/2026-10-08/superkilen_6.jpg` |
