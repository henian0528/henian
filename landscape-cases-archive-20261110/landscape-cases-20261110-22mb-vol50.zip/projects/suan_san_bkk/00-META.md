# Suan San 口袋公园（曼谷，Shma）

- 归档编号：`suan_san_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `suan_san_bkk_1.jpg` | `c7deffd0527891d78e58db61cb494c1d2284d2c1f952ec0e0f34badffd6dc12a` | 303925 | 是 | `/workspace/landscape/batch26/suan_san_bkk_1.jpg` |
| `suan_san_bkk_2.jpg` | `fafd1abd89e6d7f1fdd833853769578c8acd4ad19f66237d81b397f3db5e8646` | 276775 | 是 | `/workspace/landscape/batch26/suan_san_bkk_2.jpg` |
| `suan_san_bkk_3.jpg` | `61cb628dd5a475b60a8ac59d0b1485c2b1d79a61e0f8aff5b3c1c7b8e2b3ea64` | 271684 | 是 | `/workspace/landscape/batch26/suan_san_bkk_3.jpg` |
| `suan_san_bkk_4.jpg` | `0ff5947a5736b84e051bff56ad7128b35a06db2293e794e59c790b023b543b87` | 340513 | 是 | `/workspace/landscape/batch26/suan_san_bkk_4.jpg` |
| `suan_san_bkk_5.jpg` | `9c7d4affa4dc1a913bd4cbcb97cc1b61f9f4fd5f91a83a9ec5ed97e04ffea04f` | 303679 | 是 | `/workspace/landscape/batch26/suan_san_bkk_5.jpg` |
| `suan_san_bkk_6.jpg` | `5d06dbbcc186e3a82b3d361aaf55bb32b555427ccaadedd96107193027363a6f` | 303477 | 是 | `/workspace/landscape/batch26/suan_san_bkk_6.jpg` |
| `suan_san_bkk_7.jpg` | `b6e59a5b465fc01d2e250b3507a5b96e4aa4c78a2f6fc4d098eca7a63158e5be` | 272688 | 是 | `/workspace/landscape/batch26/suan_san_bkk_7.jpg` |
| `suan_san_bkk_8.jpg` | `50ae7675df40cf8399b3bfb75c8522899ef536ddc28996212dfcdf9ef8fb9ef7` | 260397 | 是 | `/workspace/landscape/batch26/suan_san_bkk_8.jpg` |
| `suan_san_bkk_9.jpg` | `7fa96189bfd2039f092070c676ed4418270108ba622a86fad5e8f6ec32d4bcdc` | 312722 | 是 | `/workspace/landscape/batch26/suan_san_bkk_9.jpg` |
