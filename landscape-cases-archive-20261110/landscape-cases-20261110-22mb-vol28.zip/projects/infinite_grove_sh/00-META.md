# 无限丛林／Infinite Grove（上海，batch15）

- 归档编号：`infinite_grove_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch15`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `infinite_grove_sh_1.jpg` | `1c0c66e5a9603cfab2794b9d1fc626d6150a45711f661d6abbed5fa2e3f14614` | 280127 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_1.jpg` |
| `infinite_grove_sh_10.jpg` | `62b9d39edf9f10d56b4a368f7cfd595a274d3227cdddbcfb0cb1718c64673f24` | 223432 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_10.jpg` |
| `infinite_grove_sh_2.jpg` | `377d999fc821a8a6544e15bdd158ec5a790f44ce9b6390ed7e7728decdf71ee6` | 251293 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_2.jpg` |
| `infinite_grove_sh_3.jpg` | `d9484b11b19dc791af8bafc3bbed1bf488a0a8db964110b496395720ae217279` | 263651 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_3.jpg` |
| `infinite_grove_sh_4.jpg` | `b24c63a902ee34bcd9a2c3dd34c698af80bf84f639f2da81b740004ee573522d` | 392218 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_4.jpg` |
| `infinite_grove_sh_5.jpg` | `d1b469696c15db670e1e8c1f877818d237e852224407293e37850a998efda136` | 184681 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_5.jpg` |
| `infinite_grove_sh_6.jpg` | `1af2f07a560782d8e0dc0c5648be2b4ff07ad97fbc1e93c13ead0a91674b79c3` | 252419 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_6.jpg` |
| `infinite_grove_sh_7.jpg` | `b985c6159ce2c7a024d76f2b0ac6e361e3f17679d64c2aa63d19dae1536f7630` | 319700 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_7.jpg` |
| `infinite_grove_sh_8.jpg` | `f46023e4c928ae7487def35c5de7ac0910ac4f0846c6ede7147b997e5e6f6f4a` | 256808 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_8.jpg` |
| `infinite_grove_sh_9.jpg` | `fc825e2aca5a82c82072f378fa88efb680763f7c2c247e4e6ad8c3e91008fe12` | 255093 | 是 | `/workspace/landscape/batch15/infinite_grove_sh_9.jpg` |
