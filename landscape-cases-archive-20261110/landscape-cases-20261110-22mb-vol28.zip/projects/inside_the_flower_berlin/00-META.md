# Inside the Flower（柏林 IGA，Janet Laurence 和 LAVA）

- 归档编号：`inside_the_flower_berlin`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch16`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `inside_the_flower_berlin_1.jpg` | `15c6f5d69d89361aca27aced4437b9c2e375e6f19841207f456b18c7a4a37968` | 717548 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_1.jpg` |
| `inside_the_flower_berlin_2.jpg` | `3d297a1016140d1c520bcf2517d86071a39c673cf3fede23067bc1cc728348c0` | 609606 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_2.jpg` |
| `inside_the_flower_berlin_3.jpg` | `1e71b951df7cac3695af10f00d28386479ea12f194cabf567035cb9ae28071b3` | 522105 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_3.jpg` |
| `inside_the_flower_berlin_4.jpg` | `d30b88a04313905d94851227d14d534ff9b75eb3926ad359c200d51d04da7ce8` | 607490 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_4.jpg` |
| `inside_the_flower_berlin_5.jpg` | `f060e80d439ae1431b83761df9fbf54c2309316f065822de6730b3ef09efd5fe` | 371300 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_5.jpg` |
| `inside_the_flower_berlin_6.jpg` | `5fede674e89559c203ce952c1a5d060d28426223c0bc813c5a114fc1b307ca97` | 447251 | 是 | `/workspace/landscape/batch16/inside_the_flower_berlin_6.jpg` |
