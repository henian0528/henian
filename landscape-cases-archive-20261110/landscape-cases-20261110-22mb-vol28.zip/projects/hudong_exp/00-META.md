# 沪东实验（浦东，VIA）

- 归档编号：`hudong_exp`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：11
- 在 bot 附件库中匹配到的配图：10 / 11（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch10`
  - 本记录配图文件数：11

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hudong_exp_1.jpg` | `73106bea0d36fc3ddc2e0112e1a8441c7b95dfc3052aaa2026892a1bd085ef2e` | 270088 | 是 | `/workspace/landscape/batch10/hudong_exp_1.jpg` |
| `hudong_exp_10.jpg` | `ecf03fafd8ed0586ca54e6023822261aa7defca5561b1519ece11c825a69ceaa` | 203998 | 是 | `/workspace/landscape/batch10/hudong_exp_10.jpg` |
| `hudong_exp_11.jpg` | `24a573afe152edee84e21c140b0361d85a2c80a3a23ea1640e9b4fb24d51f1cf` | 259547 | 否 | `/workspace/landscape/batch10/hudong_exp_11.jpg` |
| `hudong_exp_2.jpg` | `e46688f13b0b8dbcc8f993603c1c47a51dd53e22ac9dfbd6cae6b81f71b26da9` | 561671 | 是 | `/workspace/landscape/batch10/hudong_exp_2.jpg` |
| `hudong_exp_3.jpg` | `119d49f0321e7a07eae15506ab539566ab68894d2106e8ae90a90c14617377d6` | 279841 | 是 | `/workspace/landscape/batch10/hudong_exp_3.jpg` |
| `hudong_exp_4.jpg` | `cd5a3333002bf82075e796d3d8013b2b89eda7f0c968a86b43187c787cd0c71c` | 338471 | 是 | `/workspace/landscape/batch10/hudong_exp_4.jpg` |
| `hudong_exp_5.jpg` | `8a99091a9c212ce200fe627417700f0d11aea27ead461e91695c244d7103d401` | 240911 | 是 | `/workspace/landscape/batch10/hudong_exp_5.jpg` |
| `hudong_exp_6.jpg` | `6282ca24ba55a354987be09f829be57d3413dfaa9a900c9d46119ebe95a24e44` | 211566 | 是 | `/workspace/landscape/batch10/hudong_exp_6.jpg` |
| `hudong_exp_7.jpg` | `9f44f5f09b4830fbe26bd8d94dc745e9eea6295898565fd182c5914d09f3e79f` | 377996 | 是 | `/workspace/landscape/batch10/hudong_exp_7.jpg` |
| `hudong_exp_8.jpg` | `05816a99469718eedd6e7753653e6a7d11bf6e03d482d258c6295305564c37d5` | 239442 | 是 | `/workspace/landscape/batch10/hudong_exp_8.jpg` |
| `hudong_exp_9.jpg` | `74a98e532b627c5f7e7b55a5729dce2f0b76401123872c72096a13df4aee35b1` | 212754 | 是 | `/workspace/landscape/batch10/hudong_exp_9.jpg` |
