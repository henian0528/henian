# 蝴蝶驿站（合肥派园）

- 归档编号：`hudie_hefei`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-02
  - 出处说明：日期目录 2026-11-02（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-02/hudie_hefei`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hd_01_photo_morning.jpg` | `144557451056455de24819889345290605fe68cb3a47e28213dda8832382f959` | 966640 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_01_photo_morning.jpg` |
| `hd_02_photo_fields.jpg` | `b7af7f6aa5c37b0e646a1540f5c0c3bc9e7ab15edaf6505aa4afc1e72c69f1a1` | 803517 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_02_photo_fields.jpg` |
| `hd_03_photo.jpg` | `16eebe93ac8b941e9c8d776fffe5a8d2d5bbe4e5f5db4807cb4f4657f8582a06` | 679328 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_03_photo.jpg` |
| `hd_04_photo.jpg` | `ac87f8f2c2790b1db6af54986292f0bfc85b30b805936658d6a9eb5ef49c0e90` | 590457 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_04_photo.jpg` |
| `hd_05_photo.jpg` | `1f10b23f514e08a13ba388c987c040a29486775568390e3fdffce30e8bcdbe4a` | 630179 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_05_photo.jpg` |
| `hd_06_photo_night.jpg` | `562167fadb305a4a914d1e8e603e24f5a0f4dbbecb69fc68729f564c168ed5cf` | 566555 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_06_photo_night.jpg` |
| `hd_07_drawing_plan_1f.jpg` | `7fa2da8b4e0dd41b7afd23096a0fc9cd771f60941120b629909e342e659a461b` | 695034 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_07_drawing_plan_1f.jpg` |
| `hd_08_drawing_axo.jpg` | `cfa519e2f8525d554b03f675ccda78bf49df137514b85253dec4b88d9daed8ce` | 291506 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_08_drawing_axo.jpg` |
| `hd_09_drawing_elevation_north.jpg` | `d8285add2f5885cb1096f685bbd951b229719f76a05ad11fec93485858a85e97` | 82482 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_09_drawing_elevation_north.jpg` |
| `hd_10_drawing_detail_wall.jpg` | `73832402baa8d35dc97b1b209916eb51086ab77de4ce10a67e0cff2e9abde524` | 333275 | 否 | `/workspace/landscape/2026-11-02/hudie_hefei/hd_10_drawing_detail_wall.jpg` |
