# 步花洄／铁岗河驿站（惠州，大料建筑）

- 归档编号：`buhuahui_huizhou`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-09
  - 出处说明：日期目录 2026-11-09（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-09/buhuahui_huizhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bh_01_photo_overview.jpg` | `cc2b2745475523ef707545c2c6d6767a8e5960175163c325145a7e26d272896e` | 436382 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_01_photo_overview.jpg` |
| `bh_02_photo_bamboo.jpg` | `1011a1ae3e920bca76db39cacc239987b266293d89fe4845cd5663cd8b733dd6` | 496223 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_02_photo_bamboo.jpg` |
| `bh_03_photo_plaza.jpg` | `8fb61a46c5a6374a749f2d1e5c27d85d80456513f34f8f73f92b7b0a5cba24fc` | 484140 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_03_photo_plaza.jpg` |
| `bh_04_photo_boxes.jpg` | `f04824f68b34966e0c554db50bb5180a32632c0d5caa609eae00af2df1fbf0c4` | 224437 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_04_photo_boxes.jpg` |
| `bh_05_photo_corridor.jpg` | `efea50e24843a47b15af0b692543f6f3528ae0cbd386e149fff79ab08e6e9283` | 297867 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_05_photo_corridor.jpg` |
| `bh_06_photo_flowerhall.jpg` | `510b230bb5152a9150419aed1ff4656663cde540b39d6f21701f635a68191daa` | 190080 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_06_photo_flowerhall.jpg` |
| `bh_07_photo_swings.jpg` | `5c2e8935deb5dc7039ccd540ef6427e336c0618b3017a98c0b3daa3b4e507cf3` | 402296 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_07_photo_swings.jpg` |
| `bh_08_drawing_diagram.jpg` | `f2905fc75e27df656425c3bbf062acad9dd1ed2f3c0b17203911e2a73fcf0695` | 480201 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_08_drawing_diagram.jpg` |
| `bh_09_drawing_siteplan.jpg` | `8714e779986e270b03563348b0ff93351efa3133d05b949d276606faf531be01` | 76703 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_09_drawing_siteplan.jpg` |
| `bh_10_drawing_plan_section.jpg` | `f12f846549d1385df11587711a2583255f5c242e01eb7e47d3c6c247a6a52cdb` | 59641 | 否 | `/workspace/landscape/2026-11-09/buhuahui_huizhou/bh_10_drawing_plan_section.jpg` |
