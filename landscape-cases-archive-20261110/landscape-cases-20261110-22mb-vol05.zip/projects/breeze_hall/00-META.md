# Breeze Hall（white3）

- 归档编号：`breeze_hall`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white3）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white3`
  - 注：来源 china-canopy-cases/white3
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `breeze_hall_1.jpg` | `d6445ade4ff4a302370d48112a45b00077d6287b6e42819b0a5d44ed5f099a7b` | 152556 | 是 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_1.jpg` |
| `breeze_hall_2.jpg` | `ea215bb3a9719107b1a49908cf212d681ed267aac485976ac9c40d6de194b132` | 154808 | 是 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_2.jpg` |
| `breeze_hall_3.jpg` | `156f722015387cd27f08b36e40ddc18041ff23c0ec36982a045a9255cc1488b6` | 227916 | 是 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_3.jpg` |
| `breeze_hall_4.jpg` | `ea4dc007ef97f08d607faff0a5bccf1f6a474e70c59c960e1aebc0bfd1889043` | 280707 | 是 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_4.jpg` |
| `breeze_hall_5.jpg` | `364c070343c6f3c42ce3935b3a016a224fced436ecbfa2b66d2ffa98e83c5606` | 214692 | 否 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_5.jpg` |
| `breeze_hall_6.jpg` | `ff1c02e9a6c845f3f1397c24f4be72cb098e87e55276c7bca0812f3a08a9a4f2` | 269407 | 否 | `/workspace/landscape/china-canopy-cases/white3/breeze_hall_6.jpg` |
