# Brnox 街角公园（布尔诺）

- 归档编号：`brnox_patch_brno`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `brnox_patch_brno_1.jpg` | `9b6b83ae71bd3c57246407485f6d0d57063f1d22567b5b42509501c2e3872aa0` | 185956 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_1.jpg` |
| `brnox_patch_brno_2.jpg` | `398a22b1d47e85e844dd78d974c71ed022ed71f451e99c510f086cf7778a2c28` | 405228 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_2.jpg` |
| `brnox_patch_brno_3.jpg` | `06923f1d84635af790d7c568c8ee396fa1c506cd97f417b405d21495a5d16644` | 426379 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_3.jpg` |
| `brnox_patch_brno_4.jpg` | `792b4dd644dc61cbee2247ac1d2297c6d6192985a44e76b4d40f389380a4a815` | 328050 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_4.jpg` |
| `brnox_patch_brno_5.jpg` | `8893c7924944fe2963186959f043327b0dd90ce85b559e046e215679b34ef55d` | 277770 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_5.jpg` |
| `brnox_patch_brno_6.jpg` | `fd2a78b2170fd3b2d38097e6c4b651a6eeed87b27ce165a14095000b7f907c1e` | 281485 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_6.jpg` |
| `brnox_patch_brno_7.jpg` | `c84d80c181066db230607ca7667a97a5f2740008429b1ba83f7570df6145bd2d` | 375633 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_7.jpg` |
| `brnox_patch_brno_8.jpg` | `386db935fd12a6ece7165b83db04b10901b7a019e97c8b3126b79359b95e1021` | 370249 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_8.jpg` |
| `brnox_patch_brno_9.jpg` | `d611ea075984c2347ffecd8b0e96255d97d205a094955f3fb3b2daf76cd6138d` | 207526 | 是 | `/workspace/landscape/batch26/brnox_patch_brno_9.jpg` |
