# BUS:STOP Krumbach（奥地利）

- 归档编号：`busstop_krumbach`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `busstop_krumbach_1.jpg` | `db349dc2e3f8579279b0aa9c017aaac150d0bf42651e46b9ba790bda487c8698` | 577157 | 是 | `/workspace/landscape/batch9/busstop_krumbach_1.jpg` |
| `busstop_krumbach_2.jpg` | `16c3bffb6588962601e7e685418548dfcb300e70f60f85207c238a653c29e773` | 677590 | 是 | `/workspace/landscape/batch9/busstop_krumbach_2.jpg` |
| `busstop_krumbach_3.jpg` | `6b38b316557807230db742c0d6c5bcc932a25af7201243a95b4c5723498d6db7` | 646870 | 是 | `/workspace/landscape/batch9/busstop_krumbach_3.jpg` |
| `busstop_krumbach_4.jpg` | `504c0f4bf5b941c4f1d9cd4f7e026818f45de60116adadf579fb883d836fed54` | 514599 | 是 | `/workspace/landscape/batch9/busstop_krumbach_4.jpg` |
| `busstop_krumbach_5.jpg` | `19316d47b5e5c664736330b94650fe349298a552419eacc152ba44a5fdfd2842` | 470052 | 是 | `/workspace/landscape/batch9/busstop_krumbach_5.jpg` |
| `busstop_krumbach_6.jpg` | `ebe2e78f69cc6aed066abf22f6e24e10d2324ed080d704f5496029ff040e1f84` | 693142 | 是 | `/workspace/landscape/batch9/busstop_krumbach_6.jpg` |
| `busstop_krumbach_7.jpg` | `dad2740221905bb15b92e2ec9c1fb0da910a0355519f310d14e3bcbca4390be0` | 614443 | 是 | `/workspace/landscape/batch9/busstop_krumbach_7.jpg` |
| `busstop_krumbach_8.jpg` | `1c863583fe9403e825bbfd06493eb92f8359d9e8763196b2639617e945bf49ea` | 481070 | 是 | `/workspace/landscape/batch9/busstop_krumbach_8.jpg` |
