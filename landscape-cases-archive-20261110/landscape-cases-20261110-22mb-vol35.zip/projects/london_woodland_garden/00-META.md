# 伦敦小林地花园（Alasdair Cameron）

- 归档编号：`london_woodland_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch33`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `london_woodland_garden_1.jpg` | `1f87aea6e06c0f942ec5060b3b88578314436d9b0785890474a59144e2b57972` | 1614654 | 是 | `/workspace/landscape/batch33/london_woodland_garden_1.jpg` |
| `london_woodland_garden_2.jpg` | `e8fb8a0303e1f601198bc43e4ea2a4c4b3728a928844ac1d0262ccb0df899af8` | 1192860 | 是 | `/workspace/landscape/batch33/london_woodland_garden_2.jpg` |
| `london_woodland_garden_3.jpg` | `2bde2db6c8fd23e01489123a163c8dae8292bb7bddf114713b56525b07c1f7ac` | 1344597 | 是 | `/workspace/landscape/batch33/london_woodland_garden_3.jpg` |
| `london_woodland_garden_4.jpg` | `7178704a93220e201d8f3f2feb1d8727b9d7c7a64dae1998e9951cfea61c284f` | 1263213 | 是 | `/workspace/landscape/batch33/london_woodland_garden_4.jpg` |
| `london_woodland_garden_5.jpg` | `bcea7bbfb7fdf3f79efc1538e164c42f4b70c07211c378bd0b8baee85ebc0e02` | 1159380 | 是 | `/workspace/landscape/batch33/london_woodland_garden_5.jpg` |
| `london_woodland_garden_6.jpg` | `e985c98565ff311e46534af508fc8021b18b420f985a5e6003593e40d234daa0` | 1070681 | 是 | `/workspace/landscape/batch33/london_woodland_garden_6.jpg` |
