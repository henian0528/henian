# 灵境胡同地铁口口袋公园

- 归档编号：`lingjing_pocket_park`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `lingjing_pocket_park_1.jpg` | `992a8f6147f84e8d9fd015f419052280a26711034aa11d5daa0bea8574c57a3f` | 306557 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_1.jpg` |
| `lingjing_pocket_park_10.jpg` | `6d54552b4fcc9d7b7a754a63717367ffb20a4476de5c2809e25ccf16412f2150` | 37629 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_10.jpg` |
| `lingjing_pocket_park_2.jpg` | `b3d8a9c0b48e6fe3bb47dbb33d24d085862294b6e86a9045cd9192cfd2a06772` | 199269 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_2.jpg` |
| `lingjing_pocket_park_3.jpg` | `843729f3895f9381a777bfdd37ed9cc177951c0b58f8f867cd8828fb88ce4b02` | 231360 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_3.jpg` |
| `lingjing_pocket_park_4.jpg` | `a7b64137364e90a24845c0c20c846904606772974d001918b7780d9c7e7df25e` | 232690 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_4.jpg` |
| `lingjing_pocket_park_5.jpg` | `c7511c52991d661613a42907c91c227d2e183542f5a5d7e9533d43d959408156` | 508788 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_5.jpg` |
| `lingjing_pocket_park_6.jpg` | `dba50823cbf04c7cdd4b539afbc678441f7352bc941d1990e4ba60ef2d7d9506` | 434182 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_6.jpg` |
| `lingjing_pocket_park_7.jpg` | `01bfef67502bfba8a677833b5687f2f088ac4445a17056e13e41d38f75475640` | 267244 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_7.jpg` |
| `lingjing_pocket_park_8.jpg` | `8bdadde989c178485b0fe8cad2c98299a5db7c68eea1fce5104bba9ff52dfbed` | 119337 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_8.jpg` |
| `lingjing_pocket_park_9.jpg` | `bddf093ef9c2fb685aa5eb8c9faba9d710b45ace3aa7d26b2416935fbe5b71af` | 55730 | 是 | `/workspace/landscape/batch8/lingjing_pocket_park_9.jpg` |
