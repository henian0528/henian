# 两江新宸别墅庭院（MUSO 木守）

- 归档编号：`liangjiang_xinchen_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：7 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `liangjiang_xinchen_garden_cq_1.jpg` | `5a1c91027989fdd286720dc368a151a62c1c5fdaaa3ac63cca341a06f5331da0` | 918218 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_1.jpg` |
| `liangjiang_xinchen_garden_cq_2.jpg` | `72be7d689a6573d71862736cb46fa566871e82f8f1d5912785a0b3a42144d647` | 910157 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_2.jpg` |
| `liangjiang_xinchen_garden_cq_3.jpg` | `b5499729e012dd038d1c479f9678193f08b1e8a29e2b069698dec676874038bc` | 742025 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_3.jpg` |
| `liangjiang_xinchen_garden_cq_4.jpg` | `5e0ac72e9a4aa312f64a1dae21ace2837da93e7bf31b996c57dad37e1abd740e` | 685336 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_4.jpg` |
| `liangjiang_xinchen_garden_cq_5.jpg` | `c14940e0895afa2e12034a075419e8cb77dbb5496db70744c60a9e696059fc92` | 767619 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_5.jpg` |
| `liangjiang_xinchen_garden_cq_6.jpg` | `c96235c6df8174fd8cb2ef2038e07c07dc1427e6ac4be8d37dbdebc2706ae4af` | 580286 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_6.jpg` |
| `liangjiang_xinchen_garden_cq_7.jpg` | `8ea74c58b2b043dc6564cef460256789aeb6fc1acde4fbe907dbb0fa6ee316b9` | 532470 | 是 | `/workspace/landscape/batch20/liangjiang_xinchen_garden_cq_7.jpg` |
