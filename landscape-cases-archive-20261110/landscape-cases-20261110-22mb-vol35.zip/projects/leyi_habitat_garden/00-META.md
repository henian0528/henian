# 乐颐生境花园（上海长宁）

- 归档编号：`leyi_habitat_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：4
- 在 bot 附件库中匹配到的配图：4 / 4（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch25`
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `leyi_habitat_garden_1.jpg` | `bcc787a92acf5db4dc6a1b6103455c2067dedcdb35990086f2df306fd1b10bb4` | 276501 | 是 | `/workspace/landscape/batch25/leyi_habitat_garden_1.jpg` |
| `leyi_habitat_garden_2.jpg` | `93424c7c7180c8d55e27510e2ab34c1b959f78c4098ba5b43bc2c4f1423e4237` | 304258 | 是 | `/workspace/landscape/batch25/leyi_habitat_garden_2.jpg` |
| `leyi_habitat_garden_3.jpg` | `78616b682904a45fe876e6e4e008f7f8054b831b66cad8c2553e45e4e6b7cfae` | 291937 | 是 | `/workspace/landscape/batch25/leyi_habitat_garden_3.jpg` |
| `leyi_habitat_garden_4.jpg` | `287ebb06865b58f933a64223acad3764bed8f206ef827ed0285484f9c6bec120` | 304737 | 是 | `/workspace/landscape/batch25/leyi_habitat_garden_4.jpg` |
