# 临平相关遮阳案例（china-canopy）

- 归档编号：`linping`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·国内折板/伞状遮阳及棚架案例（目录 china-canopy-cases；期刊有「答应找国内类似 Superkilen 案例」）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases`
  - 注：来源 china-canopy-cases
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `linping_1.jpg` | `aed15cd807c2a75861e387bddf2ea3a4b2726fd7506e6f791d25dc3aa041f409` | 392696 | 否 | `/workspace/landscape/china-canopy-cases/linping_1.jpg` |
| `linping_2.jpg` | `ae8d3401355c206a49cef52868e3bb3f4e7aff3d932dccd5d63cd73d4a76c4f0` | 358027 | 是 | `/workspace/landscape/china-canopy-cases/linping_2.jpg` |
| `linping_3.jpg` | `038a26c550ff729f2eea25a24b7730d8c81414e909375f42be151dca28f10d00` | 997162 | 是 | `/workspace/landscape/china-canopy-cases/linping_3.jpg` |
| `linping_4.jpg` | `a4656f147051e2eff1320e979744275c9ea62430b111999bc8a0e57a318e8fff` | 415549 | 否 | `/workspace/landscape/china-canopy-cases/linping_4.jpg` |
| `linping_5.jpg` | `3e7dce0f233f6afde708e634716c0a325c778ca99ba4916546445755c4f69409` | 590939 | 是 | `/workspace/landscape/china-canopy-cases/linping_5.jpg` |
| `linping_6.jpg` | `d52bca70d5aaa61081e78be1ff6bc087f174dd13f33fa6615759631be08c349a` | 157810 | 是 | `/workspace/landscape/china-canopy-cases/linping_6.jpg` |
