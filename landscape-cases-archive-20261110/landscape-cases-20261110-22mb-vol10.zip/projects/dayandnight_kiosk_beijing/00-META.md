# 日夜公园 jetlag books（三里屯）

- 归档编号：`dayandnight_kiosk_beijing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `dayandnight_kiosk_beijing_1.jpg` | `2e5585f7b2de925fd8c474c079e587dd4f3d52bee3f2bf826e43973687c5f249` | 257081 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_1.jpg` |
| `dayandnight_kiosk_beijing_10.jpg` | `02d0ca15496f0639806eb9c395dcff9e1642dd5757ad7bc386ed8c6b26516fe4` | 300246 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_10.jpg` |
| `dayandnight_kiosk_beijing_2.jpg` | `3b2747d0552cd6de8dd4b2eeed0e085e25bb282530466de5a526ed676faa2f2e` | 209216 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_2.jpg` |
| `dayandnight_kiosk_beijing_3.jpg` | `29e569048eb132c5f3de28863f90dbf861143dba5ac90a16daa7c7a6b4423724` | 201269 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_3.jpg` |
| `dayandnight_kiosk_beijing_4.jpg` | `05b32110c145dc5330c7209c43783d81ca93d902d66159f24f13ec1b012f7e73` | 399361 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_4.jpg` |
| `dayandnight_kiosk_beijing_5.jpg` | `c4788ccfb080847c5009818c342f05a5dfd65a59405556377b31bd1dc8ff995a` | 360302 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_5.jpg` |
| `dayandnight_kiosk_beijing_6.jpg` | `58ebef5282c9d8ce9e756a925e3f531466c60f52bf1217f2e7bc770fa2b017c2` | 379530 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_6.jpg` |
| `dayandnight_kiosk_beijing_7.jpg` | `9b77f6c0575d4f93ceb76625531732afae638575a40db9f0e5bf26e7c803110b` | 338572 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_7.jpg` |
| `dayandnight_kiosk_beijing_8.jpg` | `369a364300e3c333d77f0d855f11a5ec74d16831e2b974bc6f5953fe6e13e69f` | 337476 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_8.jpg` |
| `dayandnight_kiosk_beijing_9.jpg` | `06714f3a6103071fd206e38141258aa16f21b7bf61670dcb1b43eb75ac3c1182` | 396097 | 是 | `/workspace/landscape/batch9/dayandnight_kiosk_beijing_9.jpg` |
