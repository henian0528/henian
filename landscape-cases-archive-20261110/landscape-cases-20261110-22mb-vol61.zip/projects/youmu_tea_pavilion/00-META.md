# 杭州长埭村茶山浮亭（由牧）

- 归档编号：`youmu_tea_pavilion`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：34
- 在 bot 附件库中匹配到的配图：0 / 34（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（与 chashan_fu_pavilion 为同一项目，见 texts/original-*）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 同项目互见

与 `chashan_fu_pavilion` 为同一项目。当时发出原文写明是杭州转塘长埭村、由牧建筑设计的「茶山浮亭」，并说明与松阳浮亭不是同一项目。本目录为 2026-10-25 的另一批配图。

## 出现记录（不改写）

- 日期/标记：2026-10-25
  - 出处说明：日期目录 2026-10-25（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-25/youmu_tea_pavilion`
  - 注：项目子目录精选图
  - 本记录配图文件数：34

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `_draw_extra_50.jpg` | `8b137e7451996ea91dde3dd380d6b181ef051df059202d3afdaeb4ae763bcb06` | 274507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_50.jpg` |
| `_draw_extra_51.jpg` | `8b137e7451996ea91dde3dd380d6b181ef051df059202d3afdaeb4ae763bcb06` | 274507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_51.jpg` |
| `_draw_extra_52.jpg` | `25e891ebc006e92215a4f05ec60072250e609a3312d4945fb4cda052216684ce` | 1105064 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_52.jpg` |
| `_draw_extra_53.jpg` | `25e891ebc006e92215a4f05ec60072250e609a3312d4945fb4cda052216684ce` | 1105064 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_53.jpg` |
| `_draw_extra_54.jpg` | `66417bf635f7c126e039d0e865a958a519a985cb211d243edf1fc71a8adf8ad4` | 162930 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_54.jpg` |
| `_draw_extra_55.jpg` | `66417bf635f7c126e039d0e865a958a519a985cb211d243edf1fc71a8adf8ad4` | 162930 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_55.jpg` |
| `_draw_extra_56.jpg` | `8fa0ec436ed34d30d26c5b50012e49b9c547123cb52771d28527e99d8cf08e13` | 589496 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_56.jpg` |
| `_draw_extra_57.jpg` | `8fa0ec436ed34d30d26c5b50012e49b9c547123cb52771d28527e99d8cf08e13` | 589496 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_draw_extra_57.jpg` |
| `_raw_00.jpg` | `b54dc31ce39a4d57ce2d066fb40886ed2a7b2c255d8574c4fc9bb24e6b1ad423` | 121665 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_00.jpg` |
| `_raw_01.jpg` | `d44ced734bc3795fa544bf683edd31118e46abc9b975fb70f84ae5026932c723` | 373028 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_01.jpg` |
| `_raw_02.jpg` | `309bdd185e7d5e44335c524d70e9cca927cd2a8411977332be60ea3c805480f2` | 490027 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_02.jpg` |
| `_raw_03.jpg` | `8b137e7451996ea91dde3dd380d6b181ef051df059202d3afdaeb4ae763bcb06` | 274507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_03.jpg` |
| `_raw_04.jpg` | `51549c143d55c0f92a3f71b2e6e795b1051a54f4e1d6dc475dd2e3c790e98390` | 889507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_04.jpg` |
| `_raw_05.jpg` | `c9c980a4bdfb2b7f750a4f7e8285fad73db55d0b77f423604dcc3c8e686efb1f` | 555765 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_05.jpg` |
| `_raw_06.jpg` | `92a93204f60c5ff0b70a2d2263302612fb813d9d5715b7a174b80bd99f6ab0ae` | 569560 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_06.jpg` |
| `_raw_07.jpg` | `7657f68bc02dd81eca4d1201bb66446dbdb9723d1cb8cd90b8121abeb44b2974` | 457887 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_07.jpg` |
| `_raw_08.jpg` | `66b5ab45271722cd4d4893a1a46a5eb719fad416fa5731f9e3086d48270cbb0d` | 526350 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_08.jpg` |
| `_raw_09.jpg` | `cfac56c2ae87edfeba390ad9e40f1673e3561983fa225cdd91d9a46401570c89` | 393784 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_09.jpg` |
| `_raw_10.jpg` | `6e68c7dc9d9637dd68a455ebbbe3adcb321210c97813e7f9e0f713701f767934` | 449812 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_10.jpg` |
| `_raw_11.jpg` | `65d473a07e1e29ae8aa2d8f6887009c87899979b2e7caa29d49ca2e38334ba52` | 377535 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_11.jpg` |
| `_raw_12.jpg` | `66417bf635f7c126e039d0e865a958a519a985cb211d243edf1fc71a8adf8ad4` | 162930 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_12.jpg` |
| `_raw_13.jpg` | `abecaa3070aeb2ea59b1cdcb37317685015d41723e4002d40d87149c19dcb17d` | 396190 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_13.jpg` |
| `_raw_14.jpg` | `7bb3710f7872f0199688159537416bb9e8d6b549fc91dfbc389498b722b6c027` | 570306 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_14.jpg` |
| `_raw_15.jpg` | `26f333f66e8ed35ec0821fe0d0b492f0ef1c8ed6c2f0077cfe91bb02d96a7dcf` | 348408 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/_raw_15.jpg` |
| `ym_01_photo.jpg` | `d44ced734bc3795fa544bf683edd31118e46abc9b975fb70f84ae5026932c723` | 373028 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_01_photo.jpg` |
| `ym_02_photo.jpg` | `309bdd185e7d5e44335c524d70e9cca927cd2a8411977332be60ea3c805480f2` | 490027 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_02_photo.jpg` |
| `ym_03_photo.jpg` | `51549c143d55c0f92a3f71b2e6e795b1051a54f4e1d6dc475dd2e3c790e98390` | 889507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_03_photo.jpg` |
| `ym_04_photo.jpg` | `c9c980a4bdfb2b7f750a4f7e8285fad73db55d0b77f423604dcc3c8e686efb1f` | 555765 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_04_photo.jpg` |
| `ym_05_photo.jpg` | `92a93204f60c5ff0b70a2d2263302612fb813d9d5715b7a174b80bd99f6ab0ae` | 569560 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_05_photo.jpg` |
| `ym_06_photo.jpg` | `66b5ab45271722cd4d4893a1a46a5eb719fad416fa5731f9e3086d48270cbb0d` | 526350 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_06_photo.jpg` |
| `ym_07_photo.jpg` | `6e68c7dc9d9637dd68a455ebbbe3adcb321210c97813e7f9e0f713701f767934` | 449812 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_07_photo.jpg` |
| `ym_08_drawing_site_plan.jpg` | `8b137e7451996ea91dde3dd380d6b181ef051df059202d3afdaeb4ae763bcb06` | 274507 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_08_drawing_site_plan.jpg` |
| `ym_09_drawing_floor_plan.jpg` | `25e891ebc006e92215a4f05ec60072250e609a3312d4945fb4cda052216684ce` | 1105064 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_09_drawing_floor_plan.jpg` |
| `ym_10_drawing_elevations.jpg` | `66417bf635f7c126e039d0e865a958a519a985cb211d243edf1fc71a8adf8ad4` | 162930 | 否 | `/workspace/landscape/2026-10-25/youmu_tea_pavilion/ym_10_drawing_elevations.jpg` |
