# 元荡棚（white2）

- 归档编号：`yuandang_canopy`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：4 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yuandang_canopy_1.jpg` | `2164285c40d0108c6a6e7a0eaee4fb262b6cd57d2dd160391fb00984de169fc1` | 119388 | 是 | `/workspace/landscape/china-canopy-cases/white2/yuandang_canopy_1.jpg` |
| `yuandang_canopy_2.jpg` | `bf32d5fbe6f571027dc29ef51f4781db994abb8571a520075fdc5d587de266a5` | 207902 | 是 | `/workspace/landscape/china-canopy-cases/white2/yuandang_canopy_2.jpg` |
| `yuandang_canopy_3.jpg` | `1d11a4d1931a5c5372bff025002d052944602299bb86fcf25de102ce368aa6ca` | 149954 | 是 | `/workspace/landscape/china-canopy-cases/white2/yuandang_canopy_3.jpg` |
| `yuandang_canopy_4.jpg` | `ab7018e03e77e5b7248743abf5616704a397df9dc9af5b78be8bf3337173a80c` | 101466 | 否 | `/workspace/landscape/china-canopy-cases/white2/yuandang_canopy_4.jpg` |
| `yuandang_canopy_5.jpg` | `ccd3c0b076955b9d9e4fa6239840aa71f09a642f800ac0f540bfc1f4060e21e8` | 88611 | 是 | `/workspace/landscape/china-canopy-cases/white2/yuandang_canopy_5.jpg` |
