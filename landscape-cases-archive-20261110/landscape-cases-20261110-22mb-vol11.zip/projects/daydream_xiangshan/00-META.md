# 白日梦之径（象山滨海驿站）

- 归档编号：`daydream_xiangshan`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：45
- 在 bot 附件库中匹配到的配图：10 / 45（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-27
  - 出处说明：日期目录 2026-10-27（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-27/daydream_xiangshan`
  - 注：项目子目录精选图
  - 本记录配图文件数：35

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch7`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `dd_01-1-i3f.jpg` | `ff12a1fc91cfb89bb8273294703c4f26cc5bf923f6bde89f74dd3a6927d18495` | 426983 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-1-i3f.jpg` |
| `dd_01-10-kle.jpg` | `2a929a623fc874bb2ab774aea4374bb75eb85919c7f56981b7d63920a35fa6d2` | 783640 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-10-kle.jpg` |
| `dd_01-11-1-wwp.jpg` | `80917027aa1192162c441698cce626220d2478216a343d33a644a996d2ee1d9a` | 864934 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-11-1-wwp.jpg` |
| `dd_01-12-mhx.jpg` | `b3231e4229131a97574ca07ad3f668033bade069ae93b2fdaa6b17b564c47273` | 1834700 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-12-mhx.jpg` |
| `dd_01-13-1-cky.jpg` | `80606539427d72d183f0d6c0ed73a5fd31f366f6f52e341aa9b036234c1033dc` | 726110 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-13-1-cky.jpg` |
| `dd_01-14-cfx.jpg` | `6cece217559c71d8a04b598fe085ddc6e5aea0b4d3d1f1db209de29ad01c8f3c` | 545236 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-14-cfx.jpg` |
| `dd_01-15-1-vi7.jpg` | `da3eadf1672d8b26b6388b60696b35a93a2736165647aa478b89ea1d7c268bc1` | 1135000 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-15-1-vi7.jpg` |
| `dd_01-16-srt.jpg` | `f81023e36611e7d194c194a51463141c6f9a9449af36e8a25f9c6f308e21aa7a` | 955019 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-16-srt.jpg` |
| `dd_01-17-26x.jpg` | `03b17e189387c9b97a5a35de3450446ebd2b4846740d9f0951919f73ebb79f3d` | 538250 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-17-26x.jpg` |
| `dd_01-18-vrg.jpg` | `a9a80122d557611ceb3f9fc1ba973eec3f0a5d79c3cdec450738a952e45b5cec` | 627068 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-18-vrg.jpg` |
| `dd_01-19-qbv.jpg` | `18e11b756e90c6229d69d1383011fa5a3ca295a372c0f237267253e6416ba56a` | 435330 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-19-qbv.jpg` |
| `dd_01-2-hzo.jpg` | `ac5c6acb7d2370098284256459edb645b53e92444cd269522b23ac4dbe964fa5` | 716892 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-2-hzo.jpg` |
| `dd_01-20-8nb.jpg` | `66446934e11cee0074c37f5a68b7ce92f14b40e0de995d34b9f760e0ab8028a3` | 349120 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-20-8nb.jpg` |
| `dd_01-21-x7g.jpg` | `3c1c75ba6dcda610a28b842073bf14c4a9fa0b504fded8cf45b0f0b327d9aa34` | 335646 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-21-x7g.jpg` |
| `dd_01-3-6xy.jpg` | `7871496feb9c81606046c3e74be9dd2da01e495623f5fa6be4c71a32fc3b6b14` | 645836 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-3-6xy.jpg` |
| `dd_01-4-1-2zv.jpg` | `7c9fcf62cd45086a2d865d240b79878c7204e561c6f4faee3c918dc5d78aa21f` | 453572 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-4-1-2zv.jpg` |
| `dd_01-5-uzm.jpg` | `6a7a3dfc0561fea4579dcec9c9f5662edf2e62c405e07b858fc5f47d3bdc59fd` | 620614 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-5-uzm.jpg` |
| `dd_01-6-amz.jpg` | `d119ddc2b95a15501c09c83b5bb43434cc7b91b48ebd02fa95761109f3fc803d` | 818958 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-6-amz.jpg` |
| `dd_01-7-zj1.jpg` | `6a1442d8c7a45b839483f7e784db5890d0c063837cc73a002ee25204caf9ed82` | 659190 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-7-zj1.jpg` |
| `dd_01-8-ysm.jpg` | `76815c1575cbc4c7456a2c1438dcec6031d4c17d6d4a60560ce835a7e5fb33bd` | 710865 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-8-ysm.jpg` |
| `dd_01-9-wcb.jpg` | `b4d19f988c38591bd6e512397adfe869a534b2f3d71ad4ddc538c5154fef366e` | 463278 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01-9-wcb.jpg` |
| `dd_01_photo.jpg` | `76815c1575cbc4c7456a2c1438dcec6031d4c17d6d4a60560ce835a7e5fb33bd` | 710865 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_01_photo.jpg` |
| `dd_02_photo.jpg` | `b3231e4229131a97574ca07ad3f668033bade069ae93b2fdaa6b17b564c47273` | 1834700 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_02_photo.jpg` |
| `dd_03_photo.jpg` | `da3eadf1672d8b26b6388b60696b35a93a2736165647aa478b89ea1d7c268bc1` | 1135000 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_03_photo.jpg` |
| `dd_04_photo.jpg` | `f81023e36611e7d194c194a51463141c6f9a9449af36e8a25f9c6f308e21aa7a` | 955019 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_04_photo.jpg` |
| `dd_05_photo.jpg` | `80917027aa1192162c441698cce626220d2478216a343d33a644a996d2ee1d9a` | 864934 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_05_photo.jpg` |
| `dd_06_photo.jpg` | `2a929a623fc874bb2ab774aea4374bb75eb85919c7f56981b7d63920a35fa6d2` | 783640 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_06_photo.jpg` |
| `dd_07_photo.jpg` | `18e11b756e90c6229d69d1383011fa5a3ca295a372c0f237267253e6416ba56a` | 435330 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_07_photo.jpg` |
| `dd_08_photo.jpg` | `d119ddc2b95a15501c09c83b5bb43434cc7b91b48ebd02fa95761109f3fc803d` | 818958 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_08_photo.jpg` |
| `dd_09_drawing_site.jpg` | `ff12a1fc91cfb89bb8273294703c4f26cc5bf923f6bde89f74dd3a6927d18495` | 426983 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_09_drawing_site.jpg` |
| `dd_10_drawing_form.jpg` | `6397bcdf65cefdd6df284f5f8724fdecdbac42a79a0968df9fb67b3661e17a8a` | 285879 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_10_drawing_form.jpg` |
| `dd_drawing_form.gif` | `e7a6f2533cf773d6b92efe4c06739f05ed32a7f1377d6dac13a2fdbcdfacbb3e` | 1489206 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_drawing_form.gif` |
| `dd_drawing_form.jpg` | `6397bcdf65cefdd6df284f5f8724fdecdbac42a79a0968df9fb67b3661e17a8a` | 285879 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_drawing_form.jpg` |
| `dd_drawing_renovation.gif` | `a843b3c63c2a01a785ee80235c9a63da24fe5960117f91aeab60ffd09b32e0fc` | 754384 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_drawing_renovation.gif` |
| `dd_drawing_renovation.jpg` | `a545c5cc13545efc03efca2b5e52ab55036f23011e7bb89ad015707493b6f0a4` | 408662 | 否 | `/workspace/landscape/2026-10-27/daydream_xiangshan/dd_drawing_renovation.jpg` |
| `daydream_trail_xiangshan_1.jpg` | `18b5592ef02d11c75eeddc1b39bf438e5f65d1b513c97e0cc3459e40431f686d` | 118494 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_1.jpg` |
| `daydream_trail_xiangshan_10.jpg` | `8eace59dc839fe1f2c12023afca32bda3ba7364c98d20d118d98c34ab5f328e0` | 124068 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_10.jpg` |
| `daydream_trail_xiangshan_2.jpg` | `d44144527a60f809d8441c5e11fef045cd3e5f475124d8e9a4107eaa8259e214` | 120454 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_2.jpg` |
| `daydream_trail_xiangshan_3.jpg` | `62e154c48ed1520c48b043bc39e41d42f0c11e989c343265005db8e1bea4b72b` | 144077 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_3.jpg` |
| `daydream_trail_xiangshan_4.jpg` | `74970f384beffaff5dfd5a30d5be8c7348bd0154351516f418a0ad5cadcea0d8` | 156561 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_4.jpg` |
| `daydream_trail_xiangshan_5.jpg` | `0435897af53b045e052b7ec2907ae053afd201bc9a1c9cb1783c8e664301ac83` | 180249 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_5.jpg` |
| `daydream_trail_xiangshan_6.jpg` | `3d73a32ffe6b031b814e18a4eb27b63107bae391bccba6861070ae6fe71ec5a7` | 149299 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_6.jpg` |
| `daydream_trail_xiangshan_7.jpg` | `16899ba3c48cf694f3c73e53d80958207bf265d6f84532fb24567ce734410a70` | 168457 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_7.jpg` |
| `daydream_trail_xiangshan_8.jpg` | `6e34ab56cf1537cee8b3bb355721b9d08878b88202d0182f71af2b3d731a0b13` | 219481 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_8.jpg` |
| `daydream_trail_xiangshan_9.jpg` | `3ec3f2ca22343ac395e8f5b1b3221d1150564b0ace5b6c77a99a63cd47e1d969` | 80337 | 是 | `/workspace/landscape/batch7/daydream_trail_xiangshan_9.jpg` |
