# H01 花园（上海，batch18）

- 归档编号：`h01_garden_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `h01_garden_sh_1.jpg` | `caf08027da7cbcd22c7602cd46f5b2eb72d416604791c68ee78804d135c93999` | 476584 | 是 | `/workspace/landscape/batch18/h01_garden_sh_1.jpg` |
| `h01_garden_sh_10.jpg` | `f7f1269adc0c4c6fc2ff7e4da136f0c35374f84caab75a3808da9fb5b8975ad0` | 758889 | 是 | `/workspace/landscape/batch18/h01_garden_sh_10.jpg` |
| `h01_garden_sh_2.jpg` | `e738d178246f7e358f502d484b3bebc468c32c0702d251b5ae36609914bdc860` | 581306 | 是 | `/workspace/landscape/batch18/h01_garden_sh_2.jpg` |
| `h01_garden_sh_3.jpg` | `031be2b384ad089a161576c2451244ae5658759f968ad905ecb5e0d52e4b2855` | 775906 | 是 | `/workspace/landscape/batch18/h01_garden_sh_3.jpg` |
| `h01_garden_sh_4.jpg` | `2ec8f3573875d8e3e1ab4915c67091e754868af8e7e24ab2a767fbd86b78499f` | 555077 | 是 | `/workspace/landscape/batch18/h01_garden_sh_4.jpg` |
| `h01_garden_sh_5.jpg` | `06072b590528d849e80082217438446e12e9993de189f4b27aec2ef11d57769d` | 891381 | 是 | `/workspace/landscape/batch18/h01_garden_sh_5.jpg` |
| `h01_garden_sh_6.jpg` | `e7599d7ff770cb95dd8e033abb3d8be43df531aefb3fc84871aec781792d211e` | 1038579 | 是 | `/workspace/landscape/batch18/h01_garden_sh_6.jpg` |
| `h01_garden_sh_7.jpg` | `4efc993202255c39f86662651bf74e0520312a4605169aa6d728deb112c4547d` | 931036 | 是 | `/workspace/landscape/batch18/h01_garden_sh_7.jpg` |
| `h01_garden_sh_8.jpg` | `a9ed838aaed6f3e2b47364b6a39dced9e4e343e9d6488e813a20690871c06355` | 1091396 | 是 | `/workspace/landscape/batch18/h01_garden_sh_8.jpg` |
| `h01_garden_sh_9.jpg` | `c264bdd58639cbc8b597dc431c3f1802c10cdece5d5e8dfa7f55eceefe8a50b7` | 1064133 | 是 | `/workspace/landscape/batch18/h01_garden_sh_9.jpg` |
