# 前海桂湾公园驿站三座（深圳）

- 归档编号：`guiwan_qianhai`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-08
  - 出处说明：日期目录 2026-11-08（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-08/guiwan_qianhai`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `gw_01_photo_station4_geometry.jpg` | `c401040e9e05c72be8dcc95f88c14f8fed35cc41de0909814ab921cb31c57cf0` | 586092 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_01_photo_station4_geometry.jpg` |
| `gw_02_photo_station4_eaves.jpg` | `f12723a81be44d7f4d07a8e324783d33a47ad99223b58d7ffa89e956cfa329ad` | 559484 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_02_photo_station4_eaves.jpg` |
| `gw_03_photo_station1_embed.jpg` | `cf05c7ddd09c36c53d05433bb7626f263982a42d2316f73b65728a9243a3ed43` | 490529 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_03_photo_station1_embed.jpg` |
| `gw_04_photo_station1_seats.jpg` | `4436653147024e25a1129cf255ae6f57252babc5f1ad5688300035a8923e97a7` | 457066 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_04_photo_station1_seats.jpg` |
| `gw_05_photo_station1_overview.jpg` | `980fd50ae5867b97b48ec7c4e51b052cecaaea3e185b1dac854c497881e29ea2` | 571435 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_05_photo_station1_overview.jpg` |
| `gw_06_photo_station3_autumn.jpg` | `a7285f9d1af79d7b9d15f889873d4e8b97f0d1e64a0cae3002acf56294b90171` | 714300 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_06_photo_station3_autumn.jpg` |
| `gw_07_photo_station3_arcade.jpg` | `2e918c29656d12fb51b16cd85b39b0373d728aed8d0e9712f2208f27b9d30833` | 544313 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_07_photo_station3_arcade.jpg` |
| `gw_08_drawing_station1_siteplan.jpg` | `decc90f9dd81768859a39993a880ce46541d0f882cb3b3472c307d93054abec4` | 285907 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_08_drawing_station1_siteplan.jpg` |
| `gw_09_drawing_station1_plan.jpg` | `e2eba2f7383a6472434cd670d7bea85eb7986f5251f0b1fa60cda9979f67f359` | 358620 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_09_drawing_station1_plan.jpg` |
| `gw_10_drawing_station1_section.jpg` | `926d08beec15c78a0766bb1a52a37701aed69ebbe9afa71b188e19c08b84e7e0` | 32307 | 否 | `/workspace/landscape/2026-11-08/guiwan_qianhai/gw_10_drawing_station1_section.jpg` |
