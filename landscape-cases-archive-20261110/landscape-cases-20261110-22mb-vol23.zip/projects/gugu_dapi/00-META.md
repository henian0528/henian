# 咕咕来仪·大伾山悬崖驿站（河南浚县）

- 归档编号：`gugu_dapi`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-11
  - 出处说明：日期目录 2026-11-11（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-11/gugu_dapi`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `gg_01_photo_overview.jpg` | `80525c168f871304a2584b41f8945e03e0010c047a84f9c069686dbc7d7cdd6c` | 753578 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_01_photo_overview.jpg` |
| `gg_02_photo_aerial.jpg` | `f7469739d54a4bf28dd7c1c29d6dd626435388b443f2e539bb772843afd22882` | 333023 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_02_photo_aerial.jpg` |
| `gg_03_photo_temple.jpg` | `598faf1bbaeb4c73ec48b106706eb3135b088ebb7073d17e8164ead72999fd04` | 307702 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_03_photo_temple.jpg` |
| `gg_04_photo_entrance.jpg` | `bad079f3b626d40aa6894021c8a9c82ef1461f171f46b16b978107fab4fb1d95` | 354878 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_04_photo_entrance.jpg` |
| `gg_05_photo_veranda.jpg` | `84bd2748f049816c081e506eeec2050bc0cc1d5aba6ad0d6b12b43494ad31f1d` | 416279 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_05_photo_veranda.jpg` |
| `gg_06_photo_interior.jpg` | `f744b2a401550c4b7c3b0559bd2374c9453e4789f67c9f26dd0e571c750426cb` | 420682 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_06_photo_interior.jpg` |
| `gg_07_photo_eaves.jpg` | `e386f6ef99413bf4f252c92200b1e8d6778b546ce5b0e10c484358d4258ec5b3` | 724555 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_07_photo_eaves.jpg` |
| `gg_08_drawing_plan.jpg` | `f11c0d77ea6b40cd79151156a21c6d5076ca393d3927a03e064365685db42b5e` | 355578 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_08_drawing_plan.jpg` |
| `gg_09_drawing_elevation.jpg` | `ab6b34a44d319f675a8e9793d43de120ed7bba3911d1654137a4c39f931b9fc7` | 205303 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_09_drawing_elevation.jpg` |
| `gg_10_drawing_section.jpg` | `e202612456556a348d923b5db0c3629c127a1ccd51d0b85e168c9d9f354aa27d` | 158634 | 否 | `/workspace/landscape/2026-11-11/gugu_dapi/gg_10_drawing_section.jpg` |
