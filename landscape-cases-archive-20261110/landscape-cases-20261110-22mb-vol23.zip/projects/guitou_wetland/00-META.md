# 龟头湿地（variety 早期批次）

- 归档编号：`guitou_wetland`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `guitou_wetland_1.jpg` | `33f6dbfb9d932e27ab183935fb52a3750bfe1410232a160a307418f7a9b40d5d` | 99261 | 是 | `/workspace/landscape/variety/guitou_wetland_1.jpg` |
| `guitou_wetland_2.jpg` | `6bab5212803e6a18ec42b2558af73d9dd7e837886a44ab5cd9c7251def6b23a2` | 122303 | 是 | `/workspace/landscape/variety/guitou_wetland_2.jpg` |
| `guitou_wetland_3.jpg` | `080826e8c4ead523ee05fa4ad8cf2faa53d0cab81886f5f294f93f13b1674bb5` | 174257 | 是 | `/workspace/landscape/variety/guitou_wetland_3.jpg` |
| `guitou_wetland_4.jpg` | `0944c3784b11d8a277ccadc65f3ee304e24b6c26f6c28105c021e80018bcbf22` | 174947 | 是 | `/workspace/landscape/variety/guitou_wetland_4.jpg` |
| `guitou_wetland_5.jpg` | `826e4735557fbaefdc25a4106c3909f8ca415393a24393727f7bbcf011708e04` | 129625 | 否 | `/workspace/landscape/variety/guitou_wetland_5.jpg` |
| `guitou_wetland_6.jpg` | `8554440cedfd704f29a915e7518c3542544c138cf3b92e4948f1f808b21a88f6` | 146156 | 否 | `/workspace/landscape/variety/guitou_wetland_6.jpg` |
