# 天壤云影（深圳）

- 归档编号：`tianrang_yunying_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `tianrang_yunying_sz_1.jpg` | `f665716b372741d279c625f8f62e4b5a0baaf4075fc9945e500a3159efa93106` | 1014141 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_1.jpg` |
| `tianrang_yunying_sz_10.jpg` | `86ba251f8acdbb99075a5d1ca4f68b7e6eadc0acc6dd31237c8d1a48aba7c9d8` | 254699 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_10.jpg` |
| `tianrang_yunying_sz_2.jpg` | `2c52c050c39e6a8f4ef06400e1d47b5b9848065978ccfe4c35f01c6855c7c361` | 817340 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_2.jpg` |
| `tianrang_yunying_sz_3.jpg` | `65aab985ab581a1d7e87d67b0d07b0017d6f681e4f6c2b86ac3944768653f406` | 1020142 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_3.jpg` |
| `tianrang_yunying_sz_4.jpg` | `e78d2cd581efb80c2880dfe077ab7852ec87a9116510697c7db9da6aa1065350` | 1299620 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_4.jpg` |
| `tianrang_yunying_sz_5.jpg` | `d7747e33c4a2c7d313cf9d59cf00758cf0efb4ddc85248915bb20683cca27035` | 632731 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_5.jpg` |
| `tianrang_yunying_sz_6.jpg` | `a153817fd2f63ef52b52ba87768b536e0eeedad75c86935eb1cd672b308d5fbf` | 282501 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_6.jpg` |
| `tianrang_yunying_sz_7.jpg` | `2f970cce8a0f20f50d224e25032874fe102f3aac87feaa356591f52c7a214b76` | 822266 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_7.jpg` |
| `tianrang_yunying_sz_8.jpg` | `2078108a07a2a6993753fa2c2b0bdc65d9832ba31c596607a205d5e0099cec5c` | 441716 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_8.jpg` |
| `tianrang_yunying_sz_9.jpg` | `11425cafacec8b996a2332a611523e626a1c58704a6bbaa8b9d14340044dbdf7` | 866050 | 是 | `/workspace/landscape/batch26/tianrang_yunying_sz_9.jpg` |
