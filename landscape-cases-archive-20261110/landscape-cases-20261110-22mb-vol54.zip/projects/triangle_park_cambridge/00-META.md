# Triangle Park（剑桥，Stoss）

- 归档编号：`triangle_park_cambridge`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `triangle_park_cambridge_1.jpg` | `d0c215092304f7063766989a05bdd81d8cdf1d6ef8cd689337d22be4abae5046` | 478751 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_1.jpg` |
| `triangle_park_cambridge_10.jpg` | `88310afd068ff3e849decf5542aa4387a704b4fbbb7d369afe4af204ee90d341` | 206632 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_10.jpg` |
| `triangle_park_cambridge_2.jpg` | `d470a244439cdf851f512253a37e8dbfbd738000e012af3b045307e7776a33ae` | 540491 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_2.jpg` |
| `triangle_park_cambridge_3.jpg` | `d1949243211fd50930867672de596ee792c3afd0704eb650f6cef19f6d8d2fb7` | 445272 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_3.jpg` |
| `triangle_park_cambridge_4.jpg` | `213dce7f3bc3d348ca54de0f3bcf2177728a55ea0bd8e9bc1aa1123ed8c9fe53` | 688018 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_4.jpg` |
| `triangle_park_cambridge_5.jpg` | `5b6019ee00931a23e5097b9b1857c47cdaa6abb07f1a663e9ce0ee09f36078f7` | 474363 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_5.jpg` |
| `triangle_park_cambridge_6.jpg` | `06611b00862ebd1573fd1608c1551a3af2fb49d470956a4e92689a622aca4e6a` | 659455 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_6.jpg` |
| `triangle_park_cambridge_7.jpg` | `ae9a41b591dbd39dff9052d0ada4056f9c73a83f32450bdd400cf3b9ea0b7706` | 733967 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_7.jpg` |
| `triangle_park_cambridge_8.jpg` | `62dc7505e6b0a23a9f068c801ee512e9915fec59e0e70169425d64b95e7f960e` | 490910 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_8.jpg` |
| `triangle_park_cambridge_9.jpg` | `dbd966fb247278cb0b51be74687258aea7859c1c5045cdb4d0a9ad29da256aa6` | 194050 | 是 | `/workspace/landscape/batch27/triangle_park_cambridge_9.jpg` |
