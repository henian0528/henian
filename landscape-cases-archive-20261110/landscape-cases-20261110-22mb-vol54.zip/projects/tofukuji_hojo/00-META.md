# 东福寺方丈庭园（courtyard 早期批次）

- 归档编号：`tofukuji_hojo`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `tofukuji_hojo_1.jpg` | `58615123f2c4c17e8931a3b23d2d7d65113b1d83ec5fd381f99e3ddbf49fabb0` | 1254415 | 是 | `/workspace/landscape/courtyard/tofukuji_hojo_1.jpg` |
| `tofukuji_hojo_2.jpg` | `d3171e3c667aeb3529a9a2fac08af5cd354f597b73be9134ac6d668821d96a95` | 1490305 | 是 | `/workspace/landscape/courtyard/tofukuji_hojo_2.jpg` |
| `tofukuji_hojo_3.jpg` | `fd5478808f10087b550ab1bd024b22e8da353fa938256c171bfdc15bb828b678` | 674102 | 是 | `/workspace/landscape/courtyard/tofukuji_hojo_3.jpg` |
| `tofukuji_hojo_4.jpg` | `45f0237ac1957ec0014189930970f5f0d7e1cd0e04d1c50f93267c0d8a489535` | 1777316 | 是 | `/workspace/landscape/courtyard/tofukuji_hojo_4.jpg` |
| `tofukuji_hojo_5.jpg` | `47d66c714abb69566bc078c3d66cf34e62260fc55f436aa9db486a77fcaf5815` | 169016 | 否 | `/workspace/landscape/courtyard/tofukuji_hojo_5.jpg` |
| `tofukuji_hojo_6.jpg` | `384170932adedd77ac6f3382fa6ad74a05e391a4246704b5f65508d930e2d6d7` | 1017403 | 否 | `/workspace/landscape/courtyard/tofukuji_hojo_6.jpg` |
