# Glassfields（期刊记因图片拦截未发）

- 归档编号：`glassfields`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：4
- 在 bot 附件库中匹配到的配图：4 / 4（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`（后续补发，见 texts/original-*）
  - 本地来源：`/workspace/landscape/batch31`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `glassfields_1.jpg` | `ed8e055c797a44eeea99ff7df3b6b058916bb98f11c29abdc5d6350e92135f4c` | 240045 | 是 | `/workspace/landscape/batch31/glassfields_1.jpg` |
| `glassfields_2.jpg` | `eb1ae548f5120865676059ca361f840b0c29224a7194ad06ec14a683ce487676` | 974852 | 是 | `/workspace/landscape/batch31/glassfields_2.jpg` |
| `glassfields_3.jpg` | `48307b01eeb5b9231ee4ba441e0d484baf106b9ba25e3801dadaad96e2d09086` | 949211 | 是 | `/workspace/landscape/batch31/glassfields_3.jpg` |
| `glassfields_4.jpg` | `d478b13c0f2eabb53f5c013e854f909cb1b739574d156593226d158634db9da5` | 822083 | 是 | `/workspace/landscape/batch31/glassfields_4.jpg` |
