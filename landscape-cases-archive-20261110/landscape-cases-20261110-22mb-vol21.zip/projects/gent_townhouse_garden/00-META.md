# 根特 Garden Veerle and Rhida（Plant en Houtgoed）

- 归档编号：`gent_townhouse_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：5 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `gent_townhouse_garden_1.jpg` | `cc2aa9d99d82451aa0689365e60f994d889b1f63fe9ec9fc172d57a71d94c6ea` | 619706 | 是 | `/workspace/landscape/batch20/gent_townhouse_garden_1.jpg` |
| `gent_townhouse_garden_2.jpg` | `a124a37583d982d7dc98b7335b084358d32d2b6ca95e21000262a17741dc117b` | 683729 | 是 | `/workspace/landscape/batch20/gent_townhouse_garden_2.jpg` |
| `gent_townhouse_garden_3.jpg` | `2d66a32520a006ff79986ee104c40ec163e7d0f94761995e6d2698aed432faf7` | 713810 | 是 | `/workspace/landscape/batch20/gent_townhouse_garden_3.jpg` |
| `gent_townhouse_garden_4.jpg` | `7d321e2dc42f374a16bc2f287d452b16f50cac72b3f703ce57ff5953e4a96f0c` | 426240 | 是 | `/workspace/landscape/batch20/gent_townhouse_garden_4.jpg` |
| `gent_townhouse_garden_5.jpg` | `040cc75da07ea067e9844ef80b5a6395caff6f44ea8e93b7f099873b2d76f853` | 308338 | 是 | `/workspace/landscape/batch20/gent_townhouse_garden_5.jpg` |
