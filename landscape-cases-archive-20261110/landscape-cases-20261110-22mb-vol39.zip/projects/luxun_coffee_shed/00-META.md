# 上海鲁迅公园咖啡亭

- 归档编号：`luxun_coffee_shed`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-24
  - 出处说明：日期目录 2026-10-24（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-10-24/luxun_coffee_shed`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `luxun_01_photo.jpg` | `36b2aef490d48fbe8fb5ab336edcfdec97d0c1e963f54d1b990c38f145809f38` | 1080987 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_01_photo.jpg` |
| `luxun_02_photo.jpg` | `7b6444feee4ab9f4f87a392092fe74b4c73b40d3229c83abbc76819ba3aa0fba` | 634316 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_02_photo.jpg` |
| `luxun_03_photo.jpg` | `0232ac3d6bfe4279bf8bec7d40511c51dca1c3d04330ea2a28c7e2f4b5170ff3` | 1262883 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_03_photo.jpg` |
| `luxun_04_photo.jpg` | `28314bdc862221920249c315b1d5accf28306b7f9e7d1a25425336a5fe9e725c` | 1006509 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_04_photo.jpg` |
| `luxun_05_photo.jpg` | `db0f1e92bdc83de91a5c08adb8b44873f05103d9fa5945449b3aedfe279ce09c` | 916807 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_05_photo.jpg` |
| `luxun_06_photo.jpg` | `ed6821c0626e2c4e5bb066ea9820524164db5dab6cf14e1bb4396ef5f81d7e0a` | 1745483 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_06_photo.jpg` |
| `luxun_07_photo.jpg` | `bf0f280edb727141eea6e73fa9da395a5427d266f5b8c3620655994d1d6f1113` | 960264 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_07_photo.jpg` |
| `luxun_09_drawing_plan.jpg` | `cdda11b74543901b41da04036e5768afa1347748789282ec3ab88dfec05d3d51` | 358333 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_09_drawing_plan.jpg` |
| `luxun_10_drawing_roof_plan.jpg` | `cc20bf46666395f10cc9c43dee69ac711e7300d82d393e54f69679304f82a0f5` | 436662 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_10_drawing_roof_plan.jpg` |
| `luxun_11_drawing_section.jpg` | `5aef2ef0eabfe6a49944555df9977cdb39b288e387ad075fdeead6a0c8391ae5` | 410262 | 否 | `/workspace/landscape/2026-10-24/luxun_coffee_shed/luxun_11_drawing_section.jpg` |
