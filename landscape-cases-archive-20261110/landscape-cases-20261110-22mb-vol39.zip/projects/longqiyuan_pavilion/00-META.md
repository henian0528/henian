# 龙麒源水之廊亭（温州）

- 归档编号：`longqiyuan_pavilion`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-26
  - 出处说明：日期目录 2026-10-26（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-26/longqiyuan_pavilion`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `lq_01_photo.jpg` | `cb3231f1013a0ab14590e35f1a58c8caf6b6157f13a2a5064e622d7942e196cb` | 683330 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_01_photo.jpg` |
| `lq_02_photo.jpg` | `c9e52939f2f07756c11eb50558f6e418820d7d62025660fdcdd5e014ec4f1c6f` | 757962 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_02_photo.jpg` |
| `lq_03_photo.jpg` | `e4f38988fa9020fbaaa2c256eb5848e992da4c06e43f559ca5fa2447c2dc393e` | 884623 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_03_photo.jpg` |
| `lq_04_photo.jpg` | `81e4bd12ebf6faaa67b7a08dfff5c9497bb8cc66d9e270cb169e87765c1e7403` | 763615 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_04_photo.jpg` |
| `lq_05_photo.jpg` | `a376368ce40c89a3a3b177dfdc1eea29f6cd8840c11f0485dd35b915ef186dc4` | 768473 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_05_photo.jpg` |
| `lq_06_photo.jpg` | `232db929e0704782f7931fe021f3854245edccd945d82fd52ff18054f50c9fb9` | 941812 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_06_photo.jpg` |
| `lq_07_photo.jpg` | `2f4dd27fbfece78562364ed7945fec90b267920c4c73105838dc935f6912d41d` | 761978 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_07_photo.jpg` |
| `lq_08_drawing_plan.jpg` | `d72f7181116344799bf7cd76ed9fd2b95eea239e346af29df09f3349b1c8624a` | 688041 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_08_drawing_plan.jpg` |
| `lq_09_drawing_diagram.jpg` | `7a56f2aefdc6c50dfda7f60449b672b095e2f16050de5780ef35f04998b896fd` | 516261 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_09_drawing_diagram.jpg` |
| `lq_10_drawing_axon.jpg` | `edab91ebd44e27eea62697e5f089e94643db9844ca6841b54abacf943e3c8b86` | 149352 | 否 | `/workspace/landscape/2026-10-26/longqiyuan_pavilion/lq_10_drawing_axon.jpg` |
