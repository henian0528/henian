# 渌湾水鸟公园（batch7）

- 归档编号：`luwan_waterbird_park`
- 推荐状态（汇总）：`uncertain`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch7`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `luwan_waterbird_park_1.jpg` | `8d7d09f25395b95b3941662f6db4ebd4c08b7ed78997bc10f4a763574718659a` | 283120 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_1.jpg` |
| `luwan_waterbird_park_10.jpg` | `026cdaaf65a00bc4ed941f5621259fbb319f73e34e6078ab1a7f93410ad29623` | 121198 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_10.jpg` |
| `luwan_waterbird_park_2.jpg` | `9b958d7a1672b6aabe652727bbb980c2b68f225bd19890c204f07926187883ec` | 270130 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_2.jpg` |
| `luwan_waterbird_park_3.jpg` | `d7b4309072808a37e5c6b930b64b14e00fb5560b176bddbd29f6536657dbe68a` | 320232 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_3.jpg` |
| `luwan_waterbird_park_4.jpg` | `f0263cb4b5db43bff80f2b34d9e28fa4c18da82815b4a21ef92617d87aa795f4` | 229073 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_4.jpg` |
| `luwan_waterbird_park_5.jpg` | `c6f60a83024d516b58d19ca3dd7e31b3b7864655f262ba2318aea8ead22391b8` | 217903 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_5.jpg` |
| `luwan_waterbird_park_6.jpg` | `522a6cf49bfd515db95c418f148ce6941d5f6d863da165255e6d6f9251987a5a` | 226577 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_6.jpg` |
| `luwan_waterbird_park_7.jpg` | `343200ca73b763db89d0395261d0fc61b480a1769d279ea28b21cf23b45d671e` | 190818 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_7.jpg` |
| `luwan_waterbird_park_8.jpg` | `19a08ddb43befda004ed7d8dd2a16742e2d424275644e9d816ed9dfac621a839` | 247848 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_8.jpg` |
| `luwan_waterbird_park_9.jpg` | `10f2d9a34d103934054ed1e8074ec204a0cb253bddcd77f65628ca9d04849991` | 200714 | 是 | `/workspace/landscape/batch7/luwan_waterbird_park_9.jpg` |
