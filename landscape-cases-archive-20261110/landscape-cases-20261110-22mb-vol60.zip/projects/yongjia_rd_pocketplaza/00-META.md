# 永嘉路口袋广场（阿科米星）

- 归档编号：`yongjia_rd_pocketplaza`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yongjia_rd_pocketplaza_1.jpg` | `680f5f36f355be8a4394c556d9c6bbb2cf139ae71b0e3843f83a2b62dd5bf6e4` | 327898 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_1.jpg` |
| `yongjia_rd_pocketplaza_10.jpg` | `5a00a3890f17a06d7cb09a17fdc6e286b92b7ccb047adf1bb3270d9ae8ec351d` | 103403 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_10.jpg` |
| `yongjia_rd_pocketplaza_2.jpg` | `7e522b9cd163bcb78f6009aa2475effbb2eb51384c2376f09307edf4c5a4a74c` | 115681 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_2.jpg` |
| `yongjia_rd_pocketplaza_3.jpg` | `3b6c802e9325cf845a4805f1fdf79d0571c596dee073866c4164b2712fbebd37` | 155351 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_3.jpg` |
| `yongjia_rd_pocketplaza_4.jpg` | `2392f7fc75638fde0025047e5fb5445bed7a5d9d448a5d4829391fa29ab77480` | 246781 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_4.jpg` |
| `yongjia_rd_pocketplaza_5.jpg` | `d4284464ba08cfd67f063d9c226bb761b31f272760f8de7ee01ab787a3c5301c` | 254310 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_5.jpg` |
| `yongjia_rd_pocketplaza_6.jpg` | `8875dd7ee580d70c2a85cf45c980fcc01c90c2a88c50edac15e8de6555a4ce73` | 237704 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_6.jpg` |
| `yongjia_rd_pocketplaza_7.jpg` | `bd9510298c55ba216a47be08b38e7803fe841ba4456c5df45a75b9b5f100a02b` | 191257 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_7.jpg` |
| `yongjia_rd_pocketplaza_8.jpg` | `ddaa5e3aa387e20373f743fc783620670706150148b3f1e098f4eeb49a6d40bb` | 185107 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_8.jpg` |
| `yongjia_rd_pocketplaza_9.jpg` | `528fc8881bcdacda0b86ff7f3ada79ff729f201987538d32188464d33f6e0f91` | 101991 | 是 | `/workspace/landscape/batch12/yongjia_rd_pocketplaza_9.jpg` |
