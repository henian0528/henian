# 一叶茶亭（structures 早期批次）

- 归档编号：`yiye_tea_pavilion`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yiye_tea_pavilion_1.jpg` | `c7f033983be5a0095c10c774dc82f6066b735424fa7bfaf3f0185d5eab5e53a4` | 138012 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_1.jpg` |
| `yiye_tea_pavilion_2.jpg` | `0bc35318322a9302f280eae283f63c266db444442d15a6d87c27a4797820896e` | 149655 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_2.jpg` |
| `yiye_tea_pavilion_3.jpg` | `5a6e22c9beb13e36cdfaa782564f50e832c1df464d0d7cbe9ef39751e7ba3778` | 86714 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_3.jpg` |
| `yiye_tea_pavilion_4.jpg` | `4ebb0adbbdc659522d6688da5171802fb62816ed1872b995d5ce4eb9b0422647` | 75972 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_4.jpg` |
| `yiye_tea_pavilion_5.jpg` | `dcd3c5a65dad0733c236fbcfea0270a7bbdc9295920bbc3055a59ccf7b9fddea` | 49611 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_5.jpg` |
| `yiye_tea_pavilion_6.jpg` | `cde3fe83c7cd335e2cca752389da41ad11c7adcc74ba4381f74c8c3314756814` | 51385 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_6.jpg` |
| `yiye_tea_pavilion_7.jpg` | `aa60bd78ce8de2e5edb918d6a6eea34fd77c1ed553248d6ba41b410d0e6b83dc` | 66896 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_7.jpg` |
| `yiye_tea_pavilion_8.jpg` | `4ad448793949288903b556409a32759f1c99597652d65692d288fd37bc79bfb3` | 95010 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_8.jpg` |
| `yiye_tea_pavilion_9.jpg` | `a572af4390ffcdd0d53adae830cbb740f3fb736f46d950ecaa112e4322ea5764` | 93709 | 是 | `/workspace/landscape/structures/yiye_tea_pavilion_9.jpg` |
