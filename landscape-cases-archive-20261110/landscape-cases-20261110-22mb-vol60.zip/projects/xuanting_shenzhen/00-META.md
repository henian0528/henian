# 轩亭（深圳，structures 早期批次）

- 归档编号：`xuanting_shenzhen`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `xuanting_shenzhen_1.jpg` | `22f6c1a077911c706b62e70de19f9f17ae3f43b3c5cc805c6bb884d9027b0b51` | 268864 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_1.jpg` |
| `xuanting_shenzhen_10.jpg` | `13418efada2513381b5fde284e4d784d4cdfa0111d52473e7b665271c19c4a95` | 84416 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_10.jpg` |
| `xuanting_shenzhen_2.jpg` | `369380df5faf73d1c914e07147b6952f8d88c8e820b381e26c33f39944c8f693` | 257668 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_2.jpg` |
| `xuanting_shenzhen_3.jpg` | `bae38bafce66e4f6ca2cb0dec0363e434cd015f74233c92cf9adf68dbd647f3d` | 216077 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_3.jpg` |
| `xuanting_shenzhen_4.jpg` | `eb942c25646febd208223f9b2d19a10d4a5c2e6ebda0f067a6e74866a9ed7acc` | 211113 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_4.jpg` |
| `xuanting_shenzhen_5.jpg` | `89891e19fec6f405e291c49a25789dfdab2e11dbbe5fb4b49ffdaac37f9ebe54` | 244713 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_5.jpg` |
| `xuanting_shenzhen_6.jpg` | `b5d194bb44559565df1a32f4e1f2f6daed79da5b3cab68dfdc1cdca0e34fd4dd` | 275978 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_6.jpg` |
| `xuanting_shenzhen_7.jpg` | `65dba7c709500d8174c83ed2e73aebaf264bba38fc9ba4518196f78fa7df1c44` | 239287 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_7.jpg` |
| `xuanting_shenzhen_8.jpg` | `a3f68b22265c5fc868998778e85bdf1b704781783902f0edf171c90de9928b07` | 190207 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_8.jpg` |
| `xuanting_shenzhen_9.jpg` | `4ec26af0423009074751e3fa5c653d9ef60393e79e2bfdf49e5ac8b2b40167e7` | 124238 | 是 | `/workspace/landscape/structures/xuanting_shenzhen_9.jpg` |
