# 杨浦滨江（variety 早期批次）

- 归档编号：`yangpu_riverside`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yangpu_riverside_1.jpg` | `ad9e3a69d889b922ad79668d5d3520ce106c057eb6a13518eb8ecdbe720512ab` | 232869 | 是 | `/workspace/landscape/variety/yangpu_riverside_1.jpg` |
| `yangpu_riverside_2.jpg` | `131a542025a779302933458301671110f6641feebb7f96a5e147965469b1bc08` | 198665 | 是 | `/workspace/landscape/variety/yangpu_riverside_2.jpg` |
| `yangpu_riverside_3.jpg` | `837e7a4952c4e82c2aa9a2dc075406426ea6696140f991f54a8ba5661ef20fed` | 268461 | 否 | `/workspace/landscape/variety/yangpu_riverside_3.jpg` |
| `yangpu_riverside_4.jpg` | `23fc0fe305cb7f91a5945df011f50f067e3dd51cfb350a26e4c7ef00cfa83321` | 194258 | 否 | `/workspace/landscape/variety/yangpu_riverside_4.jpg` |
| `yangpu_riverside_5.jpg` | `80f86f1bf79e0b8c7c71259e1cc4829bf636af74f81a3926e05fcc52b667c4c4` | 151161 | 是 | `/workspace/landscape/variety/yangpu_riverside_5.jpg` |
| `yangpu_riverside_6.jpg` | `0ca7d3521c5f513704b5da8b6553889087b134e203f877d3e91cf97c4cc475d0` | 68566 | 是 | `/workspace/landscape/variety/yangpu_riverside_6.jpg` |
