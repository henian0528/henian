# 雁尾洲公园（variety 早期批次）

- 归档编号：`yanweizhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：8 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：6

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety 洪水相关配图并入雁尾洲同案。
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yanweizhou_1.jpg` | `6e0ef4cf7041e7e307b2a221c63fa14e861331b697cf25c094a45117a891b728` | 167474 | 是 | `/workspace/landscape/variety/yanweizhou_1.jpg` |
| `yanweizhou_2.jpg` | `196b26fb2cba87d8dc9caae906fc7ba3eb9338480129dcb6206a917cf16708fc` | 125651 | 是 | `/workspace/landscape/variety/yanweizhou_2.jpg` |
| `yanweizhou_3.jpg` | `1774c173b36b389d0155f482045e39a1b540f042a464b3bba0dab8ee3a1d79e4` | 278670 | 是 | `/workspace/landscape/variety/yanweizhou_3.jpg` |
| `yanweizhou_4.jpg` | `d6615f3027fad5cfc71c661a5f85b07f9336a1750f77b6dd4fc2ed62716db95f` | 231964 | 是 | `/workspace/landscape/variety/yanweizhou_4.jpg` |
| `yanweizhou_5.jpg` | `65cce194a5df2dffffec1b010c7bc4d2a4803a2e8273bd0ab8f9e6316798a644` | 183323 | 否 | `/workspace/landscape/variety/yanweizhou_5.jpg` |
| `yanweizhou_6.jpg` | `85d1dfd081eac3bbec07ad31ddc49194a4295d54d91a73758f99ad03aaa457a6` | 176326 | 否 | `/workspace/landscape/variety/yanweizhou_6.jpg` |
| `yanweizhou_flood_1.jpg` | `196b26fb2cba87d8dc9caae906fc7ba3eb9338480129dcb6206a917cf16708fc` | 125651 | 是 | `/workspace/landscape/variety/yanweizhou_flood_1.jpg` |
| `yanweizhou_flood_2.jpg` | `6e0ef4cf7041e7e307b2a221c63fa14e861331b697cf25c094a45117a891b728` | 167474 | 是 | `/workspace/landscape/variety/yanweizhou_flood_2.jpg` |
| `yanweizhou_flood_3.jpg` | `977b16dfa70229fe57e0366eb8f3c0a35542c1aa4476f4371d36604da3246875` | 281381 | 是 | `/workspace/landscape/variety/yanweizhou_flood_3.jpg` |
| `yanweizhou_flood_4.jpg` | `a8c3cc91f4f845671b47574bb40d0595121f251482c4012870b5ebff5e5492e8` | 177792 | 是 | `/workspace/landscape/variety/yanweizhou_flood_4.jpg` |
