# 韦莱斯-马拉加城堡观景花园（西班牙）

- 归档编号：`velez_malaga_viewpoint_garden`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch31`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `velez_malaga_viewpoint_garden_1.jpg` | `6af652d2dea8b3c6d9c500ee6322b5456250dfc230fd4d9de520aabe715d07ee` | 830242 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_1.jpg` |
| `velez_malaga_viewpoint_garden_10.jpg` | `cb2da7a91b5adfbcd55e63c843ac41b9ff0c43aec380cbe909e52781dccaab56` | 402387 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_10.jpg` |
| `velez_malaga_viewpoint_garden_2.jpg` | `95357c73ee92cd1af77caa1ee7416138b3ca6f328197f4afead32e2b6050edb1` | 501713 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_2.jpg` |
| `velez_malaga_viewpoint_garden_3.jpg` | `14b8245a9c79e6f8101b9b004168394324d2db9cfda60ac87ff658528575356f` | 510979 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_3.jpg` |
| `velez_malaga_viewpoint_garden_4.jpg` | `1e0cbc4d00442d6296c0c8ff17daf34d76903560ba6a6d02e8923342f8b58430` | 811045 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_4.jpg` |
| `velez_malaga_viewpoint_garden_5.jpg` | `909a99e5d5d7b379bda0c219c2afaa22526a8d0c04577932ce4392b8828f7ff5` | 602180 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_5.jpg` |
| `velez_malaga_viewpoint_garden_6.jpg` | `011ef0ce3191b9419d9bf840af563bd22919adce67961bf137bd2b630b3ec4eb` | 840886 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_6.jpg` |
| `velez_malaga_viewpoint_garden_7.jpg` | `74226e013b391666ce6a71b93c2ac8f051da5e98e2986b9ac49fa90743410f34` | 904335 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_7.jpg` |
| `velez_malaga_viewpoint_garden_8.jpg` | `a77ad952028fe4ea11abc295dc73401973920d1799a7b5883712dc90cf3b6714` | 775175 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_8.jpg` |
| `velez_malaga_viewpoint_garden_9.jpg` | `053f1eeafb884aa90f5222933fbb6c8ea8be06add17e31097abb536d3c24516e` | 281313 | 是 | `/workspace/landscape/batch31/velez_malaga_viewpoint_garden_9.jpg` |
