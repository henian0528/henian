# 无废智能生态岛（深圳）

- 归档编号：`wastefree_ecoisland_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：7 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wastefree_ecoisland_sz_1.jpg` | `91805aa4d69c56cc7fd6d7e4dd9319603718236bceb9f3e54ad04691e9863053` | 694933 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_1.jpg` |
| `wastefree_ecoisland_sz_2.jpg` | `d04a688b047e113a83d436a4f494f3f47125053c67181fe99e0c5ef21a078620` | 766438 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_2.jpg` |
| `wastefree_ecoisland_sz_3.jpg` | `a033ba7bc9ed740720a43f186a691f22966e78788f19c6ae5c1217c0dcabc6ab` | 744429 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_3.jpg` |
| `wastefree_ecoisland_sz_4.jpg` | `43cef520cff1d2fd8834dd200465d80c94b18b922d54c82b17b660466bb5c676` | 685694 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_4.jpg` |
| `wastefree_ecoisland_sz_5.jpg` | `1e8216373c98351accfeea33204c4a75aed197fb9b891a759878d796249bfaf5` | 805618 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_5.jpg` |
| `wastefree_ecoisland_sz_6.jpg` | `b690e03ff67c092a4ef2fc7f9b12aae69788837c7cebf48eb769445d296a4c07` | 749971 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_6.jpg` |
| `wastefree_ecoisland_sz_7.jpg` | `573fa383f7908e08f712f428d503216d7e144713f4bdf085ef2f732f6d353f8b` | 708177 | 是 | `/workspace/landscape/batch27/wastefree_ecoisland_sz_7.jpg` |
