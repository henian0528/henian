# 望山（湖州，white2）

- 归档编号：`wangshan_huzhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wangshan_huzhou_1.jpg` | `1896b34eb02f2c91606b2b25426f7eaf12b85716ccf9f628a3bdfd990344c842` | 101525 | 是 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_1.jpg` |
| `wangshan_huzhou_2.jpg` | `0e4ac1edc84f6d8c308ad08bd143fbce91e634a9bd4ecac3ef33d75d6ce2bf2a` | 162173 | 是 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_2.jpg` |
| `wangshan_huzhou_3.jpg` | `21701d81a2accaa5a899aa20fad4ad4861baef0de6e783c77f8e55b87c44bf59` | 233796 | 是 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_3.jpg` |
| `wangshan_huzhou_4.jpg` | `01bed0e98cde88e64f4f9952186cd956cb4ce84ba3a89b283cfd1aeae58db111` | 293381 | 是 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_4.jpg` |
| `wangshan_huzhou_5.jpg` | `a006eeba5598a423f46143f2341948fa1e260dfd472a9e43daa57a771aa186dc` | 260661 | 否 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_5.jpg` |
| `wangshan_huzhou_6.jpg` | `7086bc428475408972942600b09413f163912202d2701920fc1538b870c6dedb` | 110325 | 否 | `/workspace/landscape/china-canopy-cases/white2/wangshan_huzhou_6.jpg` |
