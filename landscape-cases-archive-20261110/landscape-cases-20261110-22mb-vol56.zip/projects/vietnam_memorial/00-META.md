# 越战纪念碑（variety2 早期批次）

- 归档编号：`vietnam_memorial`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：4 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `vietnam_memorial_1.jpg` | `5a9e98b010ff9753e7faac910bcccd521f59b7278dab2ee964c5f0be2a6d3419` | 612814 | 是 | `/workspace/landscape/variety2/vietnam_memorial_1.jpg` |
| `vietnam_memorial_2.jpg` | `13bf22279545390fa549b5f89674d90b07b60fed6db329ff6d70c766dd07ad60` | 662322 | 是 | `/workspace/landscape/variety2/vietnam_memorial_2.jpg` |
| `vietnam_memorial_3.jpg` | `0cf53878bac6ef539fe333d43c934c5f65d0862b8e89c4ce16d5b2e831118672` | 425727 | 是 | `/workspace/landscape/variety2/vietnam_memorial_3.jpg` |
| `vietnam_memorial_4.jpg` | `f8a634b20c879300f2c338fcddbde59ec118804add92f518ae2f36172a0f51ed` | 1353935 | 是 | `/workspace/landscape/variety2/vietnam_memorial_4.jpg` |
| `vietnam_memorial_5.jpg` | `0aed5b56bf62535dd20a91c6a427802f6ca5a1d35c63371214706a12afb41678` | 602139 | 否 | `/workspace/landscape/variety2/vietnam_memorial_5.jpg` |
