# 华南蓬寺 Rukkhaniwet 公园（曼谷，Shma）

- 归档编号：`wat_hua_lamphong_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wat_hua_lamphong_bkk_1.jpg` | `00e442c680aedd24c82dc0e3e7bb385a128ed8bf7b8bb7faede88f539654688d` | 295064 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_1.jpg` |
| `wat_hua_lamphong_bkk_2.jpg` | `74e48b3edfdbc5168dc5973613cdcd8b286264fd19d5db45c71f93645b399567` | 278229 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_2.jpg` |
| `wat_hua_lamphong_bkk_3.jpg` | `cd1625e92a2cf50539b00ecfb78b50802197496de026b877869fdb089309d7a2` | 225623 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_3.jpg` |
| `wat_hua_lamphong_bkk_4.jpg` | `54d2fbe133fc5821ee26c564c01b6a450c3fc3a0cb694b15a47b8f49bd8534a8` | 527952 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_4.jpg` |
| `wat_hua_lamphong_bkk_5.jpg` | `0f3f8ae15423b1778e53b87e4555ca1cb5c143e336e9dd28c73ba6812c788a5d` | 261583 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_5.jpg` |
| `wat_hua_lamphong_bkk_6.jpg` | `746b6140a3c7e0945bd340d62a1531932807487b826f228fd8841e97322545e6` | 275942 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_6.jpg` |
| `wat_hua_lamphong_bkk_7.jpg` | `4aa4d3427466364aa354d97cf70a34b6b54a03bd6c72a85738fc7e037825e17d` | 177269 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_7.jpg` |
| `wat_hua_lamphong_bkk_8.jpg` | `fd2941dca6d7eeb5b5deb5246b5aad21a226f430d43a8bd3cf7be96290f6e345` | 209384 | 是 | `/workspace/landscape/batch26/wat_hua_lamphong_bkk_8.jpg` |
