# 无锡渤公岛「翠屏花障」（Wutopia Lab）

- 归档编号：`emerald_screen_wuxi`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：18
- 在 bot 附件库中匹配到的配图：10 / 18（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-26
  - 出处说明：日期目录 2026-10-26（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-26/emerald_screen_wuxi`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`uncertain`
  - 本地来源：`/workspace/landscape/batch7`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `es_01_photo.jpg` | `fc7082a739d82a2c681f3f6fb053fda1965edc25bd623e7c8de861b1894fd229` | 3098497 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_01_photo.jpg` |
| `es_02_photo.jpg` | `90c0f544cdba67174b940d8038f677173212b6f411bfee36fe1c951f81d42285` | 3285884 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_02_photo.jpg` |
| `es_03_photo.jpg` | `e7734c32abffa18584e8d923272434ed88c7158d452ce1efd4112bb29ed7ed5b` | 3349879 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_03_photo.jpg` |
| `es_04_photo.jpg` | `d8cbfec60b9f7640ef60bb83fd6754dc63029ea28952aee73fd4aca58f88e494` | 3264172 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_04_photo.jpg` |
| `es_05_photo.jpg` | `53eff13a938ea9966112603129d53262d4a9582a12633c5b21a8f6a728ad8a13` | 2940954 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_05_photo.jpg` |
| `es_06_photo.jpg` | `88d1e967865fa9daa14c8509e1e8bf4a0eca8d15f967e2489c2b608dbd2c499e` | 4627095 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_06_photo.jpg` |
| `es_07_photo.jpg` | `3007518d391a0c7d0d250cf262ff20956075bd6ceb0adaf9b9660a393076d187` | 1957695 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_07_photo.jpg` |
| `es_08_drawing_site_plan.jpg` | `27f7ce3a9f9bae4378f5bd109a8230665d2f21cca328787a140b94b7f0de2674` | 511257 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_08_drawing_site_plan.jpg` |
| `es_09_drawing_west_elev.jpg` | `8eb9bef0fa4de62b6ee25d8fe06908fc7cf9bd40d3f2dfd97618d97735eff3f7` | 226067 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_09_drawing_west_elev.jpg` |
| `es_10_drawing_section.jpg` | `705fd324e1c313b74f5b40a3264347b6d0f1b5c8f48630c1f2e8b5f13bc1722f` | 223094 | 是 | `/workspace/landscape/2026-10-26/emerald_screen_wuxi/es_10_drawing_section.jpg` |
| `emerald_pergola_wuxi_1.jpg` | `48d8af87cb70651ec2c555d9f9494eef26b23ee7125696a723cfef79804190f6` | 139651 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_1.jpg` |
| `emerald_pergola_wuxi_2.jpg` | `0d566fd7e2ffc70c420b10721a6f3766279e49134a992e9dac439ffdcea79be0` | 197568 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_2.jpg` |
| `emerald_pergola_wuxi_3.jpg` | `4f217f36b72eb2529faa73abad409b63cf93c954e4dd6d8fa82524f652ee5a33` | 207486 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_3.jpg` |
| `emerald_pergola_wuxi_4.jpg` | `d0afb06f6e9bdecb059bc709fd923eb69719e47a462484078ab7c37d116efc28` | 237793 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_4.jpg` |
| `emerald_pergola_wuxi_5.jpg` | `085bb775207d16b7da2f1ac0192dd19ffe9752aad3206cf8f7685ca2f0e68146` | 179586 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_5.jpg` |
| `emerald_pergola_wuxi_6.jpg` | `eba59a8dc9d324c1579f1b347d76beabf1dd98cc742e77d4425bcd417d3c50cb` | 843100 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_6.jpg` |
| `emerald_pergola_wuxi_7.jpg` | `0ca84aad0d887d8afb975e0fb1f7d6f7e5d34fb90bcf6be8324174eecffb6a5e` | 268786 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_7.jpg` |
| `emerald_pergola_wuxi_8.jpg` | `284a8e6104233e9f103e2ad18b7ef82cc9601bcdaed21b443e47c59c1eb61ca9` | 813641 | 否 | `/workspace/landscape/batch7/emerald_pergola_wuxi_8.jpg` |
