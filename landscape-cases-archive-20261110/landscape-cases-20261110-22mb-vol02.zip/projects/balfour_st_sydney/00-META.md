# Balfour St（期刊记因图片拦截未发）

- 归档编号：`balfour_st_sydney`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：4
- 在 bot 附件库中匹配到的配图：4 / 4（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`（后续补发，见 texts/original-*）
  - 本地来源：`/workspace/landscape/batch31`
  - 注：期刊明确记载未发。精选图仍归档，但不算已推荐。
  - 本记录配图文件数：4

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `balfour_st_sydney_1.jpg` | `5b01d2e15a333d26f4cc498f1334966ddde65a85b96413ca3215c714ff743caf` | 70718 | 是 | `/workspace/landscape/batch31/balfour_st_sydney_1.jpg` |
| `balfour_st_sydney_2.jpg` | `bdae7530b36a6f7f1473fe19a9ee997e30e7bfe7458d8a9fbc74a037c6400b27` | 154689 | 是 | `/workspace/landscape/batch31/balfour_st_sydney_2.jpg` |
| `balfour_st_sydney_3.jpg` | `9f11996e232f107c7a207a59b681a0d637e1febe7a0a67a29ce7f5ffb83418b4` | 129980 | 是 | `/workspace/landscape/batch31/balfour_st_sydney_3.jpg` |
| `balfour_st_sydney_4.jpg` | `f0ee97d850d91afc2fa4cc4f77945f8ea4094d4f6d7f57e81f33f27eb3f332c2` | 113758 | 是 | `/workspace/landscape/batch31/balfour_st_sydney_4.jpg` |
