# 白云庭院（长阳路138弄，Wutopia Lab）

- 归档编号：`baiyun_courtyard`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：12
- 在 bot 附件库中匹配到的配图：10 / 12（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch10`
  - 本记录配图文件数：12

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `baiyun_courtyard_1.jpg` | `ad26da223af2f8cb5d078708a050de7211a20b813dc7072d4927f831b9c280d8` | 387435 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_1.jpg` |
| `baiyun_courtyard_10.jpg` | `78390221ab1de332dfb0dcaec5e0511622de923bef49ac9fcdf6decbf91bad3c` | 117833 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_10.jpg` |
| `baiyun_courtyard_11.jpg` | `762e189d9b0cda7708f4675d19135beb404c6fdfc6920146ea1de3a33c947e75` | 154686 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_11.jpg` |
| `baiyun_courtyard_12.jpg` | `afe5a04b008f0aefc22af5873b949069d42c236d9b53ba1e7e8b60daf9305290` | 179095 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_12.jpg` |
| `baiyun_courtyard_2.jpg` | `a1adc7129ed5879b8e78609f1b22e096f634301ebc7c752e7517938760161546` | 431315 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_2.jpg` |
| `baiyun_courtyard_3.jpg` | `37ca589af7a21b6936deee4b9105b67b2f2dddb3b3bd4f0365dfd8f21f9e1bfd` | 333816 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_3.jpg` |
| `baiyun_courtyard_4.jpg` | `a144732e4deb2b436975cb99da26a6aee748cec36911e6e33c2a7fd5d8ae9c8f` | 427669 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_4.jpg` |
| `baiyun_courtyard_5.jpg` | `d866d360a8af02e47f2c023d128b3e6eda9d5f70d9d8b5c8fc9f5ca494b301ec` | 354486 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_5.jpg` |
| `baiyun_courtyard_6.jpg` | `234a05fda36af1fa1e3247f79de3307dde660b704e57adc0584f224a47b60a94` | 568531 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_6.jpg` |
| `baiyun_courtyard_7.jpg` | `fe182d43dbc3cb9a0525659a2cc08e286c375717c38e5524ac527ef9bb76e64e` | 378686 | 是 | `/workspace/landscape/batch10/baiyun_courtyard_7.jpg` |
| `baiyun_courtyard_8.jpg` | `5690f2336116015efb584d1781203965cb7971402db3cf057fb153a73dc30a85` | 575107 | 否 | `/workspace/landscape/batch10/baiyun_courtyard_8.jpg` |
| `baiyun_courtyard_9.jpg` | `221c980e59c2f08d4ad76000788163647e71dd4a58fef05fbb7b813955350d2b` | 401056 | 否 | `/workspace/landscape/batch10/baiyun_courtyard_9.jpg` |
