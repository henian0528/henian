# 芭蕉叶亭／相关遮阳案例（china-canopy）

- 归档编号：`bananaleaf`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·国内折板/伞状遮阳及棚架案例（目录 china-canopy-cases；期刊有「答应找国内类似 Superkilen 案例」）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases`
  - 注：来源 china-canopy-cases
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bananaleaf_1.jpg` | `1131ca7f7b39bd9cd40ed66f777b30f94021fb4a87c8d6df858da94f435c4cf4` | 708264 | 是 | `/workspace/landscape/china-canopy-cases/bananaleaf_1.jpg` |
| `bananaleaf_2.jpg` | `4dc19d371f5f9d1215bf473d8685377cdb4218b107e9507d69c577749271a44a` | 605478 | 是 | `/workspace/landscape/china-canopy-cases/bananaleaf_2.jpg` |
| `bananaleaf_3.jpg` | `f53faf3b6ce80ea31770c3cf2febc8c7cc830441b8c8c6fcbbc2ef090caaab53` | 394739 | 是 | `/workspace/landscape/china-canopy-cases/bananaleaf_3.jpg` |
| `bananaleaf_4.jpg` | `868734ce4ff5e3ccdd97652ec24f79fdddddc5e040320c7f300a4016ac6774a5` | 535537 | 是 | `/workspace/landscape/china-canopy-cases/bananaleaf_4.jpg` |
| `bananaleaf_5.jpg` | `447b803293726c601b22a006f10cc02d38f694f9287b196f5e5dacc603495bec` | 1217168 | 否 | `/workspace/landscape/china-canopy-cases/bananaleaf_5.jpg` |
| `bananaleaf_6.jpg` | `2b7580223f8b0e20c41b286fbab3a7d776968dc21a0d793a0756acc3ba99694a` | 1445788 | 否 | `/workspace/landscape/china-canopy-cases/bananaleaf_6.jpg` |
