# 百花园书屋与曲廊廊架（信阳，刘宇扬）

- 归档编号：`baihuayuan_xinyang`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（与 xinyang_pergola 为同一项目，见 texts/original-*）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 同项目互见

与 `xinyang_pergola` 为同一项目（信阳百花园曲廊与花亭，刘宇扬）。2026-10-08 已发原文见该目录；本目录为 2026-11-01 的另一批配图，哈希不同。

## 出现记录（不改写）

- 日期/标记：2026-11-01
  - 出处说明：日期目录 2026-11-01（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-11-01/baihuayuan_xinyang`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bh_01_photo.jpg` | `dfb2e95bedd789532aa6ec393a8b92c66a95c9c2538436365e1a3791ac3a91e5` | 683521 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_01_photo.jpg` |
| `bh_02_photo_pergola_trees.jpg` | `7d654af0e7aad7bd2e3010aea91abbae3db29cbf5ae50aece4fd62cc26c7f51f` | 916919 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_02_photo_pergola_trees.jpg` |
| `bh_03_photo_pergola_detail.jpg` | `7e7a3cc764ff1799bfffa3c7852604de9459b74cf4563980bd422273fc4d3533` | 606994 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_03_photo_pergola_detail.jpg` |
| `bh_04_photo_veranda.jpg` | `bab716fbf028d112dac75c7bbcca53ebe2a7f00fc5241f25ce62c2cda2aa6692` | 520154 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_04_photo_veranda.jpg` |
| `bh_05_photo_eaves.jpg` | `dd30e314331c92d93dd0557c266a98f431a1ef69c026b56c4835c808adb73278` | 624693 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_05_photo_eaves.jpg` |
| `bh_06_photo_station.jpg` | `668e5c31d4317ccca2be7189a31fbdc99a4e0649725796e45534cfea5678ced9` | 875517 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_06_photo_station.jpg` |
| `bh_07_photo_flowerhouse.jpg` | `8ca5005167a742efd3d252c396dc42e818f143e563b703fc520e77d2c8e5fd07` | 911475 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_07_photo_flowerhouse.jpg` |
| `bh_08_drawing_station_elevation.jpg` | `f380b70d1f35abfd0f49ebe27c28c733e74a91e18a64decc9c1254a4ab1937d6` | 404296 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_08_drawing_station_elevation.jpg` |
| `bh_09_drawing_pergola_section.jpg` | `6d2a10c345fb8b5d70acd90aa234429ce20e0e98f09c6250bc0017c536a9ef59` | 315634 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_09_drawing_pergola_section.jpg` |
| `bh_10_drawing_flowerhouse_plan.jpg` | `33dd1cf7eebfae31164531b485c2d75e79f44b8a3d620aab94b35679a16d34ee` | 381983 | 否 | `/workspace/landscape/2026-11-01/baihuayuan_xinyang/bh_10_drawing_flowerhouse_plan.jpg` |
