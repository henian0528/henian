# 博爵堡别墅庭院（重庆，MUSO 木守）

- 归档编号：`bojuebao_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch21`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bojuebao_garden_cq_1.jpg` | `c4390967e921121b1ea2c3e6b05557bff170b965891d76a29490b211b8ed1a98` | 852476 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_1.jpg` |
| `bojuebao_garden_cq_10.jpg` | `42d8a191f1c255bf6921db64e7e6e99479bd502c7f12b236ff0f8008d62ad457` | 576700 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_10.jpg` |
| `bojuebao_garden_cq_2.jpg` | `6672b60df631088ee722403759860183c20fd5634bc5f8d835e9b43424e0867c` | 485043 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_2.jpg` |
| `bojuebao_garden_cq_3.jpg` | `b0a77bb55edb92a2c31e3ed665cbc9c93d678bd61de312bb7b7ec76b5eda5393` | 684291 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_3.jpg` |
| `bojuebao_garden_cq_4.jpg` | `65239171ae6e9954355cb4f64416b441f5994f7422384596e4badc8c6f5a0507` | 469187 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_4.jpg` |
| `bojuebao_garden_cq_5.jpg` | `98262e46fb57d56dda789c63060e324f0ce22242fc185a818d18ea607d5042a8` | 531955 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_5.jpg` |
| `bojuebao_garden_cq_6.jpg` | `86bfe2d3f28646d16893808eb36ee3b88eb54544296470d19bd85419be872a0b` | 412620 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_6.jpg` |
| `bojuebao_garden_cq_7.jpg` | `c062298e7c1b331d1776e51e5b6806523c35afb1d9de582c55e3f31c92d463d4` | 811717 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_7.jpg` |
| `bojuebao_garden_cq_8.jpg` | `cd66582daa15d999565f4a28b2ed83c7023fffed29cf7a44d5c925bedaad4a01` | 565717 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_8.jpg` |
| `bojuebao_garden_cq_9.jpg` | `832bbe4cf3a6dbcebfc4f3c5571b9318c04afaa409328f3df9ecf9b8f8e0f5ba` | 504813 | 是 | `/workspace/landscape/batch21/bojuebao_garden_cq_9.jpg` |
