# Blank Garden（东京，Unemori）

- 归档编号：`blank_garden_tokyo`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch22`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `blank_garden_tokyo_1.jpg` | `ff2b218f00da0d72a6e65b9f58e7429dc9d1e916dc080c7d422e466152c4064c` | 461827 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_1.jpg` |
| `blank_garden_tokyo_10.jpg` | `88c9fb2e9bf961a31f82e621b61ef79e81cf38073bc9d0f4c027f9a82bcc5b66` | 200806 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_10.jpg` |
| `blank_garden_tokyo_2.jpg` | `a16c7c3b4a8bb8557116c86562b752e495635237402db1d295c0e020eda92d83` | 642387 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_2.jpg` |
| `blank_garden_tokyo_3.jpg` | `542d47097997ee4aaeb779047a1fda1a213dfe970e8c39cf5109c38af315515f` | 628966 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_3.jpg` |
| `blank_garden_tokyo_4.jpg` | `17879af70c56b26aba0214f44978b036f4ef44e3fb579aa3c1696a2facd1a579` | 759467 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_4.jpg` |
| `blank_garden_tokyo_5.jpg` | `86bd3b68f189ae5a244277e32cac078ef9302b9d4d5958de236945ad0471e544` | 795839 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_5.jpg` |
| `blank_garden_tokyo_6.jpg` | `f4b8a6705a2b2cc3ad0b19de396385e859af3394e0be2f85fc5942d5282d0d17` | 777586 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_6.jpg` |
| `blank_garden_tokyo_7.jpg` | `7892b26787baf89bed5c20c2ceb939fecbd0092897575f2c35ff159b19bd57af` | 343785 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_7.jpg` |
| `blank_garden_tokyo_8.jpg` | `8ccccc32487c44fcd80b87fb2bcabe6a2cf35c8b88b48df75f53d21eef030266` | 501186 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_8.jpg` |
| `blank_garden_tokyo_9.jpg` | `199e1667939fbdc3f9509262353d0fc50fd5007ff2ef9e9259464a6735dae021` | 358654 | 是 | `/workspace/landscape/batch22/blank_garden_tokyo_9.jpg` |
