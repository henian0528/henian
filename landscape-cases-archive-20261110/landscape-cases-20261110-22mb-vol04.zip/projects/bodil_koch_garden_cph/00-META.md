# Bodil Koch's Garden（哥本哈根）

- 归档编号：`bodil_koch_garden_cph`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bodil_koch_garden_cph_1.jpg` | `c8e56cc6c7940d5b45096e41ad8ff66603980db8cfdbaea3ddfa1867961df99e` | 908593 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_1.jpg` |
| `bodil_koch_garden_cph_10.jpg` | `1b3cbcf7b7eaf3c98530308fd569cab9f94d26acb90f3b956dba770a8aedac68` | 734367 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_10.jpg` |
| `bodil_koch_garden_cph_2.jpg` | `3136862e08bd831b903e69afacccb53db2b9cb132ff497e725be54fc9036598d` | 494059 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_2.jpg` |
| `bodil_koch_garden_cph_3.jpg` | `87860bfddf85eead683c8f9a57b1d828b9f8421c968f43946e7b414c50058bbc` | 667277 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_3.jpg` |
| `bodil_koch_garden_cph_4.jpg` | `e0e71871f6ec102452ee266b1198bbccafbe3869e2c8fee7720a87efbf94b894` | 655670 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_4.jpg` |
| `bodil_koch_garden_cph_5.jpg` | `263caec4640bb2b127c51d89c96019d2ae43fa30132daf63ce8e22c1134f80ae` | 620317 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_5.jpg` |
| `bodil_koch_garden_cph_6.jpg` | `87d726ca73f17fb37f81449eaac3e03ed829a0066114ef8db96e2de13bffe019` | 722990 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_6.jpg` |
| `bodil_koch_garden_cph_7.jpg` | `3df763c79d4093594425ffa3a8a41b719cb6f9e649a6e94862998b02702d6bc2` | 771414 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_7.jpg` |
| `bodil_koch_garden_cph_8.jpg` | `41d65c74aa59c5e616b92ffba94416a01913c7b13ecda1b92431092cee860ed9` | 656275 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_8.jpg` |
| `bodil_koch_garden_cph_9.jpg` | `71b8d2df71bd65610b5be2a172ecea0e5f61188e697ea1f8ddd561f50eddea9a` | 1009820 | 是 | `/workspace/landscape/batch27/bodil_koch_garden_cph_9.jpg` |
