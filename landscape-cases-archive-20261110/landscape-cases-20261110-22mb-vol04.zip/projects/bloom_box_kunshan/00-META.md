# 花盒咖啡（昆山）

- 归档编号：`bloom_box_kunshan`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `bloom_box_kunshan_1.jpg` | `f3b7140f37addd8c288c8a517d152f1ceb57fb46035b8f2f45c08ed9e2fd6cb6` | 223847 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_1.jpg` |
| `bloom_box_kunshan_10.jpg` | `eda4819e486b8e94f95aa8030c9acf1d266dd70163901c8a4fe6398814f853f8` | 126380 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_10.jpg` |
| `bloom_box_kunshan_2.jpg` | `a4cd46f5d6e14558b84f06feea98368da64bd39cd6fd1d5b84027eff2a4c9609` | 156595 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_2.jpg` |
| `bloom_box_kunshan_3.jpg` | `778af507fa25b8c0c46fdf12a45b2004c500071a23bd64275970336d5029fd46` | 220784 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_3.jpg` |
| `bloom_box_kunshan_4.jpg` | `e7eac9416912cf9a992d066ab8a2df6ebcabd6e7fe9288a9848d45cf63628f8d` | 175444 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_4.jpg` |
| `bloom_box_kunshan_5.jpg` | `da2b67b8ced0019698f89ef29378c596f70725d02b3b7f58e97be1e0c3bd3433` | 131176 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_5.jpg` |
| `bloom_box_kunshan_6.jpg` | `838d354fcc2e5ccd830039b96d314e3a95c3f2b0fea4717f6cee641129ba6066` | 176826 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_6.jpg` |
| `bloom_box_kunshan_7.jpg` | `0c90a468d6aa53825019ebc84a682a054fce402bceeb1e39508cce2ff2a8efd7` | 154338 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_7.jpg` |
| `bloom_box_kunshan_8.jpg` | `a1d944f1c54080a6b902f7f646b1af7a3b1712800d2c0f08acf71f2b9d5173a6` | 153332 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_8.jpg` |
| `bloom_box_kunshan_9.jpg` | `65fa161cea83aed62ce91c1b4ed70289533a60f2d4a028500f3527f2810e9aed` | 162772 | 是 | `/workspace/landscape/batch8/bloom_box_kunshan_9.jpg` |
