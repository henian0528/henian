# Meiso no Mori / Ito（white2）

- 归档编号：`meiso_ito`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `meiso_ito_1.jpg` | `9c897ef84e7f9e48085227e3bc11736238ae1b3f2ff8a9c788afe205c0a1ada3` | 555224 | 是 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_1.jpg` |
| `meiso_ito_2.jpg` | `2d2ea5ddcd0d52cec38f78e8f5ee4948516eba9f2d0b400aec9f6768025a8932` | 559079 | 是 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_2.jpg` |
| `meiso_ito_3.jpg` | `d9147a82af7e9ccffd5713c037a51ed8190d1468d60536b55753684ac7b8578b` | 555690 | 否 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_3.jpg` |
| `meiso_ito_4.jpg` | `8e3df9b17d2ae0996e31c95e692818c22b29ca2fa652bd3461f953918ce145cc` | 354316 | 否 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_4.jpg` |
| `meiso_ito_5.jpg` | `a401da9f9dfac26c8414ba46c9a48deb656d9a109f4f3f6aca48c5e878438520` | 195500 | 是 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_5.jpg` |
| `meiso_ito_6.jpg` | `532c056b67c223460b8ef2b64ead4d76b00094303b4153cadc2b8478a531acd3` | 136933 | 是 | `/workspace/landscape/china-canopy-cases/white2/meiso_ito_6.jpg` |
