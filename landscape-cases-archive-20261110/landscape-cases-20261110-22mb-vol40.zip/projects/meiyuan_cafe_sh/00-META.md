# 梅园咖啡花园（上海，batch18）

- 归档编号：`meiyuan_cafe_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `meiyuan_cafe_sh_1.jpg` | `48dec67440dca23a2b518f474e3bba3b79450be6e8261f4350d9776260bc3d8f` | 425383 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_1.jpg` |
| `meiyuan_cafe_sh_2.jpg` | `0ff1c69fb7888d52e422bd9fad9d08f3d16c2bd5733d4e21817766fbbf539770` | 520020 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_2.jpg` |
| `meiyuan_cafe_sh_3.jpg` | `c82685eae4c1c3eed29074b50f464a140e0a19a8f83388ad4e06fa3b30473ebc` | 553211 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_3.jpg` |
| `meiyuan_cafe_sh_4.jpg` | `e230acb148d94d6b92a12ed3fcc04d89a9fc394ce38424a16b66a6a086001fff` | 391529 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_4.jpg` |
| `meiyuan_cafe_sh_5.jpg` | `ef654527865942cdc11f45e5a251e57822d7baf48f2d4c5aa64a9915a88d5787` | 335170 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_5.jpg` |
| `meiyuan_cafe_sh_6.jpg` | `bc0196655f19fa14ebaad10d0276099e5cace9ceffca90da57f08c9948b24a30` | 441987 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_6.jpg` |
| `meiyuan_cafe_sh_7.jpg` | `52b3320fb64835368ffb424ea6916bf36c2e687ad094a26b5b9bbdf4cf57de5c` | 369097 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_7.jpg` |
| `meiyuan_cafe_sh_8.jpg` | `b1f7bdc991dfecc03c2b9d0dd954adefd16362c050d350537aa4b1fe3076ace5` | 332158 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_8.jpg` |
| `meiyuan_cafe_sh_9.jpg` | `8fb75d67d184707cd09f87c7bc346b620da39fac89f450e12d39253fd9853364` | 120378 | 是 | `/workspace/landscape/batch18/meiyuan_cafe_sh_9.jpg` |
