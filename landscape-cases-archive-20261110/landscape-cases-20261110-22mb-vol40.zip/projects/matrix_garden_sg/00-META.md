# The Matrix Garden（新加坡，Sanitas Studio）

- 归档编号：`matrix_garden_sg`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch17`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `matrix_garden_sg_1.jpg` | `b4b7665f35a56d4d4e2402815537975f9294eef1c41b596dcde9528788552751` | 220254 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_1.jpg` |
| `matrix_garden_sg_10.jpg` | `0459831b3ef39a4ad384aa38916ab9280012de1de82af8a125578a9000f15f8a` | 100732 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_10.jpg` |
| `matrix_garden_sg_2.jpg` | `b70b962ee88328a8908becf655b80ad980d5c7482a3c29ee805cc16a7cb49c0b` | 251764 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_2.jpg` |
| `matrix_garden_sg_3.jpg` | `672469f9b1d0fe01ed7c3ad97de5c9c0a3e54ca6aa6296c7671cad69ad1afcb6` | 289744 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_3.jpg` |
| `matrix_garden_sg_4.jpg` | `82d318f61a0a28b6baf0d5abf0b1464da822f919c11ddbbc0ad6612a8e356bc1` | 267940 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_4.jpg` |
| `matrix_garden_sg_5.jpg` | `2cc7ecf18de84cadf6e49a8020e5dd2a80a2f40cb18738ae7ac433cf8336b351` | 206902 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_5.jpg` |
| `matrix_garden_sg_6.jpg` | `cd19af7929ddad848ccb5a788a6b716c37c4c8f35a2aeaa17193723941bbc93b` | 291906 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_6.jpg` |
| `matrix_garden_sg_7.jpg` | `d0eb60b21789ee318c9a8239305305c444443f721a06d1023f141f0289314c4d` | 289230 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_7.jpg` |
| `matrix_garden_sg_8.jpg` | `67cb9b19874e054451dca42e0782b16a9320f6dbb07b164b1b5a432135323c48` | 117207 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_8.jpg` |
| `matrix_garden_sg_9.jpg` | `e267bdc6d0dd5f975b08b0ffd2caa62b0c70a256e516448e61839d1405c3312e` | 238167 | 是 | `/workspace/landscape/batch17/matrix_garden_sg_9.jpg` |
