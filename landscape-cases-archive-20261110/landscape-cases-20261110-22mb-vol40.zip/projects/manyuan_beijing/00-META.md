# 满园（北京，TAOA）

- 归档编号：`manyuan_beijing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `manyuan_beijing_1.jpg` | `7230fcab097a48992a664f6adf8c1aae09d20628d803dbbd2180c43ac60463c6` | 880876 | 是 | `/workspace/landscape/batch23/manyuan_beijing_1.jpg` |
| `manyuan_beijing_10.jpg` | `669d867b8f7246661f45e94d8fe2fa9186c8162f02d1e2aa32e9522dab85c908` | 286690 | 是 | `/workspace/landscape/batch23/manyuan_beijing_10.jpg` |
| `manyuan_beijing_2.jpg` | `594244c1996b826ce054922ea21ed07e2c50c37ec73ffb69969f5637acc302ae` | 774762 | 是 | `/workspace/landscape/batch23/manyuan_beijing_2.jpg` |
| `manyuan_beijing_3.jpg` | `db63b4a63d65d4430a88568133882e56142b754a9a7dfd02a51df88bd555a2de` | 1195300 | 是 | `/workspace/landscape/batch23/manyuan_beijing_3.jpg` |
| `manyuan_beijing_4.jpg` | `aa4bb3e0fe2bd936d55ece85d6fa8a89b5a46f7ab569bcda943a443733dc47cb` | 696197 | 是 | `/workspace/landscape/batch23/manyuan_beijing_4.jpg` |
| `manyuan_beijing_5.jpg` | `e78bc9300965b44779e8e7829e28147d6540ceedee7adf3a32b1b98a49ea8657` | 674841 | 是 | `/workspace/landscape/batch23/manyuan_beijing_5.jpg` |
| `manyuan_beijing_6.jpg` | `8566872f6cd6113c8dc7fe97d12ea1e0295dc846325e613aede4e7323d9688c9` | 552028 | 是 | `/workspace/landscape/batch23/manyuan_beijing_6.jpg` |
| `manyuan_beijing_7.jpg` | `64cf7a2b56153b75b8518203eb7a5d453c51660025414f3a2478194ea0210a12` | 633696 | 是 | `/workspace/landscape/batch23/manyuan_beijing_7.jpg` |
| `manyuan_beijing_8.jpg` | `43e80deb101c84ffc92d2668b5a38fa1bd27f63271e9ef25c8cc236a1cbd7a52` | 601060 | 是 | `/workspace/landscape/batch23/manyuan_beijing_8.jpg` |
| `manyuan_beijing_9.jpg` | `8c8a0908a7968dc44f1aa2525a6be64fc7df05c01c5919fec4cbcde995553f87` | 601250 | 是 | `/workspace/landscape/batch23/manyuan_beijing_9.jpg` |
