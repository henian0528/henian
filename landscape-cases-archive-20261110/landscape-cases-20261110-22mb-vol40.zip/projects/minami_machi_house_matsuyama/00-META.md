# House in Minami-machi（松山，Jun Yamaguchi + Chiba Plantation）

- 归档编号：`minami_machi_house_matsuyama`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch21`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `minami_machi_house_matsuyama_1.jpg` | `d230f4678d974392300b4b6f575c8e9e7a0e97c785d8c6d9df11b4988c8995ea` | 558118 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_1.jpg` |
| `minami_machi_house_matsuyama_2.jpg` | `c805344841153c8c27a3313c109a08ce12c089324892c68b85e1c3ea0d189888` | 518038 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_2.jpg` |
| `minami_machi_house_matsuyama_3.jpg` | `209d1b3837f490ab99ea8cb76a54ab399831d7180162ac2f230e115add42c6f2` | 612035 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_3.jpg` |
| `minami_machi_house_matsuyama_4.jpg` | `2d29e8e81f0061e4f4af8d873e5360f5d290d9c93c178d7e799363c0afb84926` | 953833 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_4.jpg` |
| `minami_machi_house_matsuyama_5.jpg` | `4e7a4120d09d46dab2b9a86d276363a027566347502b058c768473c35f620eee` | 517224 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_5.jpg` |
| `minami_machi_house_matsuyama_6.jpg` | `ddf7d14101345cc72ca94eb8ca3e59a2c969e4baee38116c246106e877c1c7ef` | 202861 | 是 | `/workspace/landscape/batch21/minami_machi_house_matsuyama_6.jpg` |
