# PK House（曼谷，batch18）

- 归档编号：`pk_house_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `pk_house_bkk_1.jpg` | `d5d7b660f238fd0b9809947a58d5f2ae000e5443b2ec2b7004969c4bdaf21796` | 645483 | 是 | `/workspace/landscape/batch18/pk_house_bkk_1.jpg` |
| `pk_house_bkk_2.jpg` | `9b6da8aed7766f2f26e76d7c45c0cfb5f435751d6a3da34d57c22184a5ce72f7` | 628429 | 是 | `/workspace/landscape/batch18/pk_house_bkk_2.jpg` |
| `pk_house_bkk_3.jpg` | `42c4648900071870d71d5e008ea33f7c5ba56747530c896c2127d04f78df1ad3` | 664766 | 是 | `/workspace/landscape/batch18/pk_house_bkk_3.jpg` |
| `pk_house_bkk_4.jpg` | `13d611b3b1fb21fee9271d77ca126db4592765216bfe82987aa5bc22a1b3eef0` | 483402 | 是 | `/workspace/landscape/batch18/pk_house_bkk_4.jpg` |
| `pk_house_bkk_5.jpg` | `d986640a7ee570497a8928a71c07dc5ca256e56a66b33a07a36c283d8fbd2123` | 624696 | 是 | `/workspace/landscape/batch18/pk_house_bkk_5.jpg` |
| `pk_house_bkk_6.jpg` | `63667304d815e8e25f30a30062ee28fea20a9d889fe726a268ff2a94aa1ac1fa` | 585618 | 是 | `/workspace/landscape/batch18/pk_house_bkk_6.jpg` |
| `pk_house_bkk_7.jpg` | `af0f2164c706ab6f1873cc24ef6891827e429f8275441bbbbceaa7d20bb05b2f` | 722148 | 是 | `/workspace/landscape/batch18/pk_house_bkk_7.jpg` |
| `pk_house_bkk_8.jpg` | `96b7bcd81ac3a0dea316ea325d3db84434d10be1a68754cc5b5528dc1e499741` | 552219 | 是 | `/workspace/landscape/batch18/pk_house_bkk_8.jpg` |
| `pk_house_bkk_9.jpg` | `69b8cb3e410e7e44aace49c01cc9ba8a272669cfdc5e6895264f6a8999b4360e` | 557872 | 是 | `/workspace/landscape/batch18/pk_house_bkk_9.jpg` |
