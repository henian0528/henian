# 台南柳营站前「蜻蜓，轻亭」（丁尺建筑师事务所，2023）

- 归档编号：`pointe_liuying`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-11
  - 出处说明：日期目录 2026-11-11（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-11/pointe_liuying`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `pp_01_photo_aerial.jpg` | `36258eb2d8bf76dc510fc9e1b78484411767d6d1156fdbc5479b79149f4c76ac` | 776546 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_01_photo_aerial.jpg` |
| `pp_02_photo_street.jpg` | `6e298ec2766ecba9001166e93e8d1b26be8b0fa65cc0af8177e8dddb9ded9582` | 523696 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_02_photo_street.jpg` |
| `pp_03_photo_longcanopy.jpg` | `77df6726b51604ad7b6aa4102b4908391cbc9e4729a1991de7f7abff435efc0a` | 776462 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_03_photo_longcanopy.jpg` |
| `pp_04_photo_passage.jpg` | `1f2cc432d7185943311224ae41c2da7b117ec5298194291d341a6d27071c6db6` | 518241 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_04_photo_passage.jpg` |
| `pp_05_photo_skylight.jpg` | `2fcbebf5201e0ff42e513e13aac3389d0659ac1345525dc29d8cd152daca0898` | 575352 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_05_photo_skylight.jpg` |
| `pp_06_photo_columns.jpg` | `3e8311d5707d4233d623e9535b37fa226c742c4048ae534411638b754e4f02f7` | 218692 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_06_photo_columns.jpg` |
| `pp_07_photo_night.jpg` | `46cfb3db0153f54d0e274c5315a82341640917f53edf90932a357cfe2afc5f3f` | 308490 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_07_photo_night.jpg` |
| `pp_08_drawing_axon.jpg` | `bcf5eed291a970cc6a384eadc491f5c808d7def598fd4cb9d9c2b65ff6b0f24e` | 245450 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_08_drawing_axon.jpg` |
| `pp_09_drawing_plan.jpg` | `e44306e50d0eeb0dd4ed167e2dfa0f71b4b3d46c44fe3a3e69a2d83a9f4a5f55` | 188821 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_09_drawing_plan.jpg` |
| `pp_10_drawing_elevation.jpg` | `daa72c69380d81b4027aa27bcd364c2d51515e307db2f300af2765f41214c58a` | 124610 | 是 | `/workspace/landscape/2026-11-11/pointe_liuying/pp_10_drawing_elevation.jpg` |
