# Pocket Campus Bernini（都灵，期刊记图片曾被拦截）

- 归档编号：`pocket_campus_bernini_turin`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`（后续补发，见 texts/original-*）
  - 本地来源：`/workspace/landscape/batch28`
  - 注：期刊记载当时图片下载受阻；本地后来有精选图，是否补发未从对话记录确认。
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `pocket_campus_bernini_turin_1.jpg` | `71240446537ef6800ce4627e45e5a18282bdfaf169726d08448646b2965101a6` | 1216206 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_1.jpg` |
| `pocket_campus_bernini_turin_10.jpg` | `48de1fe86cbe84b975364a5065daeae3cce3e8af6e1ef287719382e8320bd0b6` | 705255 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_10.jpg` |
| `pocket_campus_bernini_turin_2.jpg` | `65b06728bcaeaba4a9a7c079556fe607b7ac0584032bb4927fb2dd47a2c0d2cc` | 288328 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_2.jpg` |
| `pocket_campus_bernini_turin_3.jpg` | `7322d1882cb2a4e471d730e7c192c4f97ee00d3b9fcd64553f387ef5ef492f2e` | 243904 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_3.jpg` |
| `pocket_campus_bernini_turin_4.jpg` | `4d671b0f2bc85175f654a717214e67fae054d3de8faea89d116be4d73f60ab69` | 537590 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_4.jpg` |
| `pocket_campus_bernini_turin_5.jpg` | `d3d10ba698acbb4a160ef15790e6c8ef1f90b54301e41e806e20a3fb10f16ed2` | 520255 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_5.jpg` |
| `pocket_campus_bernini_turin_6.jpg` | `16804e4593a6c0b71b21af10e93b73b94010292e18112c4dbaf5fa79aedf2189` | 339253 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_6.jpg` |
| `pocket_campus_bernini_turin_7.jpg` | `9629c0995a9aa789712075bed01aa552b67ef80732f4e7febe17bf16a8f84d50` | 557462 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_7.jpg` |
| `pocket_campus_bernini_turin_8.jpg` | `9a7ec343f824dd55c94eafb1c26c6c95dd9228cb145d8a3b69ca0edc3b7e7bf5` | 432358 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_8.jpg` |
| `pocket_campus_bernini_turin_9.jpg` | `7692f18f67a4e43f919f15be18f73fbd29071c756b9a6a4718bed258a4ab9450` | 488616 | 是 | `/workspace/landscape/batch28/pocket_campus_bernini_turin_9.jpg` |
