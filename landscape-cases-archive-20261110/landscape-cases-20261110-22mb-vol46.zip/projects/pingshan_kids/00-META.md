# 坪山儿童游乐（variety 早期批次）

- 归档编号：`pingshan_kids`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·多种类型（屋顶花园/儿童场地/滨水/雨水或洪水/乡村等，与期刊「看完屋顶花园、儿童游乐场、滨水步道、雨水花园、乡村景观」相合）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety`
  - 注：来源 variety
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `pingshan_kids_1.jpg` | `e45821a17f82d87dac79d21ac6dc7bd5fc9749ed3fb15f5b34d2a0cd1814df3f` | 207727 | 是 | `/workspace/landscape/variety/pingshan_kids_1.jpg` |
| `pingshan_kids_2.jpg` | `b443a410f993d26fd951cf789e3afa8956dfe00db237e3294a81589566aec85a` | 238800 | 是 | `/workspace/landscape/variety/pingshan_kids_2.jpg` |
| `pingshan_kids_3.jpg` | `a5fb9bd8499a1a2e3673ccf68505c4c38bb9c886d2b4a90ba4c738a3bf5042b8` | 263190 | 是 | `/workspace/landscape/variety/pingshan_kids_3.jpg` |
| `pingshan_kids_4.jpg` | `f41dfeb415dca9983847f6d15417d21632bf550e35112a66a6ffc1685b116531` | 228263 | 是 | `/workspace/landscape/variety/pingshan_kids_4.jpg` |
| `pingshan_kids_5.jpg` | `ca32f38b10f41e5e770709838732488076c9b56d7c0b760f2d05e53740b69fbe` | 163438 | 否 | `/workspace/landscape/variety/pingshan_kids_5.jpg` |
| `pingshan_kids_6.jpg` | `c71543804a4c2efa046207906856073dbaef41caa15bd1e7b412136cdb0b0fa9` | 303579 | 否 | `/workspace/landscape/variety/pingshan_kids_6.jpg` |
