# 柱之亭（宁波象山，Found Projects + 明暗研究室）

- 归档编号：`zhuzhiting`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：20
- 在 bot 附件库中匹配到的配图：20 / 20（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-14
  - 出处说明：群聊工作日日推（目录与来源页为柱之亭；11-10 群推配图说明称10月已推过）
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/2026-10-14`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

- 日期/标记：2026-11-10
  - 出处说明：日期目录 2026-11-10（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-10/zhuzhiting_xiangshan`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zhuzhiting_10_section.jpg` | `82a4c270eab082b7b12d1b4979ff966fcf0f11647bd5a886bbbe31ee0568ab83` | 38282 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_10_section.jpg` |
| `zhuzhiting_1_aerial_coast.jpg` | `9ab9e4ee449d748541683b76ba691277350071daf0652aa0be99a9485897025e` | 399747 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_1_aerial_coast.jpg` |
| `zhuzhiting_2_roadside.jpg` | `96b674411d5859f8057651bde4e4ccb82476d92218f5e72ef0c2a0efe2088e44` | 211412 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_2_roadside.jpg` |
| `zhuzhiting_3_front_elevation.jpg` | `1f28b2a8529e80ad8db97070e269a3e977aad706bf9036c42232de9e386f3b7d` | 134214 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_3_front_elevation.jpg` |
| `zhuzhiting_4_thin_roof_columns.jpg` | `a5fdc73f0b0fd65bc4fc14248fcb4eb7d62a031376ae26bf477e470451ebb787` | 374178 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_4_thin_roof_columns.jpg` |
| `zhuzhiting_5_tower_through_roof.jpg` | `bf0499fa79b0e32fca44bdb50e271cf57e21d37470cbc8588e7b0020f78ae5b9` | 318613 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_5_tower_through_roof.jpg` |
| `zhuzhiting_6_mirror_ceiling.jpg` | `81e7111d202c763c7dec4a298b82d943c13be69dc83a83fda5679421a0061bfc` | 236018 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_6_mirror_ceiling.jpg` |
| `zhuzhiting_7_periscope_view.jpg` | `7a80f3efb1e1e8fd2d90077ccd9b01bd0d48bfd549dc6a04e027aa9bf147a2de` | 261310 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_7_periscope_view.jpg` |
| `zhuzhiting_8_axo.jpg` | `ba86d47b87efe8b78e6972e45174fc4c025a2846dec35ab6a380b59b71a9ad29` | 71173 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_8_axo.jpg` |
| `zhuzhiting_9_plan.jpg` | `97c55a3c41b38c40f5dd2bdcccbb29ac213816a2be29be33a46faec3206ffeb5` | 51755 | 是 | `/workspace/landscape/2026-10-14/zhuzhiting_9_plan.jpg` |
| `zz_01_photo_aerial.jpg` | `dd7bf0a1498a293842935502aad1112dab31acecab2b4ff5be6283bdd92e4bcd` | 870797 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_01_photo_aerial.jpg` |
| `zz_02_photo_overview.jpg` | `1322304cc752d75754a05ecdf62a65576c5004d007d38fb132352f1d5dd588c9` | 799029 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_02_photo_overview.jpg` |
| `zz_03_photo_appearance.jpg` | `b9bfaf39fc96e622cc0f434b7e061b70502f845e52e568bc5f69951ec8d6288f` | 488655 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_03_photo_appearance.jpg` |
| `zz_04_photo_columns.jpg` | `bc9d580c8331f60f3be1ac3bf56521ac3578e26b1ea0562660292bea562f6f7e` | 935080 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_04_photo_columns.jpg` |
| `zz_05_photo_furniture.jpg` | `032117ecb7bc2f6638065222509163e46707c836fd0cb2af76db6af8b30d3b41` | 539374 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_05_photo_furniture.jpg` |
| `zz_06_photo_periscope.jpg` | `fdda66a0703ce6cf3783ff09e995c0f61a70ac9ad79e7b9fa0cafea953c8578a` | 768295 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_06_photo_periscope.jpg` |
| `zz_07_photo_openplan.jpg` | `ec24eb5c5d39b255a936f596846693265d4aa484b7dbe1b647945833bde46585` | 528748 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_07_photo_openplan.jpg` |
| `zz_08_drawing_elevation.jpg` | `557f212994e3420fe789a997063b83ee5c8d732ab53cdf3075e8f09ff34db35c` | 58999 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_08_drawing_elevation.jpg` |
| `zz_09_drawing_plan.jpg` | `9cef4a30792be900a42d95f1cd19c4dfd0406c3751a0e4c2f19f0866149f49f2` | 69534 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_09_drawing_plan.jpg` |
| `zz_10_drawing_section.jpg` | `7245b4afb366293efe10bbeca6aa616ce92526b7f515d24b5c24f0d84a194735` | 46713 | 是 | `/workspace/landscape/2026-11-10/zhuzhiting_xiangshan/zz_10_drawing_section.jpg` |
