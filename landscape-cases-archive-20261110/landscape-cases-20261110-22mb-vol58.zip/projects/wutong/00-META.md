# 梧桐亭，深圳（悉地国际东西影工作室）

- 归档编号：`wutong`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-19
  - 出处说明：工作日目录：梧桐亭。原文未从对话记录回读
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-19`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wutong_01.jpg` | `5bcf43dd55c0521d21737a3e179ab5609861ff973455ace20f3884f91bb5c6f3` | 242695 | 是 | `/workspace/landscape/2026-10-19/wutong_01.jpg` |
| `wutong_02.jpg` | `303e87078ae5d27ff0f5d4e2323fa09528c017a872f075bb57562588709c1c1f` | 169940 | 是 | `/workspace/landscape/2026-10-19/wutong_02.jpg` |
| `wutong_03.jpg` | `7744b75c8d9153ebe87ef8b41ceac0e454bf745cbe1aaba3e5bd492a9d5de03d` | 185252 | 是 | `/workspace/landscape/2026-10-19/wutong_03.jpg` |
| `wutong_04.jpg` | `ada0775d838b910ae759bfcfdbc56e476581c4b85c1712e198ff7db4984bb124` | 357797 | 是 | `/workspace/landscape/2026-10-19/wutong_04.jpg` |
| `wutong_05.jpg` | `63ddc24b7f8d04ee5e711ce84f1d6754c835b899001de8786c483844a1922ec3` | 178345 | 是 | `/workspace/landscape/2026-10-19/wutong_05.jpg` |
| `wutong_06.jpg` | `3b6726d100216dc38242dd422148620d35638779ce9e182c7fa2ee4c899342c3` | 125605 | 是 | `/workspace/landscape/2026-10-19/wutong_06.jpg` |
| `wutong_07.jpg` | `038e0858a4a33b7ea7c82da0e2e2ae15e758122c7a16deb3dad64c017d7f1e55` | 169746 | 是 | `/workspace/landscape/2026-10-19/wutong_07.jpg` |
| `wutong_08.jpg` | `d714cf6195d5b71c205951836717a66fdeae9cde7dcdc7fb1292991a7a81ee63` | 170375 | 是 | `/workspace/landscape/2026-10-19/wutong_08.jpg` |
| `wutong_09.jpg` | `2ce40864b2f241349c4ea6adc0872d1bc701007e57871cbf3562dcacc4eb814c` | 52506 | 是 | `/workspace/landscape/2026-10-19/wutong_09.jpg` |
| `wutong_10.jpg` | `c3d711bf25adbf5d26b72712b51a5b600693241a54ddc56b12eed488336e9018` | 41845 | 是 | `/workspace/landscape/2026-10-19/wutong_10.jpg` |
