# 「一页白纸」阅读亭（塔林，Ninja Stuudio）

- 归档编号：`white_sheet_tallinn`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：13
- 在 bot 附件库中匹配到的配图：10 / 13（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch10`
  - 本记录配图文件数：13

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `white_sheet_tallinn_1.jpg` | `d18e711353e44748ea28aae3f7ff3e2e9bc1e8ccb224e1b9f15749ba7a70b21e` | 1056944 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_1.jpg` |
| `white_sheet_tallinn_10.jpg` | `34c6a3cf0aab108a8a5b52951130a1e1e8837cb8c9d44f43c5c791aeb9463543` | 147416 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_10.jpg` |
| `white_sheet_tallinn_11.jpg` | `0a457503a617c5d3e317a4bbd49d89416c221acdf8828d3e26ec92136eaecf9f` | 111120 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_11.jpg` |
| `white_sheet_tallinn_12.jpg` | `2f899549edcc708e7a8df96d3b31f0194366a8ba03639c911179449733fb7d85` | 96475 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_12.jpg` |
| `white_sheet_tallinn_13.jpg` | `13deff1964139c604019ad6c3bbb1c84e193f4a7c54964a46540d0048b2a7943` | 118989 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_13.jpg` |
| `white_sheet_tallinn_2.jpg` | `ccb21bd958547d9d1feaef685b15642800beb752b529792fc603113c46542aa2` | 707623 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_2.jpg` |
| `white_sheet_tallinn_3.jpg` | `3e7d46ad0a02b6a95f776f5b66b658b6353db3965e638b09326176d8901eafa0` | 1037549 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_3.jpg` |
| `white_sheet_tallinn_4.jpg` | `3f91000ac72b9e654e7f5100aee80d4b5af42e8dc49389d610da33b90d1e6ee8` | 1149689 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_4.jpg` |
| `white_sheet_tallinn_5.jpg` | `36245610005e6232ac5d0efe210780930b0ff21fd2dffafb9c777e654fd98e07` | 1056730 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_5.jpg` |
| `white_sheet_tallinn_6.jpg` | `29fcf65d473839a8d4905c8c1bc82e5f1ef1f47db96e05df2906d5c69c8b90f3` | 906207 | 是 | `/workspace/landscape/batch10/white_sheet_tallinn_6.jpg` |
| `white_sheet_tallinn_7.jpg` | `cd745b0d90b594ff134d7b706fae2ebf86908e6991a4dcb96b374832616c9d33` | 879493 | 否 | `/workspace/landscape/batch10/white_sheet_tallinn_7.jpg` |
| `white_sheet_tallinn_8.jpg` | `136a05b6e9719da2be8268da622341996d22dae46ac68b46648bd06d801036e6` | 696888 | 否 | `/workspace/landscape/batch10/white_sheet_tallinn_8.jpg` |
| `white_sheet_tallinn_9.jpg` | `da341f5655a5b7ac546071c4e1b419a4ac8290396cb96150ec04397f72952053` | 1282473 | 否 | `/workspace/landscape/batch10/white_sheet_tallinn_9.jpg` |
