# 达拉斯 Westmoreland Park Pavilion

- 归档编号：`westmoreland_dallas`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：4 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `westmoreland_dallas_1.jpg` | `87598513701bf95ac65eb05ca664b42f4893ae74363f47060098f8bdd7619759` | 203025 | 是 | `/workspace/landscape/china-canopy-cases/white/westmoreland_dallas_1.jpg` |
| `westmoreland_dallas_2.jpg` | `06fbfd7acbfd1003d48ade85406b2fe0beb0b69e15363e06e4b6de4ec671052b` | 124959 | 是 | `/workspace/landscape/china-canopy-cases/white/westmoreland_dallas_2.jpg` |
| `westmoreland_dallas_3.jpg` | `eb0f72afc87fa360405c39fdf1bb45900c84e09ab6d721502e376914cbb97608` | 157026 | 是 | `/workspace/landscape/china-canopy-cases/white/westmoreland_dallas_3.jpg` |
| `westmoreland_dallas_4.jpg` | `1cff1b7fa4576cf0d12a4d502a46b7385a0427265cb4d13aeca2c8cf2417c1f4` | 531094 | 是 | `/workspace/landscape/china-canopy-cases/white/westmoreland_dallas_4.jpg` |
| `westmoreland_dallas_5.jpg` | `d1a41a724ffa679d2f1f69469a5f2bfc73ee1fb80c89cc842a6eba9a3d84736c` | 97510 | 否 | `/workspace/landscape/china-canopy-cases/white/westmoreland_dallas_5.jpg` |
