# 白色七巧板（华东师大一村入口）

- 归档编号：`white_tangram_entrance`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `white_tangram_entrance_1.jpg` | `073c62636344d83c08ce4ee8d613ddbbe60456712a3c1a263e06d6839305e297` | 580557 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_1.jpg` |
| `white_tangram_entrance_10.jpg` | `e414b782176da4620b3dcde70c7c7a873f563b3670b880d44b390192f29591fb` | 189194 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_10.jpg` |
| `white_tangram_entrance_2.jpg` | `1ad0f6443f8d90a6acfa2942ab3c8f656d4f21e2066753b3fadae414991c7034` | 474703 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_2.jpg` |
| `white_tangram_entrance_3.jpg` | `54eaaae53b96c697a541011e2988c1883915e5cd095bdd6e59746ccebdc8745a` | 582203 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_3.jpg` |
| `white_tangram_entrance_4.jpg` | `fa9a767a0a6512e5c080740fea60411ade0fd9a9da68ce0b8b8d1991126f170d` | 395446 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_4.jpg` |
| `white_tangram_entrance_5.jpg` | `870dacb57108b77e3d2f423b3a64c9eeced304fb0c276781ebcc865d501446e7` | 722222 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_5.jpg` |
| `white_tangram_entrance_6.jpg` | `4ee87a51a6120a04a02fc7b19450d2c8584067cfdcdd4d13cc3947b421763f37` | 385697 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_6.jpg` |
| `white_tangram_entrance_7.jpg` | `113621cc4890548dc55ec233c01d5c8027d17664f3a49feb10b32a17945762fc` | 320467 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_7.jpg` |
| `white_tangram_entrance_8.jpg` | `f447f097be5731abb59c9b32bf1b4525cb4ce413aa81fef723f9cad2141f8bcc` | 406473 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_8.jpg` |
| `white_tangram_entrance_9.jpg` | `b60c8a61264a6f7f4cdfa9c0d29dd516707c746f4e28a0466079467d7d50d41d` | 441225 | 是 | `/workspace/landscape/batch12/white_tangram_entrance_9.jpg` |
