# 武汉凤凰（white）

- 归档编号：`wuhan_fenghuang`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `wuhan_fenghuang_1.jpg` | `5baacb7b3238742725cc7a3c50229a0dec49e5e473f43543aeeaf9cae4e90345` | 147202 | 是 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_1.jpg` |
| `wuhan_fenghuang_2.jpg` | `3ce6621096f8740d8ad13a1b2246073f37893a5605028dd83a42d3aa193fd9a9` | 251492 | 是 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_2.jpg` |
| `wuhan_fenghuang_3.jpg` | `0820d17048c858115d3a35a1bec11b8f70f2d3ddb5bc935ab2942c600ecf79c0` | 156792 | 否 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_3.jpg` |
| `wuhan_fenghuang_4.jpg` | `93fccd8b467fcaf0054a4a31933a3ec25fcb05078d9c401ede31594b48f0db0d` | 91981 | 否 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_4.jpg` |
| `wuhan_fenghuang_5.jpg` | `7bd34cd9cf036ae571c78efad631da7457e415204fca93b02084e164645c1c33` | 163594 | 是 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_5.jpg` |
| `wuhan_fenghuang_6.jpg` | `d658994f812ef3cfb3ec587042a6d42077771ffd5d56f9945f3c7ecdfc68a9a3` | 48901 | 是 | `/workspace/landscape/china-canopy-cases/white/wuhan_fenghuang_6.jpg` |
