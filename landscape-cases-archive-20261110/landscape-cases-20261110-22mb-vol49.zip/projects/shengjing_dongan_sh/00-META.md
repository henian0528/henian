# 生境东岸（上海）

- 归档编号：`shengjing_dongan_sh`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shengjing_dongan_sh_1.jpg` | `e040ed885ea8cbd72b65c68c050e3b6d25a5e39e04903e6d4427ab0b1d40a81c` | 274931 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_1.jpg` |
| `shengjing_dongan_sh_10.jpg` | `e1fdee0c1191f3c848bc861551fd5a27f980cb7e16a54417acac88dd3d00b6b0` | 87546 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_10.jpg` |
| `shengjing_dongan_sh_2.jpg` | `233fb643283f12e0b1c236f19acb04be1f66312cdb7c594ba715953f45c4f9a3` | 385612 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_2.jpg` |
| `shengjing_dongan_sh_3.jpg` | `07bd5557da1645533cec02c27328e31236934ac04ea9b88e18a642a6767a634f` | 195630 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_3.jpg` |
| `shengjing_dongan_sh_4.jpg` | `2f63f7106eadeea18c42b39057a26c0528e4fc633027c383c1ad7e875939bb3b` | 480472 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_4.jpg` |
| `shengjing_dongan_sh_5.jpg` | `3007e69674c59e4bc51e80ae91593a17b0f4a2adddbb8305b4ba5d3128868da0` | 417379 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_5.jpg` |
| `shengjing_dongan_sh_6.jpg` | `d742a875ff66ccd1699468e0b3e072b2e4f34dc62ca7f673a59409934caed937` | 414986 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_6.jpg` |
| `shengjing_dongan_sh_7.jpg` | `76f22c2b1576eeb275fe34ce6a416f5c5a6e91ec5415e05e7629f9845fd2eb5f` | 300749 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_7.jpg` |
| `shengjing_dongan_sh_8.jpg` | `39fba2a026de77d6279defa114d8bf9086fe0e2f0823080fa3b204e4e7697d08` | 475876 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_8.jpg` |
| `shengjing_dongan_sh_9.jpg` | `0e6b243ff26cd35efcbafc51a32a282ae2e2e7ff4a5ada57ad16d510e7e3c8b1` | 254442 | 是 | `/workspace/landscape/batch26/shengjing_dongan_sh_9.jpg` |
