# 天樾私人住宅花园（MUSO 木守）

- 归档编号：`skyline_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `skyline_garden_cq_1.jpg` | `fb8d4caeb2de6e78a1892971d7630b6fbb2d9d220e4bbad057846196ab886080` | 511969 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_1.jpg` |
| `skyline_garden_cq_2.jpg` | `d09a58d2fb23fd1f9b431e3f15b7a714cc439c4229d01e5988278a9788ecea0c` | 508030 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_2.jpg` |
| `skyline_garden_cq_3.jpg` | `a58259e8fc2e56167a3148d1701a733d36ea6df1bcd4e4e7db59130ce88dd7d8` | 579288 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_3.jpg` |
| `skyline_garden_cq_4.jpg` | `700c0c3b989513cd8a786ab86f61ac8dd4ea46cbb2c9f048fabad27e597df31e` | 489414 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_4.jpg` |
| `skyline_garden_cq_5.jpg` | `12025658d84ad27a1b9c620cd21c1d2411190f87156df0ebd8df80d0e6badb3c` | 353034 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_5.jpg` |
| `skyline_garden_cq_6.jpg` | `14a4cccb52af7e58137c8c3dcb515e48533ed08d86a66d5c23bc8901ac38cdf8` | 396979 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_6.jpg` |
| `skyline_garden_cq_7.jpg` | `a9be8cabad51b205d730ce00c5a6e5f97f750bdcf47f61f9471509cdcaf2f8a2` | 434067 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_7.jpg` |
| `skyline_garden_cq_8.jpg` | `1a1d61fe45d138d2f95c970c90fdf7aec5ce21a721ff034df6d102857d9d3c78` | 372297 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_8.jpg` |
| `skyline_garden_cq_9.jpg` | `f5b89063180b186159e608b9c95edc975e4d760915129affececa7435dbbd585` | 417208 | 是 | `/workspace/landscape/batch20/skyline_garden_cq_9.jpg` |
