# 摄云（腾冲，white3）

- 归档编号：`sheyun_tengchong`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：5 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white3）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white3`
  - 注：来源 china-canopy-cases/white3
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `sheyun_tengchong_1.jpg` | `6fa5193842a4f47b6980efd9cdcf99d63c7bc0a270a1d446efe477c3e266a21c` | 428780 | 是 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_1.jpg` |
| `sheyun_tengchong_2.jpg` | `7dba47a9f677643384ca40efa59e8c68cbe87f976cf13a2255c27446a89c7cfb` | 374437 | 是 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_2.jpg` |
| `sheyun_tengchong_3.jpg` | `7edd60b4f4b6e1352ab30e0784114ea87e2119b1944f2839920f57a704f6cc06` | 318050 | 是 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_3.jpg` |
| `sheyun_tengchong_4.jpg` | `1690d02d22ce8c73b7170e901c80eed2a630fff46ee46f74c78327b4de9b1287` | 330202 | 是 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_4.jpg` |
| `sheyun_tengchong_5.jpg` | `53533d8a5d71674b80d24e26e9446be0c932994cb6f71f2a6b72a7c8788e66ec` | 348009 | 否 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_5.jpg` |
| `sheyun_tengchong_6.jpg` | `b0516cf039ffaeafb769d6a394a64d413af6389e5e6ad6e8ab67ab23b4dd82cb` | 357558 | 否 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_6.jpg` |
| `sheyun_tengchong_7.jpg` | `6d734d448e9c725297c3d19a615082846104d55d164fd7a8d78e7976726a2ab4` | 102714 | 是 | `/workspace/landscape/china-canopy-cases/white3/sheyun_tengchong_7.jpg` |
