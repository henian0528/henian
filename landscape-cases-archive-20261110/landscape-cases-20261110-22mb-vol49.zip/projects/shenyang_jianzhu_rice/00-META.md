# 沈阳建筑大学稻田校园（variety2 早期批次）

- 归档编号：`shenyang_jianzhu_rice`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shenyang_jianzhu_rice_1.jpg` | `86b6e5e383230acd93defe3be255b23d61a255f914b569c4fa5f2bf5ba36f2ca` | 341593 | 是 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_1.jpg` |
| `shenyang_jianzhu_rice_2.jpg` | `baa23c626dd39ddb03780b564df83126627afb3c5a52605901a119cfc3edabe0` | 374738 | 是 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_2.jpg` |
| `shenyang_jianzhu_rice_3.jpg` | `79a9f9ea3277c543a0b7d07da84b68b7c9941b2eeac52b5d8a54177d74c12df7` | 369237 | 是 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_3.jpg` |
| `shenyang_jianzhu_rice_4.jpg` | `bf37762469b5837f71e1419c30e88a89ab656c9e85c5016673efe20c2f7ddbe7` | 295961 | 是 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_4.jpg` |
| `shenyang_jianzhu_rice_5.jpg` | `70744c146640f9895aed57340064b40da61ff26b054a8cc6f54561b07df94b45` | 233249 | 否 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_5.jpg` |
| `shenyang_jianzhu_rice_6.jpg` | `66e2699d5fb0fe28137ac22377599ff19d8a9a3515f90883275b33d133d55904` | 297438 | 否 | `/workspace/landscape/variety2/shenyang_jianzhu_rice_6.jpg` |
