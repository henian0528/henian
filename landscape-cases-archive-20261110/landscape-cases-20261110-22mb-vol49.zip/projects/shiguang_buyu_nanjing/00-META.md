# 时光补语（南京，batch24）

- 归档编号：`shiguang_buyu_nanjing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch24`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shiguang_buyu_nanjing_1.jpg` | `fcc14be6ddab240a81b0ee9a833ef90fb77ffb2d7b60af3bae141bc2684c2c3a` | 418838 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_1.jpg` |
| `shiguang_buyu_nanjing_2.jpg` | `86054ce542562fa5114d9a14b6864836e9e53961d419c9e61ee3abe1276bccda` | 501722 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_2.jpg` |
| `shiguang_buyu_nanjing_3.jpg` | `0f3c48878a1d2c1be5b4861eb7c3036aacc5eb89e63211f23050ff3992085ce2` | 439606 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_3.jpg` |
| `shiguang_buyu_nanjing_4.jpg` | `4817c0a201ee315304c5769905a2df714f92f9ea7784d2a10929555d6b02d5d2` | 623279 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_4.jpg` |
| `shiguang_buyu_nanjing_5.jpg` | `821b6dc72ad37917f4cd2b4f1f5e0fc6fc67d1f51f9fd77879baf8b2bf393822` | 466797 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_5.jpg` |
| `shiguang_buyu_nanjing_6.jpg` | `30d14cb67f760bf01ddae9f536c3c5345ad168d3828c3dcf218681446f70b89a` | 437606 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_6.jpg` |
| `shiguang_buyu_nanjing_7.jpg` | `caf8a4ac8dd61a0363a0081e357fd8909efd84aafad6eb5bcc7b4d5f4b3b4f26` | 481420 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_7.jpg` |
| `shiguang_buyu_nanjing_8.jpg` | `a2002a21f6cf38bf13caebbd4dddab0e03e4b6fbbffa738fedd913d04b8820d4` | 307215 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_8.jpg` |
| `shiguang_buyu_nanjing_9.jpg` | `5a49ad6c1eaf5fa2595a5259b9b0d165a64425ed9a4f699d067893c754edef4c` | 233856 | 是 | `/workspace/landscape/batch24/shiguang_buyu_nanjing_9.jpg` |
