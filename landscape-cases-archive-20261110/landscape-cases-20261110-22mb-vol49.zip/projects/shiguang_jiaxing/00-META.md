# 时光（嘉兴，courtyard 早期批次）

- 归档编号：`shiguang_jiaxing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shiguang_jiaxing_1.jpg` | `e3624993f882cd86d6b0d475cd924aebf19af00396fbc3d2fa726b7e183f70f3` | 170135 | 是 | `/workspace/landscape/courtyard/shiguang_jiaxing_1.jpg` |
| `shiguang_jiaxing_2.jpg` | `c5c4549da4602122e1cbbb60c913b268dcc62231e377e1eab1869407e410ade7` | 246805 | 是 | `/workspace/landscape/courtyard/shiguang_jiaxing_2.jpg` |
| `shiguang_jiaxing_3.jpg` | `f4274bbb3c9006f9ba9cdfec825b72830ccdafc8be19a6f1b79899891c907cc8` | 361184 | 是 | `/workspace/landscape/courtyard/shiguang_jiaxing_3.jpg` |
| `shiguang_jiaxing_4.jpg` | `56329751cfc644a10ebc4b48a7febf7afa39d2564ae55a2260a1be7ebf82e804` | 180317 | 否 | `/workspace/landscape/courtyard/shiguang_jiaxing_4.jpg` |
| `shiguang_jiaxing_5.jpg` | `c07bfb141d952856631176410273b7907c95f53463c8006beb06f4e2041ac196` | 234732 | 否 | `/workspace/landscape/courtyard/shiguang_jiaxing_5.jpg` |
| `shiguang_jiaxing_6.jpg` | `853e6ddd44289b9c86f70f436c319949cf33be983ab7679863ddb10c6d894a81` | 205563 | 是 | `/workspace/landscape/courtyard/shiguang_jiaxing_6.jpg` |
