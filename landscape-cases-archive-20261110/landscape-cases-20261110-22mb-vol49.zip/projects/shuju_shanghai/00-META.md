# 「树」居（上海，大海小燕）

- 归档编号：`shuju_shanghai`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：5
- 在 bot 附件库中匹配到的配图：5 / 5（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：5

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `shuju_shanghai_1.jpg` | `aa5c3cb00cee870aa4903d63ce3daae128d386817770b62dd2afb24c0fc5aaec` | 297063 | 是 | `/workspace/landscape/batch23/shuju_shanghai_1.jpg` |
| `shuju_shanghai_2.jpg` | `20218335c0ac12fddf6196f09bb51d2eccf0fe91c59cb42b34f96380807ccd32` | 310848 | 是 | `/workspace/landscape/batch23/shuju_shanghai_2.jpg` |
| `shuju_shanghai_3.jpg` | `cec7dbb66b57bf810aa565d966548dbd4a569bf1a09b6cd91cdb36421ddedcab` | 184518 | 是 | `/workspace/landscape/batch23/shuju_shanghai_3.jpg` |
| `shuju_shanghai_4.jpg` | `a2e34aee08f2a716b03c099ad5ad27fec68e55dc7a186b08f9d058c23c2cd142` | 533072 | 是 | `/workspace/landscape/batch23/shuju_shanghai_4.jpg` |
| `shuju_shanghai_5.jpg` | `65b0a25e926822532342e7c1da8819b1b7ef930ba197b708b0f30cb0e9a07269` | 167067 | 是 | `/workspace/landscape/batch23/shuju_shanghai_5.jpg` |
