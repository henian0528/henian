# Oishii 公园（新宫，td-Atelier）

- 归档编号：`oishii_park_shingu`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch32`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `oishii_park_shingu_1.jpg` | `78ed5ecd9cc5625b5788ddc9f2228081897df060758ec3b0bdd65413c2403bac` | 1138151 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_1.jpg` |
| `oishii_park_shingu_2.jpg` | `b16f4d871b3ab3f51153b6807b6b3bd46768d6a0c5b8561bd058d55c2c6794da` | 1023580 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_2.jpg` |
| `oishii_park_shingu_3.jpg` | `a4441f8b7e2497061a05274274af38fc2d0cab2e25f27ea58715bf7b3802c6cd` | 692976 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_3.jpg` |
| `oishii_park_shingu_4.jpg` | `24e9bd1e5a3dae17824ebf7f5f55435d50280aced2570543f5577327e59b42a3` | 867110 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_4.jpg` |
| `oishii_park_shingu_5.jpg` | `3efdb81129079a6479ab0a3537c3b91e12e1c221d27fcbcfdbcd9921b4d87dfb` | 974887 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_5.jpg` |
| `oishii_park_shingu_6.jpg` | `b19b36aa869f65c9632871278d5dc0cae1b051c80b61bcbec12eeb59c3332e46` | 815508 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_6.jpg` |
| `oishii_park_shingu_7.jpg` | `8b592ba2b87e03e0d12d1c81ada51ad626ce8a14a5a6f84f3078e63acaf4f80f` | 848225 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_7.jpg` |
| `oishii_park_shingu_8.jpg` | `b39cbefe450457a4a0e2edc9501c9c230d86ca13eb4c47253420013ec5564b1b` | 980881 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_8.jpg` |
| `oishii_park_shingu_9.jpg` | `9f6700b72dbd16f4b9d94e6cc6af6673538f01b8a432cfda41a655b9e711d9b7` | 457813 | 是 | `/workspace/landscape/batch32/oishii_park_shingu_9.jpg` |
