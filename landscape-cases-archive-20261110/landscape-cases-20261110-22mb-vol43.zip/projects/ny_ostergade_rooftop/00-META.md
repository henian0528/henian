# Ny Østergade 屋顶花园（哥本哈根）

- 归档编号：`ny_ostergade_rooftop`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ny_ostergade_rooftop_1.jpg` | `b06c2beb9c9c270a46f09f052fc34f8f2e2473b37d075bcd46e1d79661f6a714` | 443591 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_1.jpg` |
| `ny_ostergade_rooftop_10.jpg` | `7df2fd99aac4dfc5453323ba1a401c6d57fe138c48d2ccaa3bf968ce2397ac52` | 848591 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_10.jpg` |
| `ny_ostergade_rooftop_2.jpg` | `8e08bf4a6b3ee7f103bc99466f9e540470e132a29be5b5b7ef8418c9a2ceb563` | 350774 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_2.jpg` |
| `ny_ostergade_rooftop_3.jpg` | `66d44aa5c05116493bbd22960fa91ab158467c4c5584fa9e853eda0bee22fc58` | 487217 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_3.jpg` |
| `ny_ostergade_rooftop_4.jpg` | `79136c381226bff61b108d21ac57f047a6d777af5acd90196aab50bdfa5b2019` | 458315 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_4.jpg` |
| `ny_ostergade_rooftop_5.jpg` | `76710ccf5ea9d3c5b81a78b439cf90211deb4a7567889d8616e41c467e98a14c` | 409977 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_5.jpg` |
| `ny_ostergade_rooftop_6.jpg` | `48d6b6fc1f9ff58823924505be29ff6600348c78217d70e1f828add46983a85e` | 445262 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_6.jpg` |
| `ny_ostergade_rooftop_7.jpg` | `b58ae3ddb728d39f1544d5f201a19a227ad8d58aedbc7ed6e57ae047f37571f1` | 394420 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_7.jpg` |
| `ny_ostergade_rooftop_8.jpg` | `1996d63afad15a98ce281c3dab10b74e973576325b4dbfb63f92aec87f65f5ea` | 337895 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_8.jpg` |
| `ny_ostergade_rooftop_9.jpg` | `619ef7579b6d525483ba277b7afa570c979e1950856b48b4d83d87f94b5c4c3d` | 583105 | 是 | `/workspace/landscape/batch23/ny_ostergade_rooftop_9.jpg` |
