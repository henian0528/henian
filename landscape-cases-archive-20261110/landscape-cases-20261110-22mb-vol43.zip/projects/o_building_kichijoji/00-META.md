# O_building（东京吉祥寺）

- 归档编号：`o_building_kichijoji`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch28`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `o_building_kichijoji_1.jpg` | `c5c49710c8717e1b0a904e6d240281d5534bfb756240fad95000becaa2884062` | 695429 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_1.jpg` |
| `o_building_kichijoji_10.jpg` | `a5e5bd17467dc063b7f0bfd00cac07b13cb1834a638edcb0079d19633c3946ff` | 114408 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_10.jpg` |
| `o_building_kichijoji_2.jpg` | `af6a406444955b1fe1682142bccc7ccb943b983810cf385a68701019a650c47d` | 700857 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_2.jpg` |
| `o_building_kichijoji_3.jpg` | `265383a92c52a5f0eb43630637a70f1f1b2edae7c3cc55b7c0ff4438ee0607df` | 677746 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_3.jpg` |
| `o_building_kichijoji_4.jpg` | `eb1bfb3d675534ae295fd6090cac3d41643549bfdc914ea5eaa5c3cd1f871af4` | 769475 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_4.jpg` |
| `o_building_kichijoji_5.jpg` | `bb48348f1ba33a5d8eec3363ade02c57f750aa7fcf07ac9dfd9af39918f8dbf1` | 575508 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_5.jpg` |
| `o_building_kichijoji_6.jpg` | `1f3104071aac6d5165da41e5de6d56f96898ba87d792a5221b3ef4a9ddcac2f7` | 552329 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_6.jpg` |
| `o_building_kichijoji_7.jpg` | `bea9f27ee4d95512cbebb624cc7e3b2bae50567e92e2908a846601fe5dbb8c81` | 564206 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_7.jpg` |
| `o_building_kichijoji_8.jpg` | `2abd77f82151a8b208506cef46ed0b8a353af7d5fdbe55f4e3b18bc193cc6c0b` | 559445 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_8.jpg` |
| `o_building_kichijoji_9.jpg` | `b4f0a001823f3a04e51dbfd981e675e2009cdad7fa736b3b6400ba7fe0949ee4` | 444398 | 是 | `/workspace/landscape/batch28/o_building_kichijoji_9.jpg` |
