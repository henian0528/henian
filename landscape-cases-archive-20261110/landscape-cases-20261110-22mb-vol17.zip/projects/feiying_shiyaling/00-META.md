# 绯影驿站（深圳石芽岭，Studio 10）

- 归档编号：`feiying_shiyaling`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-09
  - 出处说明：日期目录 2026-11-09（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-09/feiying_shiyaling`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `fy_01_photo_aerial.jpg` | `848d4376d8c36eb74a58b9b24b3f5fc0c07b1b85cecc97736d98ff5a72f27b3f` | 411645 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_01_photo_aerial.jpg` |
| `fy_02_photo_entrance.jpg` | `a80c0de9bcb685f1dab292a807b8bc6a951802ef8a18c92edbbb1fc7cae5e24e` | 503937 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_02_photo_entrance.jpg` |
| `fy_03_photo_semioutdoor.jpg` | `9516f6c0baa21e6abd9b8096c3256ba62571c4a088560dc52528a4a74889ea43` | 663419 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_03_photo_semioutdoor.jpg` |
| `fy_04_photo_canopy.jpg` | `307b26bacaa082c7af1c4f9c54fa8800944cf62d0c57a954c16aaf1203a461be` | 423048 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_04_photo_canopy.jpg` |
| `fy_05_photo_grayspace.jpg` | `c652de5df80ab4860ed5d530af2d375fb91d1e20c798dfb8868192c52d135a08` | 440114 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_05_photo_grayspace.jpg` |
| `fy_06_photo_rest.jpg` | `509ba83711838f6fed3d6078dc93e15e539eca527306bcdc9c923ad3e06694d5` | 434521 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_06_photo_rest.jpg` |
| `fy_07_photo_skylight.jpg` | `9d9b5f34a63263d5df09b85f4b50f74f6167ecc5b6dd4ea696a379c69648b584` | 300602 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_07_photo_skylight.jpg` |
| `fy_08_drawing_siteplan.jpg` | `d422e002b4f32fd3fa3d5059245bdb0dd7e79c2a628d3c971e16c3c137ee0735` | 140439 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_08_drawing_siteplan.jpg` |
| `fy_09_drawing_plan.jpg` | `ca2b1ed2d26f6fcdccce226b4bebd27dccb322763505a59fe2f2b0d51c643393` | 889836 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_09_drawing_plan.jpg` |
| `fy_10_drawing_section.jpg` | `2d102c8fab2172ed2b0f9a73cdf53b6a116704aa31715a51e309c620c807ad3c` | 88167 | 否 | `/workspace/landscape/2026-11-09/feiying_shiyaling/fy_10_drawing_section.jpg` |
