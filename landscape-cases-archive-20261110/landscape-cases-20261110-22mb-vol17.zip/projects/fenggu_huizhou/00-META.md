# 凤谷驿／五指棚（惠州显岗水库）

- 归档编号：`fenggu_huizhou`
- 推荐状态（汇总）：`likely_sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-11-02
  - 出处说明：日期目录 2026-11-02（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-11-02/fenggu_huizhou`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `fg_01_photo_overview.jpg` | `4d68fda21f2343844b630ea67fa9a76a299e4ef4f209cb11bf8569a2d621649a` | 648576 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_01_photo_overview.jpg` |
| `fg_02_photo_fingers.jpg` | `f612d3ffd0af2ad8694a9a4d68cb469e5e000006e4985bb9aaa90d83a55b5f2f` | 850198 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_02_photo_fingers.jpg` |
| `fg_03_photo_green_roof.jpg` | `91839f05d4a74129676f51f91d2c35428e9073640e059b35be9a784b43a63191` | 1270729 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_03_photo_green_roof.jpg` |
| `fg_04_photo_palm.jpg` | `b0f5e54448740d25099164f3d23ce649027423be047ae37957ffb82ff4ae0d64` | 1150330 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_04_photo_palm.jpg` |
| `fg_05_photo_stair.jpg` | `fb5bf6048e81f2a1eafb17c68b5994aa0527036e969901b6cd5aa196b86c41ee` | 789806 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_05_photo_stair.jpg` |
| `fg_06_photo_woods.jpg` | `5e8cd09ed3dd9831daf55626759fecd3278a1602742c67a81ac587199c4f7801` | 724981 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_06_photo_woods.jpg` |
| `fg_07_drawing_plan_ground.jpg` | `251590c15395ae7854b4f977166190ba35d77eb836d9b3f6f1339028bae8aea2` | 821445 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_07_drawing_plan_ground.jpg` |
| `fg_08_drawing_plan_roof.jpg` | `b3c8646cd32a72a5ae8ab58cd0d1a0bcaecbe8cec6eeef1b7f6a49e954c6fa55` | 861715 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_08_drawing_plan_roof.jpg` |
| `fg_09_drawing_section_site.jpg` | `ff02dd41f8f18ee21fb59455f82b42bec4db96cf5c58a9402da8c66f0a16533a` | 198461 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_09_drawing_section_site.jpg` |
| `fg_10_drawing_section_pavilion.jpg` | `57b56321c4afa14aac3b98495e9363d09ad066d80f22f3d2a404fee08fb41477` | 335406 | 否 | `/workspace/landscape/2026-11-02/fenggu_huizhou/fg_10_drawing_section_pavilion.jpg` |
