# 缘圆园（深圳蔚蓝海岸社区）

- 归档编号：`yuanyuan_garden_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch14`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yuanyuan_garden_sz_1.jpg` | `17bc1b746af1842b6441c20436034bdb2154fa78347e6feda65fae3c2e7000d4` | 768215 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_1.jpg` |
| `yuanyuan_garden_sz_10.jpg` | `486c9ea3dd199cfdadc81109f6784679aaa412c02096e1be219a4b1d1402da52` | 526951 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_10.jpg` |
| `yuanyuan_garden_sz_2.jpg` | `d24eb833e2f47cb27bc6537c90467e987e5fb482b1ad246e6064c4d9bcbaa679` | 940327 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_2.jpg` |
| `yuanyuan_garden_sz_3.jpg` | `a161dbcf1adc98786096cd8d990d9db558e26f7e0f5afd4d06a235ed291f6dfd` | 1006162 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_3.jpg` |
| `yuanyuan_garden_sz_4.jpg` | `f6ba0218dca68f3bf7515cc825e6ffc4556c71a8bcecedd720d4968ed9020215` | 730350 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_4.jpg` |
| `yuanyuan_garden_sz_5.jpg` | `b6112366e2ca5cd82703d22f62e369d5a25c6359af6367c74419dc1e06408a25` | 628664 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_5.jpg` |
| `yuanyuan_garden_sz_6.jpg` | `3a74be7e6af30d362159a9e3de4d9ca5494c38c69ab87db10a1bb78625c25010` | 619469 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_6.jpg` |
| `yuanyuan_garden_sz_7.jpg` | `2b9568843bac02740f21536864865326530b25d8065526b8d522b7dee25ee4f0` | 566734 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_7.jpg` |
| `yuanyuan_garden_sz_8.jpg` | `93a3753cbacd813e1c94735b0b7a01c284daaabd2789b6ce04ae326d0e4f45cb` | 625171 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_8.jpg` |
| `yuanyuan_garden_sz_9.jpg` | `88936eae48d67a861613a2940e4d810da19e2255b0efca88bb33defd15ab28b7` | 617396 | 是 | `/workspace/landscape/batch14/yuanyuan_garden_sz_9.jpg` |
