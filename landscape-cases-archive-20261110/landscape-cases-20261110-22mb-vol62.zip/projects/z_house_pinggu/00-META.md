# Z宅（平谷，Y+Y）

- 归档编号：`z_house_pinggu`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch23`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `z_house_pinggu_1.jpg` | `4bce1fc3129d12ad30f85ca46c64adb41babdc74cdda1a623a9cebd280647120` | 423323 | 是 | `/workspace/landscape/batch23/z_house_pinggu_1.jpg` |
| `z_house_pinggu_2.jpg` | `e646b08f1d94d47bcb83141f708ca10b4b08b2f83385b71683d4e899bf4223a4` | 400824 | 是 | `/workspace/landscape/batch23/z_house_pinggu_2.jpg` |
| `z_house_pinggu_3.jpg` | `33c29140813e8b8c79c29e0f6fde87c8bcd9fba6b3b11122d0ce8ba33da364d2` | 361432 | 是 | `/workspace/landscape/batch23/z_house_pinggu_3.jpg` |
| `z_house_pinggu_4.jpg` | `4f72053506783d6b74e7592db9271da210877affca4d6dae72c019043de1e033` | 200620 | 是 | `/workspace/landscape/batch23/z_house_pinggu_4.jpg` |
| `z_house_pinggu_5.jpg` | `859de4747503b54762ffd5bee9bf8f7db0cda10dd67dab4675831366fe295fe7` | 164013 | 是 | `/workspace/landscape/batch23/z_house_pinggu_5.jpg` |
| `z_house_pinggu_6.jpg` | `bdd35df1a84a1afba9fb5a97623d7e45bf15f2608b38b2660b7036d527020fd1` | 281184 | 是 | `/workspace/landscape/batch23/z_house_pinggu_6.jpg` |
| `z_house_pinggu_7.jpg` | `cbe45c70a7fcce73e56620a8d98cf51b4a4176dc218bb44f078ead4e6802cab8` | 280243 | 是 | `/workspace/landscape/batch23/z_house_pinggu_7.jpg` |
| `z_house_pinggu_8.jpg` | `98cdd84dc0e4cd9a7bdeaac21387add484920b1097db0113fcb8f1c5f499f2d9` | 120958 | 是 | `/workspace/landscape/batch23/z_house_pinggu_8.jpg` |
