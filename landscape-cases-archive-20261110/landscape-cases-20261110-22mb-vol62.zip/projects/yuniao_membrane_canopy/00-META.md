# 玉鸟集食集膜顶棚（良渚）

- 归档编号：`yuniao_membrane_canopy`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yuniao_membrane_canopy_1.jpg` | `e55ba0c370d2fa441b1ed818836666feb163fc3cae18d03e3b3b50dbdd7ac771` | 251360 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_1.jpg` |
| `yuniao_membrane_canopy_10.jpg` | `6b32292a4c46cf5ef0bf87985989e9375710d6c225720aca046b5105c167bd95` | 67565 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_10.jpg` |
| `yuniao_membrane_canopy_2.jpg` | `58fc204f29e452969ab80ffbbaad543bb5a865d499c253191345a7219b839ac8` | 167717 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_2.jpg` |
| `yuniao_membrane_canopy_3.jpg` | `c154139b499185f286bf5adc7842728d430c3239c6778fcac2247f2ae8d8b4c3` | 416158 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_3.jpg` |
| `yuniao_membrane_canopy_4.jpg` | `3f1b811301bbc63cb9661d444e49d3f0dbba85e49e5330a7b183ce027ea0f143` | 198964 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_4.jpg` |
| `yuniao_membrane_canopy_5.jpg` | `f6d2295aecbf85bbcb17b9443f12c250735952a636120a7ffc8dde53c482dc88` | 207716 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_5.jpg` |
| `yuniao_membrane_canopy_6.jpg` | `b7bbe0685c45ef74e3df4091d226b7c8d80c7ac484898257e939b40957176cb0` | 209969 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_6.jpg` |
| `yuniao_membrane_canopy_7.jpg` | `e0c6289d405db5b7324691e8604cba9b30162b698ae9b0a5485e887cded71ba7` | 181897 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_7.jpg` |
| `yuniao_membrane_canopy_8.jpg` | `013ab26542751fc4f439784f29e5052d689ccd051e0678a366abfbbaccf1dea5` | 236510 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_8.jpg` |
| `yuniao_membrane_canopy_9.jpg` | `96ee7966a370f9ede1ec12bc4801d0ceb687f4a3eba2dc188847fc77326d8f1e` | 61242 | 是 | `/workspace/landscape/batch9/yuniao_membrane_canopy_9.jpg` |
