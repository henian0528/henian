# 云之园（white）

- 归档编号：`yunzhiyuan`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yunzhiyuan_1.jpg` | `1eb4f18daf8109cf261721fe61ca77f081b98f24c44104a75da42721df61adaf` | 225975 | 是 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_1.jpg` |
| `yunzhiyuan_2.jpg` | `8bb4f3cf2d71dcfd26d6bdb1146d1b7df66be81f558667671d6cc12db6e58f1d` | 193813 | 是 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_2.jpg` |
| `yunzhiyuan_3.jpg` | `d4a9f0bab459afc94bf1fb27d6bb8942e54a213b5c2e05613633dd2efaca76f7` | 229290 | 是 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_3.jpg` |
| `yunzhiyuan_4.jpg` | `8530b736e9bdc6e14527228a2454e44014538dcdcba015af5de1eafbb4dcb8b6` | 122518 | 否 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_4.jpg` |
| `yunzhiyuan_5.jpg` | `d166a8e2bfdad393017b80698dc003af94e357417c23c3b758f86725c1ff6711` | 175603 | 否 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_5.jpg` |
| `yunzhiyuan_6.jpg` | `a4c465c4132c79f8803d20afa4d698f3d948f8cf936c1a51c209ee278315e68a` | 174497 | 是 | `/workspace/landscape/china-canopy-cases/white/yunzhiyuan_6.jpg` |
