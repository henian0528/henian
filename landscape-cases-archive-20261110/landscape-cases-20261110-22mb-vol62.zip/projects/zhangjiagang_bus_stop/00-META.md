# 张家港高铁新城公交站台

- 归档编号：`zhangjiagang_bus_stop`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `zhangjiagang_bus_stop_1.jpg` | `b72f5ea8b94af9920145f14f2b46835db767d8d90ee424cdd89d12908daa30e7` | 147843 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_1.jpg` |
| `zhangjiagang_bus_stop_10.jpg` | `41174fadc5a793f2dfe3d7ad72b1dcb89da84ce625640fe269885d8ce08d5ac3` | 111374 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_10.jpg` |
| `zhangjiagang_bus_stop_2.jpg` | `17dd90459a3949cd23eeb63fe0f80620ecf73d9d9e116f31560fcaa4e5aa95aa` | 187755 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_2.jpg` |
| `zhangjiagang_bus_stop_3.jpg` | `f72590625f0e5caae886593f02ebd83683ee19db1fcee14c04c7e2de01ad0368` | 133138 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_3.jpg` |
| `zhangjiagang_bus_stop_4.jpg` | `c5427a4aa63425363cb8f096f5b3ea44e5efe0ef85a2e18072dcb0e769b0692b` | 138739 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_4.jpg` |
| `zhangjiagang_bus_stop_5.jpg` | `a5b17e9ecfbed50f1508380613b2a0cf8689df084690df114d58256f02584957` | 118763 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_5.jpg` |
| `zhangjiagang_bus_stop_6.jpg` | `74d1d826372416f110142772f74270e446282dc43b0fcbff7283c47e961537c4` | 101572 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_6.jpg` |
| `zhangjiagang_bus_stop_7.jpg` | `638aa1984cc5667055c5c65eff21bfb8dbf97005555b6f12134cf171402351d8` | 137795 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_7.jpg` |
| `zhangjiagang_bus_stop_8.jpg` | `4b5dda262fe4bae05ce78ec9e43b56f2a9d7cdd982f4615ce5099bb4b0dfdcc9` | 109879 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_8.jpg` |
| `zhangjiagang_bus_stop_9.jpg` | `bd0705ba460dea0d370efef4c130b0af5c9bc47bcf8b3891bb308fa557cb5389` | 87436 | 是 | `/workspace/landscape/batch9/zhangjiagang_bus_stop_9.jpg` |
