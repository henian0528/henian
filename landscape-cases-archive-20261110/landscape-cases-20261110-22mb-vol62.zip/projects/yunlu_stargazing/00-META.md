# 云麓观星（structures 早期批次）

- 归档编号：`yunlu_stargazing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·轻薄构筑/亭廊（目录 structures；含浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/structures`
  - 注：来源 structures
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `yunlu_stargazing_1.jpg` | `aedbb2a7a55e95b437a3d0f238d2fe78d0520c2682269d0e0dc174433402bc19` | 283433 | 是 | `/workspace/landscape/structures/yunlu_stargazing_1.jpg` |
| `yunlu_stargazing_10.jpg` | `8ef4252e421c924509d19a98936aee6d0509ac60f0016373091dea1015c12e94` | 78036 | 是 | `/workspace/landscape/structures/yunlu_stargazing_10.jpg` |
| `yunlu_stargazing_2.jpg` | `a0b2b47e37bfc1a9a4597daf1205b8e9925d29f9c853917702eb1cfec280a940` | 273564 | 是 | `/workspace/landscape/structures/yunlu_stargazing_2.jpg` |
| `yunlu_stargazing_3.jpg` | `2f65fb0514b3af0055f61b838d9e7b2082bacc86e54c1c2c7be506c29c924879` | 254176 | 是 | `/workspace/landscape/structures/yunlu_stargazing_3.jpg` |
| `yunlu_stargazing_4.jpg` | `4510eabb0484ee5944cdc9f51fe60d1ec38c88da588003b6acdf1d0c7f1d6edc` | 302611 | 是 | `/workspace/landscape/structures/yunlu_stargazing_4.jpg` |
| `yunlu_stargazing_5.jpg` | `c8bcf7229f57de781b3e85c46d910de8d022993350f8d5554b29318bf15759bc` | 268399 | 是 | `/workspace/landscape/structures/yunlu_stargazing_5.jpg` |
| `yunlu_stargazing_6.jpg` | `25cb309f99c6502aa06e151ce619dabab0027c195c9bf2f4a8222c76ae5ad1fd` | 257955 | 是 | `/workspace/landscape/structures/yunlu_stargazing_6.jpg` |
| `yunlu_stargazing_7.jpg` | `5afd908078daee041867710353ef2b5e60d2cdd8bfc913fd5c5147f945bb0290` | 220314 | 是 | `/workspace/landscape/structures/yunlu_stargazing_7.jpg` |
| `yunlu_stargazing_8.jpg` | `7f900719f2d4750b1ac0e9145be8676d0d8aebfdb6353cc4b485052613a56e12` | 70090 | 是 | `/workspace/landscape/structures/yunlu_stargazing_8.jpg` |
| `yunlu_stargazing_9.jpg` | `4bb33023ec542a9dd0cb241865b6bdc06091b1e7b1572d916d2d84d8a10879ae` | 335852 | 是 | `/workspace/landscape/structures/yunlu_stargazing_9.jpg` |
