# 二合院（白塔寺，courtyard 早期批次）

- 归档编号：`erheyuan_baitasi`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `erheyuan_baitasi_1.jpg` | `db8ae03f1e29ec64d22fe09011b23c90c7c8876f9aa358c8126d778f53d787dd` | 171283 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_1.jpg` |
| `erheyuan_baitasi_2.jpg` | `4afbd24637fd767429cc60040b4843c3c7bd4b66b4c85681243810b05ad98a5b` | 173052 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_2.jpg` |
| `erheyuan_baitasi_3.jpg` | `fa8f7f63533eb1484e23da63c41d43a8bfc13b1ae92661e2b02590f1b3b51704` | 157650 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_3.jpg` |
| `erheyuan_baitasi_4.jpg` | `68a75c30115ec1c59fa46e00486d3f371e09b5f5207ee7b469d93bb5fc584478` | 152152 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_4.jpg` |
| `erheyuan_baitasi_5.jpg` | `eb069d41a5e74c1e67f166b9db92cf6db0f116adf09c1e477bf3aad93ada2ba2` | 64670 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_5.jpg` |
| `erheyuan_baitasi_6.jpg` | `e5f55b488cb56c03c865e9266ab25f42c247082662ef38f0b13b4887c04e3378` | 159063 | 是 | `/workspace/landscape/courtyard/erheyuan_baitasi_6.jpg` |
