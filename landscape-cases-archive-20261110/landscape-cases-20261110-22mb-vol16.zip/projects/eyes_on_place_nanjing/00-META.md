# Eyes on Place（南京屋顶）

- 归档编号：`eyes_on_place_nanjing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch25`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `eyes_on_place_nanjing_1.jpg` | `c7bb869846b462756bc06e04697dd773609c7a2153197d4e18dadfff426877e9` | 432273 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_1.jpg` |
| `eyes_on_place_nanjing_10.jpg` | `a8e54a32f6067143caa0ca260c4869d7e187d0abcfe49efdb38841f9fae461d5` | 442204 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_10.jpg` |
| `eyes_on_place_nanjing_2.jpg` | `0815cc3d20f533686cd1ae6797b04d8e73922fa107c0b303746d4c4478f508b3` | 530931 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_2.jpg` |
| `eyes_on_place_nanjing_3.jpg` | `6f978658f8772175789234fdef5d90304828d9e4b8d9be5b180edc2657bcfe10` | 394583 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_3.jpg` |
| `eyes_on_place_nanjing_4.jpg` | `0f8d28fa16c1e178a0b9702f607812b171e2488d6ecf30ee6eb34d01487cd576` | 631732 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_4.jpg` |
| `eyes_on_place_nanjing_5.jpg` | `cf92894070e394de1d28f3b8e7a2cafbf19e8cb73f24d45a5e253f7893cb8216` | 488267 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_5.jpg` |
| `eyes_on_place_nanjing_6.jpg` | `1ea14fa30eaf61964f82a1cfd6f7706a6cb640a1cc08268a112af7a66ba57c44` | 388141 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_6.jpg` |
| `eyes_on_place_nanjing_7.jpg` | `f8e15c75cdde02c0f48efd587fca1b1a8ced85ddfc9a7ff5c1263abdf92b2351` | 446536 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_7.jpg` |
| `eyes_on_place_nanjing_8.jpg` | `8ab2a6cc13b31a43073e6e93d8e9316cba117bc8ac804aabc3e6fe8c928eade8` | 570281 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_8.jpg` |
| `eyes_on_place_nanjing_9.jpg` | `7d08ef2ee58685c5c4988183c83ee85da5b2439e5562ee8516bb8c19f94da6ee` | 449750 | 是 | `/workspace/landscape/batch25/eyes_on_place_nanjing_9.jpg` |
