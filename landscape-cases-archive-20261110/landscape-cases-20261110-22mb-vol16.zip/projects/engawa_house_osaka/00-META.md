# Engawa House（大阪，nLDK）

- 归档编号：`engawa_house_osaka`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch21`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `engawa_house_osaka_1.jpg` | `35c57e6e5a4dd96b3d182637ad0d1f68e409311c4775c9d4f0778d3b5bb2f21f` | 771181 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_1.jpg` |
| `engawa_house_osaka_10.jpg` | `0051ef355746c4c92da85b4c2808622fec536b25370e93c061bd43d7f7b9339a` | 152835 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_10.jpg` |
| `engawa_house_osaka_2.jpg` | `c8dbd527cbfd4ef374deac9d4bcab77a4b33cfe7f6590bcca76712a30cf12e36` | 685874 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_2.jpg` |
| `engawa_house_osaka_3.jpg` | `6e0c9107381b66124889c70ef3acd1e0e23a6a272d423261137c780f92779eb7` | 661720 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_3.jpg` |
| `engawa_house_osaka_4.jpg` | `59e8c4056fa33afd91a8db09c86650f8f14a00ef7c8caff1e3f7b8708f63f912` | 1060620 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_4.jpg` |
| `engawa_house_osaka_5.jpg` | `8cd5db2e0bb7827da26e93dd7188a93e6c47fbb744d860cd1d47c2fec59e2ae4` | 791243 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_5.jpg` |
| `engawa_house_osaka_6.jpg` | `1b2891c078d5622af3c12f2b69af4d2a23f6d295e9d038c898d724ba6504d889` | 923371 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_6.jpg` |
| `engawa_house_osaka_7.jpg` | `f3775c4b6f434cad5d9f07497b990f13cdd6cd74ec63fa1ecffc10555bbf8366` | 542521 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_7.jpg` |
| `engawa_house_osaka_8.jpg` | `16e072b59871c8fb56de25c203d526efb40b502993f67dec543136a2bd738d77` | 591057 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_8.jpg` |
| `engawa_house_osaka_9.jpg` | `1fa3693966b2ceb22a68cbe2b006a7f0648fa711d1ff9edc54bc1580df498787` | 605068 | 是 | `/workspace/landscape/batch21/engawa_house_osaka_9.jpg` |
