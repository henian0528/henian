# Peabody Plaza（纳什维尔）

- 归档编号：`peabody_plaza_nashville`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch30`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `peabody_plaza_nashville_1.jpg` | `877648d2a6c5b0f717c72107dd1aa95cea0c2e959bd5ca21a79311b13a1f969d` | 672093 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_1.jpg` |
| `peabody_plaza_nashville_2.jpg` | `0996b3687493f9df32eb03cffcdf1a076d4f54e7be88883bc434d3b3bede368e` | 709063 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_2.jpg` |
| `peabody_plaza_nashville_3.jpg` | `4b9589c74eb32ee5dc28e3e9f3a163b1bfa87848a0a4692b5e63e8e4b79c996e` | 625391 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_3.jpg` |
| `peabody_plaza_nashville_4.jpg` | `e0aaa9a7cee4ee2923dfa8f5f94f562c4229b9d06e5098da21afbc6559db5452` | 619023 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_4.jpg` |
| `peabody_plaza_nashville_5.jpg` | `f1d7c6f8a21cdffe511b206360e88d8b84338c51367396717bf568176c00a862` | 621153 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_5.jpg` |
| `peabody_plaza_nashville_6.jpg` | `77ae1e3e34d23fb0b8c7f312f348972bda77b1931c642fc24b07d73a0cffc42a` | 548851 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_6.jpg` |
| `peabody_plaza_nashville_7.jpg` | `f13391a4cdfbaf65e083474c8f691f8d4223776467db249f2c12d49767ad6eee` | 684117 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_7.jpg` |
| `peabody_plaza_nashville_8.jpg` | `3616a4274ba40fd04aa30c2bd5468e08f9c777f17f8779d65fd58ca56e1ad81f` | 589893 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_8.jpg` |
| `peabody_plaza_nashville_9.jpg` | `30c69b9cd6553e6567353739d2ead338ddb9590d00342f244d31496e7a5f623f` | 102134 | 是 | `/workspace/landscape/batch30/peabody_plaza_nashville_9.jpg` |
