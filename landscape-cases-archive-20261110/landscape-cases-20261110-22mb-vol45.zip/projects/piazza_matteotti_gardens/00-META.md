# 马特奥蒂广场公共花园（意大利，Pool）

- 归档编号：`piazza_matteotti_gardens`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch32`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `piazza_matteotti_gardens_1.jpg` | `cb90d0caa7216f822e0f39707b8de599ab2103bbafdfb03625bec1ee7ea8cc8e` | 1014991 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_1.jpg` |
| `piazza_matteotti_gardens_10.jpg` | `ed31a40d4c9f50391b2fa4f15b2100258998c8ee10a84ea39afb58ea4dbb62fc` | 404254 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_10.jpg` |
| `piazza_matteotti_gardens_2.jpg` | `bc5177330ec47a2f611c1c88533b878ae9c6a61f2170b4e617453d9e0c1d8a0e` | 744422 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_2.jpg` |
| `piazza_matteotti_gardens_3.jpg` | `60ce1eb81d85e2fcdea76785e6ad8960b58555e69dd8c4ef261199a14f22f982` | 1042244 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_3.jpg` |
| `piazza_matteotti_gardens_4.jpg` | `f49d76638fc6bd1edf84f839a67a8d027e42e7115e89ca5fb16059d57bf6aaeb` | 845142 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_4.jpg` |
| `piazza_matteotti_gardens_5.jpg` | `27310e211fc7a50a57e29c710a29702d8bc17cb771af1fe92df909e502757291` | 719663 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_5.jpg` |
| `piazza_matteotti_gardens_6.jpg` | `5160a8d8be385bc1f44b9031e4ec233d2b24d33c6bfd14c6d5454763a7383576` | 1010029 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_6.jpg` |
| `piazza_matteotti_gardens_7.jpg` | `852fd304c389e64f13ef0f90a1d2fe8abbe25fdee81f99f595c6e75705803693` | 972795 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_7.jpg` |
| `piazza_matteotti_gardens_8.jpg` | `071d94d37db949a559ffcc1b5d1b878f0f287f9dc061a5d52d52d92a2369242a` | 1083185 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_8.jpg` |
| `piazza_matteotti_gardens_9.jpg` | `3ad620735ef8a911b0783aa605dca3a57d2a6de1123645cec858a152ed3f2469` | 1001018 | 是 | `/workspace/landscape/batch32/piazza_matteotti_gardens_9.jpg` |
