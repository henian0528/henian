# 企鹅花园（深圳蛇口）

- 归档编号：`penguin_garden_shekou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：7
- 在 bot 附件库中匹配到的配图：7 / 7（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch25`
  - 本记录配图文件数：7

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `penguin_garden_shekou_1.jpg` | `db636467327313c35fb4bb2a751f7843f5d2cc89cf918dcff1958e18dcba7b3f` | 327099 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_1.jpg` |
| `penguin_garden_shekou_2.jpg` | `d30de8713b9744c2e15834d1fd891a20aca15f3523f649b19ed025512c8d166e` | 361688 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_2.jpg` |
| `penguin_garden_shekou_3.jpg` | `ce3010b69099a545a03aae6c0c4e1bcc81cbfcf491fddff4d511cd1d623f3d2b` | 146985 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_3.jpg` |
| `penguin_garden_shekou_4.jpg` | `18f15b16c10b7c985e5f7e4a87b422364e52c8aeaa62487fbe31e70e6a38dca6` | 204347 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_4.jpg` |
| `penguin_garden_shekou_5.jpg` | `011b37ac9612c8066d1f9f2675eae3f774bc7896b8aeb29366dce24a37ac99cd` | 383463 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_5.jpg` |
| `penguin_garden_shekou_6.jpg` | `71184951c32ceca1f5f7c51f3331c00e1e2891c8a974a68bd66f4f3801f109eb` | 315334 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_6.jpg` |
| `penguin_garden_shekou_7.jpg` | `def826c1e929ce7354e9b22d04efe14eacc582d94945c7e333627dcec1e4e76a` | 207445 | 是 | `/workspace/landscape/batch25/penguin_garden_shekou_7.jpg` |
