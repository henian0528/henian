# Piloti Bellevue（white2）

- 归档编号：`piloti_bellevue`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面续（white2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white2`
  - 注：来源 china-canopy-cases/white2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `piloti_bellevue_1.jpg` | `ca6a40ec49bb32df21c9a86c684e2d73b78476bba9afd0f96746093c72968e03` | 617425 | 是 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_1.jpg` |
| `piloti_bellevue_2.jpg` | `62108fa786f7f7fca69ebdb4dc57010809bdaa565134fb0eba39683ff5178191` | 600853 | 是 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_2.jpg` |
| `piloti_bellevue_3.jpg` | `70b36a687a5c5f49cd2aab25a7f0287a7720af3f8734dbeccd129d405a6a884c` | 636762 | 是 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_3.jpg` |
| `piloti_bellevue_4.jpg` | `1b7a92b3852b616ed7a7eface22b7f1d6b5ceaa76cb83476a5b1388c9cf153b9` | 487138 | 是 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_4.jpg` |
| `piloti_bellevue_5.jpg` | `fdcc49f22086ce23addbf838759172d39907b23448095d10f89d2260d1225b6b` | 515756 | 否 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_5.jpg` |
| `piloti_bellevue_6.jpg` | `750c73b4ce23da3f5f8c2462f09fb55bf629b3fc1b193bd173bb474318b8e9e6` | 468202 | 否 | `/workspace/landscape/china-canopy-cases/white2/piloti_bellevue_6.jpg` |
