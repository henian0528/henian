# Hook House（大阪羽曳野，ninkipen!）

- 归档编号：`hook_house_habikino`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch22`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hook_house_habikino_1.jpg` | `e9a386ad8133856f16225889f3b013cb92fa258bf17c1e8d18146e81ad664434` | 610773 | 是 | `/workspace/landscape/batch22/hook_house_habikino_1.jpg` |
| `hook_house_habikino_2.jpg` | `08e511b9ec3c30162f3dbeed89a05a96eb12ca4f7c102be5c11c90e8734ccec8` | 487766 | 是 | `/workspace/landscape/batch22/hook_house_habikino_2.jpg` |
| `hook_house_habikino_3.jpg` | `5ee440248c2c3a75bd33d4db99a1fcd6c2346817c11ca76a63888b2eabf3ac4a` | 505130 | 是 | `/workspace/landscape/batch22/hook_house_habikino_3.jpg` |
| `hook_house_habikino_4.jpg` | `f3096d22a40e62d18d13ab530bd630c9d278413ff8561cc0ea78297b3f022c1c` | 582248 | 是 | `/workspace/landscape/batch22/hook_house_habikino_4.jpg` |
| `hook_house_habikino_5.jpg` | `db49cb286568e27c578f14130796a5bf9c49e613d5f10e11e72cdd73a3f5729c` | 591044 | 是 | `/workspace/landscape/batch22/hook_house_habikino_5.jpg` |
| `hook_house_habikino_6.jpg` | `b4f5cc4bba1029b31ff5366d42b2a6ca22b0c1d85aab48c137c8eb039f6a6814` | 117192 | 是 | `/workspace/landscape/batch22/hook_house_habikino_6.jpg` |
