# House LW27（慕尼黑，batch18）

- 归档编号：`house_lw27_munich`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch18`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `house_lw27_munich_1.jpg` | `342ebfd7b9292b141fdfdf22247b5d5292454110593863d7b66d21a0ed2e1b04` | 884429 | 是 | `/workspace/landscape/batch18/house_lw27_munich_1.jpg` |
| `house_lw27_munich_10.jpg` | `f50d33340c4609713773b6e010288b0b34e20bf03b07ecc5e2587ec1e5c60764` | 436110 | 是 | `/workspace/landscape/batch18/house_lw27_munich_10.jpg` |
| `house_lw27_munich_2.jpg` | `f0b1962a8bd3a30355a1ffbf999f1e712e6b3e05a64be453dd5cc01db9cfd35a` | 558846 | 是 | `/workspace/landscape/batch18/house_lw27_munich_2.jpg` |
| `house_lw27_munich_3.jpg` | `a3904eadf5ae95e5fbf116e375c48e8c153880e16b899c83fb52b3c111133d8d` | 532196 | 是 | `/workspace/landscape/batch18/house_lw27_munich_3.jpg` |
| `house_lw27_munich_4.jpg` | `57746cbf2ffaf7842a619d21810c5020ebd56469c61d40b2f382ecc70ab3efb2` | 629672 | 是 | `/workspace/landscape/batch18/house_lw27_munich_4.jpg` |
| `house_lw27_munich_5.jpg` | `e1528ac80fb56fe7b6242f56927a78f1b923ed4c774e0617e1703903b569c7a3` | 665179 | 是 | `/workspace/landscape/batch18/house_lw27_munich_5.jpg` |
| `house_lw27_munich_6.jpg` | `64b10b1c77f7a3f5c7758abffbef4feca08c41fdf6b9b2243ab9b4f27b8c6d6d` | 522742 | 是 | `/workspace/landscape/batch18/house_lw27_munich_6.jpg` |
| `house_lw27_munich_7.jpg` | `ceb817876e840676d8e1c54dc0dc3f5a9181755b74a4cc2be178f7ee60ab0f02` | 400375 | 是 | `/workspace/landscape/batch18/house_lw27_munich_7.jpg` |
| `house_lw27_munich_8.jpg` | `aef1b0c3ad016a60a14417f845353da808bef61e65157f42530355bf68f0e202` | 551623 | 是 | `/workspace/landscape/batch18/house_lw27_munich_8.jpg` |
| `house_lw27_munich_9.jpg` | `a41716b28efd935bf1311aad14bcd3280aecc366cda412602ae455bb69b69789` | 345293 | 是 | `/workspace/landscape/batch18/house_lw27_munich_9.jpg` |
