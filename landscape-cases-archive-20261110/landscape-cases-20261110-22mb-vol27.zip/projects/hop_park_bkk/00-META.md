# Hop Park 天桥快闪花园（曼谷，Shma）

- 归档编号：`hop_park_bkk`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch14`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `hop_park_bkk_1.jpg` | `9041db1f5e56ebb9f4cc9dc45cf261c78e6bc21302beb3ca75819e40512c69f8` | 602095 | 是 | `/workspace/landscape/batch14/hop_park_bkk_1.jpg` |
| `hop_park_bkk_10.jpg` | `b438d88080bcc126314a1ad8cb8de2a218b628fc72843837ec3be3aa324195a9` | 303412 | 是 | `/workspace/landscape/batch14/hop_park_bkk_10.jpg` |
| `hop_park_bkk_2.jpg` | `9d106a9e821ef305d42eec28397b560197a2b7903c162b71bd4cd6911d6bc5be` | 417977 | 是 | `/workspace/landscape/batch14/hop_park_bkk_2.jpg` |
| `hop_park_bkk_3.jpg` | `8f570014db99ed96a7752200e6b99c52f929ed81c485ff74917637181fc98b41` | 452124 | 是 | `/workspace/landscape/batch14/hop_park_bkk_3.jpg` |
| `hop_park_bkk_4.jpg` | `70455fbe2bea5aa9e1f6e2d2625b05b3bb5f7694bfdce81985decfd9561fe32f` | 453346 | 是 | `/workspace/landscape/batch14/hop_park_bkk_4.jpg` |
| `hop_park_bkk_5.jpg` | `e266a14a7a2360aca9c684763de89c5b1931f087ad6c938b0561a0c2eb7c7125` | 390361 | 是 | `/workspace/landscape/batch14/hop_park_bkk_5.jpg` |
| `hop_park_bkk_6.jpg` | `086364cfe0d213d02cc9459203e06cdda3f6045eb9604eaafc06996da5e4cb2f` | 391140 | 是 | `/workspace/landscape/batch14/hop_park_bkk_6.jpg` |
| `hop_park_bkk_7.jpg` | `916051bb7b562f82f008993cd9337f8f87b03b3c8998f5358d950206e4d336ce` | 219507 | 是 | `/workspace/landscape/batch14/hop_park_bkk_7.jpg` |
| `hop_park_bkk_8.jpg` | `f20d1c9743bf10b6e16a2d7f5f3b94e100c82699cb94b4ca28b4e511909a4a69` | 389995 | 是 | `/workspace/landscape/batch14/hop_park_bkk_8.jpg` |
| `hop_park_bkk_9.jpg` | `bf1b1bec99b05f9ff50edc13277275137b6fc50700e4c5b292a7f0f3bf9bfead` | 402001 | 是 | `/workspace/landscape/batch14/hop_park_bkk_9.jpg` |
