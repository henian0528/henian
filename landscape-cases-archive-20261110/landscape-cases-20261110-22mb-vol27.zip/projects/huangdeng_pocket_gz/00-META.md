# 黄登口袋花园（广州，UPON）

- 归档编号：`huangdeng_pocket_gz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch27`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `huangdeng_pocket_gz_1.jpg` | `192a6ecb04be56dca22fa01d8c0d737294c82c8e1286b76f852e98a1fdbd07d5` | 777043 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_1.jpg` |
| `huangdeng_pocket_gz_10.jpg` | `4caef6226c4d63ccbaa477d7ed08a124a7853f83a26fc6fb7b50e9ada2a74794` | 269083 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_10.jpg` |
| `huangdeng_pocket_gz_2.jpg` | `69bea209196bdf73a93094682d74ff54b755d89ca9785d698ebb01d2e6a5106f` | 716707 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_2.jpg` |
| `huangdeng_pocket_gz_3.jpg` | `d9f63557633cbfa7d9e9fa62ca4213b03d57dc6f545fef6d552c374f46f3becc` | 708346 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_3.jpg` |
| `huangdeng_pocket_gz_4.jpg` | `f64099ce66d689394e7c7c9c6f360c5d9004e0bf4d353a9b059103007024e486` | 680820 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_4.jpg` |
| `huangdeng_pocket_gz_5.jpg` | `4435193ff869dc63806ede7af4558f18182cd80ad8067ea4fe46f22fa928926d` | 720725 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_5.jpg` |
| `huangdeng_pocket_gz_6.jpg` | `903cdb078a028e50812d3233b6d2d2934af571910616c942008612f2b62df655` | 653748 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_6.jpg` |
| `huangdeng_pocket_gz_7.jpg` | `2289eda6668d368648ebd0b4fbce1caae6bc4ef931dddf49a0e41bbefd52b06a` | 529786 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_7.jpg` |
| `huangdeng_pocket_gz_8.jpg` | `ecc490ae0bb5804516a50a7c7b6e3ca75e94e5833b7ab470f004f5118589b55c` | 476417 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_8.jpg` |
| `huangdeng_pocket_gz_9.jpg` | `ff40e99d199d6ef88cdad9dc912c2b002f18b78c4017d0fc49cfab8cc8a373c7` | 813289 | 是 | `/workspace/landscape/batch27/huangdeng_pocket_gz_9.jpg` |
