# House in Minami-Senri（大阪，FujiwaraMuro）

- 归档编号：`house_minami_senri`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch22`
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `house_minami_senri_1.jpg` | `a74720dcdb018275837f9cfb49a12f9e26c49aefb8cefc05524667159f8bd7a9` | 162739 | 是 | `/workspace/landscape/batch22/house_minami_senri_1.jpg` |
| `house_minami_senri_2.jpg` | `6f6e88f89deaf8a7d197a1259a720f460f4c7c9e4dbdff52b0fafd1af240c0c8` | 98798 | 是 | `/workspace/landscape/batch22/house_minami_senri_2.jpg` |
| `house_minami_senri_3.jpg` | `cff6d75503da09101c70cbd692109372a437dc5c9fb17182d5e69ca326ebd9e5` | 140742 | 是 | `/workspace/landscape/batch22/house_minami_senri_3.jpg` |
| `house_minami_senri_4.jpg` | `14b68d2ce2b66dd5dfe788c0f1ece5b091dc7a6d4e946a82838c3345aa7c56ce` | 109450 | 是 | `/workspace/landscape/batch22/house_minami_senri_4.jpg` |
| `house_minami_senri_5.jpg` | `98d7f60c63498bab05e94162a87b3a6b382b7bc6ce4eb6953b614d693e8be94e` | 50677 | 是 | `/workspace/landscape/batch22/house_minami_senri_5.jpg` |
| `house_minami_senri_6.jpg` | `f2cbde5c813b1adcbc00f7fafd6410a0de7eacee1b1b2a9e995635b96eb07042` | 21667 | 是 | `/workspace/landscape/batch22/house_minami_senri_6.jpg` |
