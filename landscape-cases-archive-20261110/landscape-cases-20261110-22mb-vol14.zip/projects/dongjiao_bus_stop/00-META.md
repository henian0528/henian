# 东角村乡村公交站（嵛山岛）

- 归档编号：`dongjiao_bus_stop`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch9`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `dongjiao_bus_stop_1.jpg` | `585bffc95ac3bdd63031d58e8b73d0b953390a20b683653a74a68e1e3f4ae729` | 172064 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_1.jpg` |
| `dongjiao_bus_stop_10.jpg` | `b8359434acd2beb6718ff426b67aa57b65826a720e7e27ee23bcc2c185878a88` | 44267 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_10.jpg` |
| `dongjiao_bus_stop_2.jpg` | `231e7bee7295d64f6d87aaa61f5b4c7a4eaba82d8ec80038d87d453f057c643e` | 178615 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_2.jpg` |
| `dongjiao_bus_stop_3.jpg` | `1c42c42dda1825013da861aa5e5450aef489702e5717d205c8bc528488e9e1fc` | 150074 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_3.jpg` |
| `dongjiao_bus_stop_4.jpg` | `39b24855eba96ec18dd8e9632bb9cb9af55a2555ebee32ddb27554d394aeaa35` | 241119 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_4.jpg` |
| `dongjiao_bus_stop_5.jpg` | `f9192206c2303cc5151026bb2accf8efa78d66fae8ef0dab625c60afd1c4f70e` | 169532 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_5.jpg` |
| `dongjiao_bus_stop_6.jpg` | `ad1503160d24c941086ac26afe7c860c1ece45e0991098ea2e7e6972bc94918f` | 184557 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_6.jpg` |
| `dongjiao_bus_stop_7.jpg` | `2c0060cf2c640b17d079fe2cd14d135a56e0d643c6b94f22effee5d8dbeb4ff5` | 138409 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_7.jpg` |
| `dongjiao_bus_stop_8.jpg` | `164c823402cd402ffdb871500fb35e47504162ace89b69c0809faba8e2fe3d93` | 149066 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_8.jpg` |
| `dongjiao_bus_stop_9.jpg` | `35fb371666ce382d8c3341a1ccc8a53631617ed47a1971296b61f7d00044270d` | 101222 | 是 | `/workspace/landscape/batch9/dongjiao_bus_stop_9.jpg` |
