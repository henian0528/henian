# 北杜伊斯堡景观公园（variety2 早期批次）

- 归档编号：`duisburg_nord`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `duisburg_nord_1.jpg` | `56892da9c698c5119033db959e801c074feeb99a0e8874a7f0ea4985b4ef58a6` | 489485 | 是 | `/workspace/landscape/variety2/duisburg_nord_1.jpg` |
| `duisburg_nord_2.jpg` | `8276c999f8323e56699487d4d0335a1666fbfdbff8a955ab15b00d0c3ee4d31a` | 884187 | 是 | `/workspace/landscape/variety2/duisburg_nord_2.jpg` |
| `duisburg_nord_3.jpg` | `97483fbdcdf17410ad69d22fa188af1408c2b488db3f72ff85c7fc85bfbed6dc` | 723811 | 是 | `/workspace/landscape/variety2/duisburg_nord_3.jpg` |
| `duisburg_nord_4.jpg` | `8ad15977a1849105a5a39f4a5999ba17a1439ff80b3aeca174431990414be125` | 219554 | 是 | `/workspace/landscape/variety2/duisburg_nord_4.jpg` |
| `duisburg_nord_5.jpg` | `2ed152b19d4e746269b6bc39c26b6d50a9e5ec3655b408955802486dade1fc53` | 550839 | 否 | `/workspace/landscape/variety2/duisburg_nord_5.jpg` |
| `duisburg_nord_6.jpg` | `adb10638195aeba78b5f1f27d92468e9a3cf29335c92fdfc40b2d6170108619b` | 566356 | 否 | `/workspace/landscape/variety2/duisburg_nord_6.jpg` |
