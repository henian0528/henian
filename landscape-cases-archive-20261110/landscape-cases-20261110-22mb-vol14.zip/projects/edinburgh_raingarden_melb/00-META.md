# Edinburgh Gardens Raingarden（墨尔本，GHD）

- 归档编号：`edinburgh_raingarden_melb`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch29`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `edinburgh_raingarden_melb_1.jpg` | `adc29be723803e9a15a466401d008ea3f4ea0523c3fc6808c125338c35f04aa3` | 326875 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_1.jpg` |
| `edinburgh_raingarden_melb_2.jpg` | `83975b97a8a4d745b8ce3481608be022dee85f703befcb6973156a42dd7d42b6` | 369791 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_2.jpg` |
| `edinburgh_raingarden_melb_3.jpg` | `b44d7c7e56ff035ff7ae1e6b8931b76b010d963b8919247b763837993435b988` | 288242 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_3.jpg` |
| `edinburgh_raingarden_melb_4.jpg` | `c5a3efe56535097be14718a133cf5288646aa092d488c19c13da27daf67aad1d` | 353087 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_4.jpg` |
| `edinburgh_raingarden_melb_5.jpg` | `452e296db38f19713a05c65f91bd9e80a26da413b13c881b0376ff12c2a30f01` | 150447 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_5.jpg` |
| `edinburgh_raingarden_melb_6.jpg` | `c542abb2dc87be7b684c900f8d4a42188b18b766c94b888182ea1b7ffa2d3d21` | 185876 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_6.jpg` |
| `edinburgh_raingarden_melb_7.jpg` | `eac2c5883a68c8f2678c86687f8e1998507b966d4c67c89ebea3002e04dd1db4` | 326807 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_7.jpg` |
| `edinburgh_raingarden_melb_8.jpg` | `ff294f059180a45f87c0a7b59bb2c9c004d8ba235b8002db495fd4f9a4ede88d` | 152340 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_8.jpg` |
| `edinburgh_raingarden_melb_9.jpg` | `f709c83b4f196ec29c5a6aa9e4567a8d10e4a00e5cb71491f3ef07e0b32767bc` | 73364 | 是 | `/workspace/landscape/batch29/edinburgh_raingarden_melb_9.jpg` |
