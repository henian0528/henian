# 东山少爷南广场（广州，哲迳）

- 归档编号：`dongshan_shaoye_square_guangzhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch32`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `dongshan_shaoye_square_guangzhou_1.jpg` | `31b4acd97493153d84bdea776fedb4eee52f3ad5e1a59d47423d46f9c1d20eeb` | 867744 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_1.jpg` |
| `dongshan_shaoye_square_guangzhou_10.jpg` | `5016ae89999f3a3c51e1a717979a1bc9cf97ca3496ada7bf4bfb3d374d028284` | 247119 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_10.jpg` |
| `dongshan_shaoye_square_guangzhou_2.jpg` | `cfcd64bc1582dbc83b2701d6e7cf4b725dbdff3509ba771235fa9bc747279147` | 1087039 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_2.jpg` |
| `dongshan_shaoye_square_guangzhou_3.jpg` | `1c90897d2bb571cf68b9250ec88d634c40f5fb6e197fbd8655109515f2f37278` | 1041798 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_3.jpg` |
| `dongshan_shaoye_square_guangzhou_4.jpg` | `5ca0d4c3db50ab0f064f05e79666980c64d844401e3bc57c7cf2ac49b875cc33` | 901896 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_4.jpg` |
| `dongshan_shaoye_square_guangzhou_5.jpg` | `057df2683e50b360bd3d5b00bac0e2b9e23c1d0319c3351453f0dba3c14e2985` | 998637 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_5.jpg` |
| `dongshan_shaoye_square_guangzhou_6.jpg` | `4de5e5681455498016ed0b9e9e24431119799495a8665bb564dfdf40dbecc028` | 1360788 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_6.jpg` |
| `dongshan_shaoye_square_guangzhou_7.jpg` | `252d49da583d7c08e79b495e201c899a5f4d7460c03060f872765b8352c218a5` | 940777 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_7.jpg` |
| `dongshan_shaoye_square_guangzhou_8.jpg` | `c3ca73f200fd70024741782a243cb76d41add84df553b1b001d55c295f4eebae` | 1150418 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_8.jpg` |
| `dongshan_shaoye_square_guangzhou_9.jpg` | `28a907e26c470387881a4d8a1a1805b9ccf2c8e82acb327a29cdc9ba877920b3` | 650946 | 是 | `/workspace/landscape/batch32/dongshan_shaoye_square_guangzhou_9.jpg` |
