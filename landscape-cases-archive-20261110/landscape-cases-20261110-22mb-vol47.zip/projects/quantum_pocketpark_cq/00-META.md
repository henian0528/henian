# 高新量子口袋公园（重庆，10Design）

- 归档编号：`quantum_pocketpark_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `quantum_pocketpark_cq_1.jpg` | `89847d2b15d2ab7a7ff0ad8759b7d3180b88979ed4e9f6a16451bc75b9663902` | 285661 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_1.jpg` |
| `quantum_pocketpark_cq_10.jpg` | `65bebdca24aadd710972834b053c6189a19cb78dbb35e8f6786eeb12947c417b` | 101858 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_10.jpg` |
| `quantum_pocketpark_cq_2.jpg` | `94e47cd385dd98f01c8be6e6e3fae6e143bc5e90e83f0c55709c3fddc39c2dcf` | 259285 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_2.jpg` |
| `quantum_pocketpark_cq_3.jpg` | `86e1b81c3814780a8d8bf3d6618a0ee248c0b98f2bfe892455cf41ce185f37f4` | 213171 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_3.jpg` |
| `quantum_pocketpark_cq_4.jpg` | `b14d1e5adeceecab8f04ab8b1f803a423fc71962a9fa518684cfdb31c1463405` | 228165 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_4.jpg` |
| `quantum_pocketpark_cq_5.jpg` | `b9f6a2fab82a9e88bb1d3f1fc5b5f10960100a7c787563d632a56c4fd940db6f` | 249605 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_5.jpg` |
| `quantum_pocketpark_cq_6.jpg` | `e46d8e022a58620fb8bb332a35c784822c7dbf9a2f89999dac0407df75e14092` | 238822 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_6.jpg` |
| `quantum_pocketpark_cq_7.jpg` | `f71e3ee807141c3eb3110d931e8268762e053ca16d65871d303440ab1f546504` | 259814 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_7.jpg` |
| `quantum_pocketpark_cq_8.jpg` | `334e2b7fb5afc9f047a9697fe999947fcdebe967543ccfb9d5e2f9e7b8895e3e` | 176522 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_8.jpg` |
| `quantum_pocketpark_cq_9.jpg` | `00fd72d0ce86f98bdacc825557819c9fad2c3a702aef909c6bbba36ec1e7462c` | 228879 | 是 | `/workspace/landscape/batch12/quantum_pocketpark_cq_9.jpg` |
