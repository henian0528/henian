# 歧江公园（variety2 早期批次）

- 归档编号：`qijiang_park`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·工业遗产/纪念/稻田等（目录 variety2）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/variety2`
  - 注：来源 variety2
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `qijiang_park_1.jpg` | `d6432ac9522738083cb3a8a5d4239694f056e62cf8956e1dd78c120adb6bed8e` | 331619 | 是 | `/workspace/landscape/variety2/qijiang_park_1.jpg` |
| `qijiang_park_2.jpg` | `23adb4dfbf8c57ccf900ef4fac22a0078f000413d80edafb628509df4955a1e9` | 195627 | 是 | `/workspace/landscape/variety2/qijiang_park_2.jpg` |
| `qijiang_park_3.jpg` | `b986306267b7941e6b6e0649f6d82bc0b19e6db0e24a7651014df737f3df720b` | 342572 | 是 | `/workspace/landscape/variety2/qijiang_park_3.jpg` |
| `qijiang_park_4.jpg` | `58a8ccaade920608911078388dd98d07a2c06968888c0dd029b2e29ca9cbc906` | 257233 | 是 | `/workspace/landscape/variety2/qijiang_park_4.jpg` |
| `qijiang_park_5.jpg` | `6d6a5e9841bc6f11859baf7d345a070d742c77c81dd2eb0222de43d249cb6e23` | 324338 | 否 | `/workspace/landscape/variety2/qijiang_park_5.jpg` |
| `qijiang_park_6.jpg` | `367858b3caf3dc1c80a35cd30a1d0b9e584ae2764a82fde672eceac9ffe86e88` | 150828 | 否 | `/workspace/landscape/variety2/qijiang_park_6.jpg` |
