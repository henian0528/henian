# QH Straight Urban Jungle（柏林）

- 归档编号：`qh_urban_jungle_berlin`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch28`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `qh_urban_jungle_berlin_1.jpg` | `dcd8be1d5861f2d7e052b1366608598a0e7b7e8633de0a76dd6721194c4990c2` | 551148 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_1.jpg` |
| `qh_urban_jungle_berlin_10.jpg` | `b8d930529e3e00c3d4d79454f39645234a9fa105feeeb3bc15300c7a483ec461` | 234738 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_10.jpg` |
| `qh_urban_jungle_berlin_2.jpg` | `5d0eccd0be37e9cdf8e87869609c8d696df1465bc6b51ea034ade4371535df91` | 727222 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_2.jpg` |
| `qh_urban_jungle_berlin_3.jpg` | `07301718c634f4f0e3ee3de265c755021ea3efca128aeb1777e132814fed43f3` | 659505 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_3.jpg` |
| `qh_urban_jungle_berlin_4.jpg` | `70bf721f2872e80255d47d6b02106d0041b9b5dccdd3987404e1e31a29d7d8ab` | 749137 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_4.jpg` |
| `qh_urban_jungle_berlin_5.jpg` | `3e13ca6e380083b66ffad87c0a5c3521fe8bc3c682250787924f12e2741f851f` | 631469 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_5.jpg` |
| `qh_urban_jungle_berlin_6.jpg` | `67598bef708dd11dd27a82d0e916a0c1adfb3117a84cfc41722bc5c612dcd623` | 475029 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_6.jpg` |
| `qh_urban_jungle_berlin_7.jpg` | `63257062e3c6a10d0acfac1ee02237761391f95fe3527b5511038230dfebc885` | 471549 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_7.jpg` |
| `qh_urban_jungle_berlin_8.jpg` | `93280c9a7c3cf8d000c8b7d03bc249407747fc19c41274435d7c562eec923216` | 634157 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_8.jpg` |
| `qh_urban_jungle_berlin_9.jpg` | `6dce8237e3c17c52d779fe3d1af824a41f3afbfacbf51e3a5396883493b75fa9` | 438992 | 是 | `/workspace/landscape/batch28/qh_urban_jungle_berlin_9.jpg` |
