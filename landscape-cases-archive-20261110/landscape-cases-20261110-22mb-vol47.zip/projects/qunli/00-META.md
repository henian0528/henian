# 哈尔滨群力国家城市湿地公园

- 归档编号：`qunli`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：6 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-05
  - 出处说明：群聊工作日日推（期刊：已准备/已推送群力湿地）
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/2026-10-05`
  - 注：精选配图在日期目录根下
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `qunli_1.jpg` | `b685a0a7d93f59a1a20c9bf44738a325478618dac35185488b2ff734acbbc025` | 660655 | 是 | `/workspace/landscape/2026-10-05/qunli_1.jpg` |
| `qunli_2.jpg` | `781f6d77d48c7c6485da90db32d57cf8597a5db6968687631e56e3dc18510c02` | 532596 | 是 | `/workspace/landscape/2026-10-05/qunli_2.jpg` |
| `qunli_3.jpg` | `f01ec463728f52bc23348c759574ec8a762d8c130b92448d42dac6a059ed1b6f` | 282262 | 是 | `/workspace/landscape/2026-10-05/qunli_3.jpg` |
| `qunli_4.jpg` | `05c79a8ebf875c6e8ccd0bdc39dec673b52b212ed88b06a86af54f78e4be2488` | 401667 | 是 | `/workspace/landscape/2026-10-05/qunli_4.jpg` |
| `qunli_5.jpg` | `c80484bb5c759090d1428062b4eea1d7e9ee15536e44188cc3d0479b55c84b67` | 538133 | 是 | `/workspace/landscape/2026-10-05/qunli_5.jpg` |
| `qunli_6.jpg` | `bc98c659e7fbaea6bd225d91cee0e32f17cfc8f3adab9ab397448ba61412786b` | 385549 | 是 | `/workspace/landscape/2026-10-05/qunli_6.jpg` |
