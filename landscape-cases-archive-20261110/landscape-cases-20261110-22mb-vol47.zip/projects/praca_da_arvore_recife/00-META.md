# Praça da Árvore（累西腓）

- 归档编号：`praca_da_arvore_recife`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch30`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `praca_da_arvore_recife_1.jpg` | `f71b8c0d87777ed87f56638d848061eb4caedd64d00260ad6730ee086cd95eca` | 996954 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_1.jpg` |
| `praca_da_arvore_recife_2.jpg` | `aad08fb578c7ce30564ee2be136076157755a8c55e56fb7f8506bb8b7ddc48e5` | 948393 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_2.jpg` |
| `praca_da_arvore_recife_3.jpg` | `a11ee96abd3c43317cc722fc4207640606e187e7ee5464835060c652e8f3dfa1` | 657480 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_3.jpg` |
| `praca_da_arvore_recife_4.jpg` | `081a00628349831f84ab865a9034e0ea0b4d1f8f6fbf314d377b98b295977324` | 824612 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_4.jpg` |
| `praca_da_arvore_recife_5.jpg` | `7b873dc0173c64a79249ecd2e7e9b2d6786013927a9c7fa8f4f3c447eacca954` | 738819 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_5.jpg` |
| `praca_da_arvore_recife_6.jpg` | `c391dbd850d0581d593c7fdcd3209dfca7070e18279e43afc4f2a36686c11b01` | 757238 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_6.jpg` |
| `praca_da_arvore_recife_7.jpg` | `da705b1557225bf6b469579ca9ead6cbbea6b8c960dd2dbf471de8d742e07575` | 876051 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_7.jpg` |
| `praca_da_arvore_recife_8.jpg` | `379ad9b2304fa03af8e1c2da1506f5689a36bd6cf67d83a798a0d1ad652518f1` | 297999 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_8.jpg` |
| `praca_da_arvore_recife_9.jpg` | `52a01a668214b6a85ea604bdfbd1fd35fc0c5b2d6393306be8af823ce982653e` | 157238 | 是 | `/workspace/landscape/batch30/praca_da_arvore_recife_9.jpg` |
