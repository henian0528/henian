# 暖亭（浦东向东社区之家，VIA）

- 归档编号：`nuanting_pavilion`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch11`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `nuanting_pavilion_1.jpg` | `d0b4622b0039130feb5d1d6edec4e7627a56cbb24b3203541ab2e4be43d8eb90` | 503033 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_1.jpg` |
| `nuanting_pavilion_10.jpg` | `00e72ca5a6917db98051a7f1e65eae88f9e3900282f47fa3e7b68de76dbe865a` | 234267 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_10.jpg` |
| `nuanting_pavilion_2.jpg` | `15984e926cef39b1b68a9f8c2874ddafc23ae3255b7bf5ff8926cd4b1067b5df` | 234006 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_2.jpg` |
| `nuanting_pavilion_3.jpg` | `9766fdea0684054ce68e7e0ad6b1335ce74701c1134e067dbda0539f9d9de3c1` | 462743 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_3.jpg` |
| `nuanting_pavilion_4.jpg` | `942575a4a7a5342ced5d83c7f6ff9807ecca3d64f12498f437943b2fe8fbbdbd` | 191094 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_4.jpg` |
| `nuanting_pavilion_5.jpg` | `15dd74dc4c39f2f5ae249e80cc7445a0dd95bdc94c09b0c1deb6ad2055a744a7` | 191854 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_5.jpg` |
| `nuanting_pavilion_6.jpg` | `6e6bf160c8672617300536df0b22cc8f4014cbd752808a6b8e4fc1b5d4c8ff6f` | 156161 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_6.jpg` |
| `nuanting_pavilion_7.jpg` | `13f01132d9bb7fec316dd68e915cbcac0afae12f4050affee30fb434e97e18e7` | 155579 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_7.jpg` |
| `nuanting_pavilion_8.jpg` | `ce2a4cac65a52a3309878b871a79cd41bbbd9d095ed9097fd7be546a39db7962` | 234014 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_8.jpg` |
| `nuanting_pavilion_9.jpg` | `6280aa82f794f4ba039f0b185c1f3f21f612939ebab4b853870b88accf45f07f` | 153356 | 是 | `/workspace/landscape/batch11/nuanting_pavilion_9.jpg` |
