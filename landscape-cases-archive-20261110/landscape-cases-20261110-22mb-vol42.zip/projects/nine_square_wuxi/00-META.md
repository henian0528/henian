# 无锡渤公岛「九宫亭」（非常建筑·张永和）

- 归档编号：`nine_square_wuxi`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：29
- 在 bot 附件库中匹配到的配图：20 / 29（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-27
  - 出处说明：日期目录 2026-10-27（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/2026-10-27/nine_square_wuxi`
  - 注：项目子目录精选图
  - 本记录配图文件数：29

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `ns_002.jpg` | `dd4df4bae02d9fcb10f82f38890543aafd5d9ece0a918ae9c9fe5b1ef89ad283` | 570320 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_002.jpg` |
| `ns_004.jpg` | `1e11fcee67f4ccd6f4eae1c5d3132bc2e579f509f9973bc1dc25f352e788ad00` | 914179 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_004.jpg` |
| `ns_006.jpg` | `14468971ae3d0feca1e3e9a6ec847c6496d379df70bd192441e68b2a31cc4893` | 677925 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_006.jpg` |
| `ns_008.jpg` | `d62545dff1bb32429cd63a95c280b63ab8fdc8ce17da2fdca1ad210cb3045858` | 809240 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_008.jpg` |
| `ns_010.jpg` | `49e552984196f55c877fb9e71d1f1b710f1c5258b8114cc0cb43afb6be2c06f6` | 754174 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_010.jpg` |
| `ns_012.jpg` | `f0cfa3100acef614edcd7d0bbb90917173d2ebe01ff83767fde266814fcbac8f` | 694367 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_012.jpg` |
| `ns_014.jpg` | `c40d106600b5081c740ee870d180be1f5cd74bd9cea6c3e46c9594a8f7b31a47` | 472867 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_014.jpg` |
| `ns_015.jpg` | `38f1c15eda3f998737baa1f1b89b259ea8bbf21bbf396bc155a343621501e780` | 469701 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_015.jpg` |
| `ns_016.jpg` | `6d8049f412d2765ce02f1568251139848b8257647aa5bfbbbce72e50e029061d` | 461784 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_016.jpg` |
| `ns_017.jpg` | `3a17a330cb327972ea567de46af845c31c9841b25f77488067fe4d7c1dea4e6c` | 504060 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_017.jpg` |
| `ns_018.jpg` | `613c421da5013a791c2be4e8bbb6c88092f4be2b783aa7dd5e0b3609dece4cd7` | 416755 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_018.jpg` |
| `ns_019.jpg` | `fa8641ed8001c582851b7b2ff8989d50b78b680ae915aef1ba046b66c155ec45` | 458105 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_019.jpg` |
| `ns_01_photo.jpg` | `dd4df4bae02d9fcb10f82f38890543aafd5d9ece0a918ae9c9fe5b1ef89ad283` | 570320 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_01_photo.jpg` |
| `ns_020.jpg` | `c2a6e08c1500b6ff9d829d82dca994c93ea1e58ff6ac1d3e32e8e0ce8dd673d8` | 561342 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_020.jpg` |
| `ns_021.jpg` | `3e16a8302b0f30913c14bc62be519fdb54cb32a5bb66963057785cc35c99d64f` | 313015 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_021.jpg` |
| `ns_022.jpg` | `7f76911a3d6476c6f86111d964c31072e26c8129ae5d41f66fefa17f129b0d22` | 196253 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_022.jpg` |
| `ns_023.jpg` | `d83c3050042fb70f87fe76c441f0890606942a13006a2e80a244e85a9bdaeff7` | 106559 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_023.jpg` |
| `ns_024.jpg` | `e84c26a643f605004675c7417246a547b18dec34342594ae91b0d2c4de71f57b` | 211491 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_024.jpg` |
| `ns_025.jpg` | `b65bd37df0b0be047e694f5beabdc594cf77dceb3560911f57236cfd4ab3dee4` | 402728 | 否 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_025.jpg` |
| `ns_026.jpg` | `0acb271cd3783165445a59396ba205b3eac60a30c1c04b3146bb6c8f2351fc24` | 227691 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_026.jpg` |
| `ns_02_photo.jpg` | `1e11fcee67f4ccd6f4eae1c5d3132bc2e579f509f9973bc1dc25f352e788ad00` | 914179 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_02_photo.jpg` |
| `ns_03_photo.jpg` | `14468971ae3d0feca1e3e9a6ec847c6496d379df70bd192441e68b2a31cc4893` | 677925 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_03_photo.jpg` |
| `ns_04_photo.jpg` | `d62545dff1bb32429cd63a95c280b63ab8fdc8ce17da2fdca1ad210cb3045858` | 809240 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_04_photo.jpg` |
| `ns_05_photo.jpg` | `49e552984196f55c877fb9e71d1f1b710f1c5258b8114cc0cb43afb6be2c06f6` | 754174 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_05_photo.jpg` |
| `ns_06_photo.jpg` | `f0cfa3100acef614edcd7d0bbb90917173d2ebe01ff83767fde266814fcbac8f` | 694367 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_06_photo.jpg` |
| `ns_07_photo.jpg` | `3a17a330cb327972ea567de46af845c31c9841b25f77488067fe4d7c1dea4e6c` | 504060 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_07_photo.jpg` |
| `ns_08_drawing_site_plan.jpg` | `0acb271cd3783165445a59396ba205b3eac60a30c1c04b3146bb6c8f2351fc24` | 227691 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_08_drawing_site_plan.jpg` |
| `ns_09_drawing_plan_elev.jpg` | `7f76911a3d6476c6f86111d964c31072e26c8129ae5d41f66fefa17f129b0d22` | 196253 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_09_drawing_plan_elev.jpg` |
| `ns_10_drawing_roof_ceiling.jpg` | `d83c3050042fb70f87fe76c441f0890606942a13006a2e80a244e85a9bdaeff7` | 106559 | 是 | `/workspace/landscape/2026-10-27/nine_square_wuxi/ns_10_drawing_roof_ceiling.jpg` |
