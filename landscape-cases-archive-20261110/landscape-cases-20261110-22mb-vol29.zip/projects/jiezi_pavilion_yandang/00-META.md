# 芥子亭（雁荡山）

- 归档编号：`jiezi_pavilion_yandang`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `jiezi_pavilion_yandang_1.jpg` | `b3aeea9d4877a21335f59ea5d86abbeed637f05691309806b91286ee7a2f13cf` | 323051 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_1.jpg` |
| `jiezi_pavilion_yandang_10.jpg` | `e89eb8209c73a5ea15cbd4eb36edc781fbaaffdcd85450ff97b2fe54f59ab5bb` | 91989 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_10.jpg` |
| `jiezi_pavilion_yandang_2.jpg` | `c78d6ca475d94a0c6de3531d83ef9dc3f4a4bbaaa8d346ea6f3ff40934974d31` | 229162 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_2.jpg` |
| `jiezi_pavilion_yandang_3.jpg` | `3bddeb5d4c575d2f245b4c51c6a68a64cc8a3277ec15e3907eb834e08d73603d` | 448286 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_3.jpg` |
| `jiezi_pavilion_yandang_4.jpg` | `901dff6cacff140a106b2aa871097b34a108b523199ce6b1f442b8300cb47cf4` | 490375 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_4.jpg` |
| `jiezi_pavilion_yandang_5.jpg` | `f32fdae00061a6e4d964dcc7740fd463bb4eb9e626e197fe7b66041ca49621c1` | 463222 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_5.jpg` |
| `jiezi_pavilion_yandang_6.jpg` | `8e4ca5b9d9fa508461175bbcb16cfb170b944f46f38d21167357f21a5c026bdf` | 200766 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_6.jpg` |
| `jiezi_pavilion_yandang_7.jpg` | `f3f5dde47214a954dcd310be44c5c6a8a2a1a73c1153f974fbec22585e445f8e` | 218746 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_7.jpg` |
| `jiezi_pavilion_yandang_8.jpg` | `9dcd33d2ee2fb908bf8f569a150016739085b78cff95627eb7f8fcef3eb12d8e` | 144233 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_8.jpg` |
| `jiezi_pavilion_yandang_9.jpg` | `145e64062ed8af10423a1ef0a752515b31d437a1befb41253490fdd968eb6f54` | 251549 | 是 | `/workspace/landscape/batch8/jiezi_pavilion_yandang_9.jpg` |
