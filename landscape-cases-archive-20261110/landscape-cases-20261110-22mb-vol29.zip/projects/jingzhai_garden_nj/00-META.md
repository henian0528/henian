# 静宅庭院（南京，boll是园）

- 归档编号：`jingzhai_garden_nj`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch20`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `jingzhai_garden_nj_1.jpg` | `249bd72d5e3de112e127d727aa5fc9bc75acf835fcdeb985174612cecf2bd52e` | 797949 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_1.jpg` |
| `jingzhai_garden_nj_10.jpg` | `bc4cd29e00e5af4b81943383240efd26b50452325f9b8f549cf56485ac0f6ac7` | 134892 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_10.jpg` |
| `jingzhai_garden_nj_2.jpg` | `402b6edd8c15fd3f269644623f336a523a74c107d24358f9c5d28b5cde3449a3` | 719581 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_2.jpg` |
| `jingzhai_garden_nj_3.jpg` | `7f7f1ca83681480f8e923371379de444683477f35ded57f994e9edb06cf3a225` | 839059 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_3.jpg` |
| `jingzhai_garden_nj_4.jpg` | `17e4b009e39a470039687e7c121a6255474a86fa18d20f1a5b32c718ac915008` | 702464 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_4.jpg` |
| `jingzhai_garden_nj_5.jpg` | `5157d0a9edafd1f3e7cb6f7722955ddd9e620cbd8a66c9ed8e0eae1e43063cee` | 796802 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_5.jpg` |
| `jingzhai_garden_nj_6.jpg` | `cc586e0cccd56c4323c9203ae6c0266e64c32c486a9b2d565d37f7153b33d19d` | 373761 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_6.jpg` |
| `jingzhai_garden_nj_7.jpg` | `3554cb2bfdf2d827fce515a09e53c0a2fd5d692aae73c7e30bb766585f2936bd` | 450093 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_7.jpg` |
| `jingzhai_garden_nj_8.jpg` | `17288e184cc727b8cce80018913742baacf545e0fc35bc72af417631d77546a3` | 636487 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_8.jpg` |
| `jingzhai_garden_nj_9.jpg` | `ea88692ee56b65483d0db037d59a38d7a52c4f2af00fe595c20ef45ab5c21272` | 470576 | 是 | `/workspace/landscape/batch20/jingzhai_garden_nj_9.jpg` |
