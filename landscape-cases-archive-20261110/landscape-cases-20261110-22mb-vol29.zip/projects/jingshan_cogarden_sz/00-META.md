# 鲸山别墅社区共建花园（深圳）

- 归档编号：`jingshan_cogarden_sz`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch12`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `jingshan_cogarden_sz_1.jpg` | `7add72489b2f007955136a72083b75c5098bcd49a34032136c11b21e5278e28d` | 292009 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_1.jpg` |
| `jingshan_cogarden_sz_10.jpg` | `25daa69144bc2f081736c22e777bafb8174766b77a1cf203116416776b00657f` | 265444 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_10.jpg` |
| `jingshan_cogarden_sz_2.jpg` | `1dcf6ea6d9ce0317cf5decd32a1ef9d60c884be1e759e00a538b15ddd8685116` | 327942 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_2.jpg` |
| `jingshan_cogarden_sz_3.jpg` | `03bddfbce6dd02939a3be4767e8ceab4d076e09e60809dead10d5e1c877f65c6` | 254895 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_3.jpg` |
| `jingshan_cogarden_sz_4.jpg` | `3b047c2ce05633553a8a88d93e6a9a792fb519ef05156f50a2fd098f93177a90` | 251302 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_4.jpg` |
| `jingshan_cogarden_sz_5.jpg` | `c02855bd27cbacbebd01c4b1586c157b4a8cad6ab35391f62debfede8deccb7a` | 257740 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_5.jpg` |
| `jingshan_cogarden_sz_6.jpg` | `ac16e93844545d7704756095bea8f5a8617aa1fd40481589b4284ca0776be090` | 286672 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_6.jpg` |
| `jingshan_cogarden_sz_7.jpg` | `e39de2233ac6c79ddac40398f71b092d55c3cc3b40576a44c80349b8e8c15ddd` | 239295 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_7.jpg` |
| `jingshan_cogarden_sz_8.jpg` | `9b1b7562e8903c7e268f0992bf47a1f0afd070331698194319f4d808e4ade7f6` | 205783 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_8.jpg` |
| `jingshan_cogarden_sz_9.jpg` | `c983f5e26623bda06408b92d5dac51a308093d65a0d5ddc2624322a96c1cf8d9` | 307245 | 是 | `/workspace/landscape/batch12/jingshan_cogarden_sz_9.jpg` |
