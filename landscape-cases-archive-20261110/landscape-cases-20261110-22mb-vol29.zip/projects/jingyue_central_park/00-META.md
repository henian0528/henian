# 长春净月中央公园（水石设计）

- 归档编号：`jingyue_central_park`
- 推荐状态（汇总）：`sent`
- 显示名来源：当时发出原文标题
- 精选配图张数（去向前）：6
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无

## 出现记录（不改写）

- 日期/标记：2026-10-03
  - 出处说明：private + 群补发（SendToUser 已确认）
  - 发送判断：`sent`
  - 本地来源：`/workspace/cases/today`（文件名与净月内容相符；mtime 为 2026-11-10，路径曾为每日复用目录，收录时按现有文件核对）
  - 本记录配图文件数：6
