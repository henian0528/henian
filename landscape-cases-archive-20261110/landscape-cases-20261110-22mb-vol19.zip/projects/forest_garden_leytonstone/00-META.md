# Forest Garden（伦敦 Leytonstone，HÛT）

- 归档编号：`forest_garden_leytonstone`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-13
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch25`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `forest_garden_leytonstone_1.jpg` | `b4e05709a6038e434765da074d05588e1b8394444b73fba5875ddd8877c241db` | 797000 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_1.jpg` |
| `forest_garden_leytonstone_10.jpg` | `ec3a67173f71f0b416797e73f5c57a972abb0c3965329277257c7908842236d2` | 162957 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_10.jpg` |
| `forest_garden_leytonstone_2.jpg` | `9ba18a6b33dfdbc81104e5436c301dff23bea3a6aceea782d5c1f120e2c7ba02` | 703753 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_2.jpg` |
| `forest_garden_leytonstone_3.jpg` | `4e8d1b89bf56fd289e3907e149894cb2e0c6f8bbee9fabdb012fde492da55405` | 348372 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_3.jpg` |
| `forest_garden_leytonstone_4.jpg` | `5deb56a128a2daa394fd13ecfe4c437e12ca90965599ebce8a28d8d375b5043a` | 848043 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_4.jpg` |
| `forest_garden_leytonstone_5.jpg` | `63d057fef53d697649bab9272301171f6672a54b935d1c9af9616937881b2ae6` | 507244 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_5.jpg` |
| `forest_garden_leytonstone_6.jpg` | `61b6dedb7dbf688198f102ba6dbc965624bb20e3e097577b3292217ac08314f4` | 459015 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_6.jpg` |
| `forest_garden_leytonstone_7.jpg` | `ed48519abfb42b0d24790a956ad7bd6831f2a985061e85a2df9f4255b3f95a6d` | 439249 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_7.jpg` |
| `forest_garden_leytonstone_8.jpg` | `efadaa7d90dd9b30f60f53a1b787a024d1d2db05c7ad72455e1337671fa13692` | 440786 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_8.jpg` |
| `forest_garden_leytonstone_9.jpg` | `e22b8cc0f312cedce4982a68a012747977928d68a70f7a0958b8bf40ac61dac3` | 137730 | 是 | `/workspace/landscape/batch25/forest_garden_leytonstone_9.jpg` |
