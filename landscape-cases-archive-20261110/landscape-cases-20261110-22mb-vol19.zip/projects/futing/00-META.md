# 浮亭相关（white；与茶山浮亭可能为同一方向）

- 归档编号：`futing`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·白色轻薄屋面（white，含 Westmoreland、浮亭方向）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/china-canopy-cases/white`
  - 注：来源 china-canopy-cases/white
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `futing_1.jpg` | `051b7ba6244faa223ae8b68bf32a0406830c9163049b8fc8faf602756224a817` | 156984 | 是 | `/workspace/landscape/china-canopy-cases/white/futing_1.jpg` |
| `futing_2.jpg` | `433340db618896802a49a0d8a5d71288e928d6f1ae2fd8f73bcb1fb678e00d5e` | 124389 | 是 | `/workspace/landscape/china-canopy-cases/white/futing_2.jpg` |
| `futing_3.jpg` | `6683a5eab9b27b59b765150135d2626488dbb2ec4d68dc4c0693b56337064369` | 287034 | 否 | `/workspace/landscape/china-canopy-cases/white/futing_3.jpg` |
| `futing_4.jpg` | `b63dd33ab562f24139ae77b9008ff15b080a2611929dd45b6a3cd1cae972a7af` | 134246 | 否 | `/workspace/landscape/china-canopy-cases/white/futing_4.jpg` |
| `futing_5.jpg` | `b21b787d9e75321bd4a45c924f601a3366036c172da8599397a97c72e44f7bf4` | 105579 | 是 | `/workspace/landscape/china-canopy-cases/white/futing_5.jpg` |
| `futing_6.jpg` | `88f79d97b4589914750a42285abf64881f98a4d51b7a39b7a950490d5ade2b88` | 119301 | 是 | `/workspace/landscape/china-canopy-cases/white/futing_6.jpg` |
