# 灯笼花园（成都，batch15）

- 归档编号：`lantern_garden_cd`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-09
  - 出处说明：private_batch
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/batch15`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `lantern_garden_cd_1.jpg` | `fef9754a39a8ab1fae146025da46f5e3160ab99ade2b9bdaf3d02f58242420d2` | 256223 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_1.jpg` |
| `lantern_garden_cd_10.jpg` | `6d06386fac4c3e7d3cf07a522cc0d74ac0d2d018672c62910d17068e63b2840c` | 270190 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_10.jpg` |
| `lantern_garden_cd_2.jpg` | `487e1b2aecc571e31d633061882a175280724cb61ffc872c91344b3d7dee74e8` | 313909 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_2.jpg` |
| `lantern_garden_cd_3.jpg` | `bccf64cbcea580f81d9de0eb073b33a01dcad4142e161762496fcc509eeb1b89` | 488064 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_3.jpg` |
| `lantern_garden_cd_4.jpg` | `61918eb37add819f7571f080ed1620305eec5cb56d4d60e3d32cc2543a29bf32` | 450891 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_4.jpg` |
| `lantern_garden_cd_5.jpg` | `cee81b7d4821282bb9dbbe6850e9f6bb03e8566a1cd56f464bd64a00beff0ac7` | 230565 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_5.jpg` |
| `lantern_garden_cd_6.jpg` | `d9655b6e5a23c32ceb96266c4793cc7ef76d18e0506b80f52fa443af6c3b36f5` | 300445 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_6.jpg` |
| `lantern_garden_cd_7.jpg` | `5d303f4935bc71b5e3d40263d04ae4a98ebaf6b3b82411a5b550a67c187f754e` | 296771 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_7.jpg` |
| `lantern_garden_cd_8.jpg` | `f8c8d1030a93719daeafa76ced80bf610e75324236b4115651e5e440e72311a5` | 283441 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_8.jpg` |
| `lantern_garden_cd_9.jpg` | `aadae00ac36cf1597a59adccfa7b4836d46106666edaec20bb1d37cdc00d9ae3` | 357746 | 是 | `/workspace/landscape/batch15/lantern_garden_cd_9.jpg` |
