# Kraffer Community Garden（捷克）

- 归档编号：`kraffer_garden_jindrichuv`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：9
- 在 bot 附件库中匹配到的配图：9 / 9（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-16
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch29`
  - 本记录配图文件数：9

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `kraffer_garden_jindrichuv_1.jpg` | `620ee5e8b7837b81f69e836ffb1467ef1592dd81753b3e033a698b8396e1bbbc` | 794673 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_1.jpg` |
| `kraffer_garden_jindrichuv_2.jpg` | `5fa769e5d3a212d3b0d30712af6883a739f8f9c66aa96d25dd4e78fc63522e8a` | 724014 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_2.jpg` |
| `kraffer_garden_jindrichuv_3.jpg` | `2daeec8df86ae48145880d55273afcfa7f9855cb694f7723c5b9e0cc5ddac8de` | 713181 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_3.jpg` |
| `kraffer_garden_jindrichuv_4.jpg` | `6a53fce837817676358ff5fe6c02da288c7139b25d962b38896ea03aae26195e` | 755642 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_4.jpg` |
| `kraffer_garden_jindrichuv_5.jpg` | `5488036905c02224f2864d37d9c26e2073d078570cea6d25e5b63efae3fd6743` | 745428 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_5.jpg` |
| `kraffer_garden_jindrichuv_6.jpg` | `d6a939c539620f3499c7afddb6ab49e35edb305b4948d5ca3f031db36b37906f` | 774430 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_6.jpg` |
| `kraffer_garden_jindrichuv_7.jpg` | `00db1f80c84daa61917c2b5be3704d8bd070eb8e32bb3b12f87e45ec0cb8e164` | 1082313 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_7.jpg` |
| `kraffer_garden_jindrichuv_8.jpg` | `fcb1d376d0b28eba2fd9f3c683f9aa921be5b1bbcaa65984816e2a2af36d162e` | 601384 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_8.jpg` |
| `kraffer_garden_jindrichuv_9.jpg` | `055263c963bc7f4e32f20e858e920039619dba5064929796cde7a6bfc86c4790` | 594528 | 是 | `/workspace/landscape/batch29/kraffer_garden_jindrichuv_9.jpg` |
