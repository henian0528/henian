# 华侨城岚溪云墅素园（重庆，木守）

- 归档编号：`lanxi_villa_garden_cq`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch19`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `lanxi_villa_garden_cq_1.jpg` | `abccaede33b8c8bea606134c94d7eb274f7cf3171740efb4dda1cc2c1a357047` | 661429 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_1.jpg` |
| `lanxi_villa_garden_cq_10.jpg` | `ac8cc364da0c0216d6b192479c5f54df8e53d89fe219e6815695de21b1099b37` | 515845 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_10.jpg` |
| `lanxi_villa_garden_cq_2.jpg` | `d0a0fa0fdf5c23eba870f78f34a00baa2204b05dbbb79906580229e3a16a9f2a` | 572015 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_2.jpg` |
| `lanxi_villa_garden_cq_3.jpg` | `51f7516ce008b7a26ceeddd53dcbfe1c2acca9fb8d8ae50f1f520095d558befc` | 537183 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_3.jpg` |
| `lanxi_villa_garden_cq_4.jpg` | `c56f50f3b684d8fc71858207b157812ff64abe423f6b4bd99209a0995d3a4a1d` | 467166 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_4.jpg` |
| `lanxi_villa_garden_cq_5.jpg` | `13faa7680c1ccb5d739c349021e4427bfc86163c84687bf648d51f8f7c2b7c46` | 462357 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_5.jpg` |
| `lanxi_villa_garden_cq_6.jpg` | `52af2ce5b09d0f1ee3df4a602502fa7574de19612f04274e4a3248374b474afd` | 725126 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_6.jpg` |
| `lanxi_villa_garden_cq_7.jpg` | `414cf833a3fda953dd9be962a08a03c74208b85b0e520f17e8038bc4ea9af459` | 746124 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_7.jpg` |
| `lanxi_villa_garden_cq_8.jpg` | `1e1d0035615d13af8a02880797d5adbd396256380f7fc4bc26d580c1da81702c` | 617445 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_8.jpg` |
| `lanxi_villa_garden_cq_9.jpg` | `aef227206da92b0ef1f4ba36482aa30b6c8147da60fef0543f66c1ead1e78a3c` | 682407 | 是 | `/workspace/landscape/batch19/lanxi_villa_garden_cq_9.jpg` |
