# 北京 CBD 屋顶花园（甲南园林）

- 归档编号：`cbd_rooftop_bj`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-10
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch19`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `cbd_rooftop_bj_1.jpg` | `42131ffc972f74ec2e4cc99dc71830c6f604d2a60cf16038d992eeeaef381c4c` | 513729 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_1.jpg` |
| `cbd_rooftop_bj_10.jpg` | `84cbf60eab872ce8773307d8fad174eec36e71232481dbf9d1cf758264fe6e51` | 168023 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_10.jpg` |
| `cbd_rooftop_bj_2.jpg` | `005c0f2a496207b24bf86ca6c36c429da0be9c323b3870faf27b830f68b27464` | 484607 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_2.jpg` |
| `cbd_rooftop_bj_3.jpg` | `f1c06b468425a3b8438d452cb2de2e13fefede5f79be8533b0247af0367364a6` | 516564 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_3.jpg` |
| `cbd_rooftop_bj_4.jpg` | `83095f240b34e338ee8b797fae89290411593200e6641fb3e27e2fa17625ddf1` | 753766 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_4.jpg` |
| `cbd_rooftop_bj_5.jpg` | `7233d8bf6ff0db4ff0b41f8125f4073b3286f3849cd1c676490a38ac8d874e12` | 485590 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_5.jpg` |
| `cbd_rooftop_bj_6.jpg` | `8e535b44ae5d8a348e31778efb1fce56c490aeee3f1cddda2e4bf6d1209f5e10` | 745770 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_6.jpg` |
| `cbd_rooftop_bj_7.jpg` | `cc3fc391a72f2925bb55ee7d66bddbc22a25ef977c16d5c78d9dfb9c118d7e43` | 571374 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_7.jpg` |
| `cbd_rooftop_bj_8.jpg` | `f596903449ad9706d65b52e351cf77145876bb9ddc8f6e54639b5e1e9df18709` | 642122 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_8.jpg` |
| `cbd_rooftop_bj_9.jpg` | `8f990160c7194cb0701921f91b27b64905fae54f30bd3d54b75d0a5ad329a8b3` | 491638 | 是 | `/workspace/landscape/batch19/cbd_rooftop_bj_9.jpg` |
