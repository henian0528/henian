# 草园胡同（courtyard 早期批次）

- 归档编号：`caoyuan_hutong`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：6
- 在 bot 附件库中匹配到的配图：4 / 6（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-07前后（早期主题）
  - 出处说明：早期主题批次·小院子/庭园（目录 courtyard；期刊未用第N批编号逐项确认）
  - 发送判断：`likely_sent`
  - 本地来源：`/workspace/landscape/courtyard`
  - 注：来源 courtyard
  - 本记录配图文件数：6

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `caoyuan_hutong_1.jpg` | `2f69401187e45623173bcd0506ab76b4050ec7f990170ec3636ec1bc7fe742e4` | 277952 | 是 | `/workspace/landscape/courtyard/caoyuan_hutong_1.jpg` |
| `caoyuan_hutong_2.jpg` | `c790397126f5484fadc56ad614e19d88ff08b421d61c818ae898f11689b6ad09` | 231430 | 是 | `/workspace/landscape/courtyard/caoyuan_hutong_2.jpg` |
| `caoyuan_hutong_3.jpg` | `6d5561438c1c07751282f44ff7c39dc17546fb765157bd9924a073225b6d2784` | 229754 | 是 | `/workspace/landscape/courtyard/caoyuan_hutong_3.jpg` |
| `caoyuan_hutong_4.jpg` | `0e038c20648cabf80604f975f9c28b5504d37c0a81cb30e5f535e8165e084c34` | 222950 | 否 | `/workspace/landscape/courtyard/caoyuan_hutong_4.jpg` |
| `caoyuan_hutong_5.jpg` | `9c0b6a3c2535520927c154a7a9a33d639d5722e834092cc7513aa917470122b2` | 235393 | 否 | `/workspace/landscape/courtyard/caoyuan_hutong_5.jpg` |
| `caoyuan_hutong_6.jpg` | `b57f9d1c3867ddc62ad252016569f3507715ce059052713f53d11e1e4402786e` | 118585 | 是 | `/workspace/landscape/courtyard/caoyuan_hutong_6.jpg` |
