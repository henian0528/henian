# Carl Nielsens Allé（哥本哈根）

- 归档编号：`carl_nielsens_alle_cph`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：8
- 在 bot 附件库中匹配到的配图：8 / 8（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-15
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch26`
  - 本记录配图文件数：8

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `carl_nielsens_alle_cph_1.jpg` | `46f5f117f58b571b28832ac5c7dfa4b275e5e72d6d7b637832f53b9e2c8a5e1e` | 663988 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_1.jpg` |
| `carl_nielsens_alle_cph_2.jpg` | `7f73561fa7c29fc25ecf18addfc5d7cce43a964d58d7d2a937fe8685fb7067b8` | 601767 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_2.jpg` |
| `carl_nielsens_alle_cph_3.jpg` | `175a2a7c386e8a3a93cd2b05a77220e560b47a19affbf14f9855cb3b5fbf488c` | 517421 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_3.jpg` |
| `carl_nielsens_alle_cph_4.jpg` | `1dbfa2c6a760931276211c3ac93c7c61d64b525aff2fa2d5a3fa27f948487004` | 571181 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_4.jpg` |
| `carl_nielsens_alle_cph_5.jpg` | `c00c28916e6f0e7792b20a0e837a78f253e2c71f838b7506093df2549cd006a0` | 550389 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_5.jpg` |
| `carl_nielsens_alle_cph_6.jpg` | `9107fedfa6c4ca6bac5df670ebe691f7b9167076fb646e9fc959b35e6e8e691c` | 343877 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_6.jpg` |
| `carl_nielsens_alle_cph_7.jpg` | `d747cfb623f54f924623ba2e26f2b13e380c546500c3b160761f98f7e0fb3262` | 526011 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_7.jpg` |
| `carl_nielsens_alle_cph_8.jpg` | `9e299ab6cd8efd6634a8e720777de596da7180585978d8163d7d756ab6b710f8` | 142985 | 是 | `/workspace/landscape/batch26/carl_nielsens_alle_cph_8.jpg` |
