# 运河小亭驿（杭州拱宸桥）

- 归档编号：`canal_post_hangzhou`
- 推荐状态（汇总）：`sent`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：10 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：有（见 texts/original-* 与 sent-originals-by-date/）
- 已有摘要：无本地 summary.md

## 出现记录（不改写）

- 日期/标记：2026-10-08
  - 出处说明：private_batch
  - 发送判断：`sent`
  - 本地来源：`/workspace/landscape/batch8`
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `canal_post_hangzhou_1.jpg` | `0f8676c79b2652a056b61d44971d33baf0b369d70643aead5f85760e85538d12` | 281693 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_1.jpg` |
| `canal_post_hangzhou_10.jpg` | `0e3a16b19bbbb5256f4839e2e562992e69fe9014dacd403decfddf483384186c` | 173820 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_10.jpg` |
| `canal_post_hangzhou_2.jpg` | `bdb5703ef2a7f1e73da4b418ef8b3caa8da33d2e81060729274f3cb8811b3b11` | 228375 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_2.jpg` |
| `canal_post_hangzhou_3.jpg` | `eb6a2ad522cf68f1b28083bfaa5434101977895e93d6a808bdd129846ecea38b` | 221450 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_3.jpg` |
| `canal_post_hangzhou_4.jpg` | `7afb7b2be293b74f8d42398342357038c3cbc404d14476abcf52994e7022313c` | 177536 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_4.jpg` |
| `canal_post_hangzhou_5.jpg` | `7771ad717c36ea3027ffa5dd0d87de4e6f00a254ce7fdbd904c5739d54a37d04` | 159156 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_5.jpg` |
| `canal_post_hangzhou_6.jpg` | `91c964c7fab91a28cb745cc534afc7a4a80cde6d080e84ba360f311c4ebf186c` | 137831 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_6.jpg` |
| `canal_post_hangzhou_7.jpg` | `14f5cf9fb7c5ea3f0efad2f67358be618d7805fee6a5563fe5fc6e1909c371b1` | 265545 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_7.jpg` |
| `canal_post_hangzhou_8.jpg` | `ac0a91035bb66f88d8ad53cdc3b42708187461541a578e0b27d2aede7d03f41f` | 398162 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_8.jpg` |
| `canal_post_hangzhou_9.jpg` | `00b6a0ed673bb64474394a0a4039b131c0cdb740ce9db1dd6566615bc5edd920` | 59493 | 是 | `/workspace/landscape/batch8/canal_post_hangzhou_9.jpg` |
