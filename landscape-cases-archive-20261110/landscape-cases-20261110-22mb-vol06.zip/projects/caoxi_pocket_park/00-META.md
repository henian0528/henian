# 上海漕溪路口袋公园（清风驿站）

- 归档编号：`caoxi_pocket_park`
- 推荐状态（汇总）：`briefed`
- 显示名来源：目录名 / 来源页标题 / 日记条目（不是当时原文）
- 精选配图张数（去向前）：10
- 在 bot 附件库中匹配到的配图：0 / 10（按 SHA256；附件库可能不完整）
- 当时逐字原文：未找到（见 texts/NOTE-原文缺失.txt）
- 已有摘要：有（见 texts/summary-*，不得冒充原文）

## 出现记录（不改写）

- 日期/标记：2026-10-24
  - 出处说明：日期目录 2026-10-24（日期目录要点；内部摘要未纳入公开包）
  - 发送判断：`briefed`
  - 本地来源：`/workspace/landscape/2026-10-24/caoxi_pocket_park`
  - 注：项目子目录精选图
  - 本记录配图文件数：10

## 配图清单

| 归档文件名 | SHA256 | 字节 | 附件库 | 源路径 |
|---|---|---:|---|---|
| `caoxi_01_photo_aerial_metro.jpg` | `86acc4667051eef22b0da11172f9022b295ed627977b103c60701e010102b771` | 789836 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_01_photo_aerial_metro.jpg` |
| `caoxi_04_photo_under_bridge.jpg` | `798f56c3b020352370c16934624d16b43c5a4322d88011954301a7fae973125d` | 588245 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_04_photo_under_bridge.jpg` |
| `caoxi_05_photo_breeze_gallery.jpg` | `507f5428c1f9e8ee562890dd21f32e4f4a89d3ed4753b54444ec61d4edcd6b10` | 567341 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_05_photo_breeze_gallery.jpg` |
| `caoxi_06_photo_ecology.jpg` | `ba4966d6e1bea2b9863890d598c94a25be4e326111596c681723f79825748446` | 743790 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_06_photo_ecology.jpg` |
| `caoxi_07_photo_night.jpg` | `15e05d41d1e0d0b20a2f5327f8f0d84b773f3e251122e54686fec6f8a5e37004` | 793782 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_07_photo_night.jpg` |
| `caoxi_09_photo_layers.jpg` | `909cab860b2ae22db327de46e1c24294838f3bd013dd0ee59b664bdb1b26adb3` | 797760 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_09_photo_layers.jpg` |
| `caoxi_10_photo_dynamic_static.jpg` | `63975ce2b385a8e9ae3db8d03ad77222cb5904572b6b257226ac92efad5b4e3f` | 462369 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_10_photo_dynamic_static.jpg` |
| `caoxi_11_drawing_site_plan.jpg` | `b24218cb2584010f7c6edf99db9a2a574d266bc711073603690449b6f6e84dcc` | 388122 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_11_drawing_site_plan.jpg` |
| `caoxi_12_drawing_space_generation.jpg` | `82f77398444ad8da37c817be1aeee44abbdc299df667713eb56b4d398dbeb006` | 322106 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_12_drawing_space_generation.jpg` |
| `caoxi_13_drawing_breeze_form.jpg` | `3f10a36cc1cf7c5d116682df64409a527a879dd80b03ccf7caa6896a9bf02c61` | 187782 | 否 | `/workspace/landscape/2026-10-24/caoxi_pocket_park/caoxi_13_drawing_breeze_form.jpg` |
