# 上海泾馨绿地口袋公园 / Shanghai Jingxin Pocket Park

- 序号：2
- 项目中文名：上海泾馨绿地口袋公园
- 项目英文名：Shanghai Jingxin Pocket Park
- 地点：上海市浦东新区浦东大道苗圃路交叉口
- 设计方：U+ Design Lab
- 施工：上海大康建设有限公司
- 建成年份：2022.10—2023.01（建设时间）
- 面积：1200 ㎡
- 摄影：黎伟、王粲
- 来源：https://www.gooood.cn/shanghai-jingxin-pocket-park-china-by-u-design-lab.htm
- 类型（归档归类，非来源营销语）：口袋公园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于上海浦东新区浦东大道与苗圃路交叉口东南角，占地约1200 ㎡；改造前为绿篱围合的闲置封闭绿地。来源：https://www.gooood.cn/shanghai-jingxin-pocket-park-china-by-u-design-lab.htm
2. 洋泾街道2022年决定改造；设计时间2022.07—2022.10，建设时间2022.10—2023.01。来源：同上（项目信息）
3. 设计单位U+ Design Lab，主创王粲、郑志成；摄影黎伟、王粲；施工单位上海大康建设有限公司。来源：同上
4. 来源称场地约64M×27M、边界不规则，设计将功能空间与公园路径整合。来源：同上正文

## 图片
![▼公园整体俯视航拍，The overall aerial view of the park ©U+ Design Lab](images/01.jpg)

说明：▼公园整体俯视航拍，The overall aerial view of the park ©U+ Design Lab

![▼公园整体俯视航拍，The overall aerial view of the park ©U+ Design Lab](images/02.jpg)

说明：▼公园整体俯视航拍，The overall aerial view of the park ©U+ Design Lab

![▼功能空间与公园路径的整合，Integration of functional space and park pathway ©U+ Design Lab](images/03.jpg)

说明：▼功能空间与公园路径的整合，Integration of functional space and park pathway ©U+ Design Lab

![▼开放与实用性兼具的入口空间，Open and practical entrance space ©U+ Design Lab](images/04.jpg)

说明：▼开放与实用性兼具的入口空间，Open and practical entrance space ©U+ Design Lab

![▼开放与实用性兼具的入口空间，Open and practical entrance space ©U+ Design Lab](images/05.jpg)

说明：▼开放与实用性兼具的入口空间，Open and practical entrance space ©U+ Design Lab

![▼活力儿童空间组团，The dynamic children’s space ©U+ Design Lab](images/06.jpg)

说明：▼活力儿童空间组团，The dynamic children’s space ©U+ Design Lab

![▼活力儿童空间组团，The dynamic children’s space ©U+ Design Lab](images/07.jpg)

说明：▼活力儿童空间组团，The dynamic children’s space ©U+ Design Lab

![▼趣味性的景观体验界面，A dramatic interactive landscape interface ©U+ Design Lab](images/08.jpg)

说明：▼趣味性的景观体验界面，A dramatic interactive landscape interface ©U+ Design Lab

![▼趣味性的景观体验界面，A dramatic interactive landscape interface ©U+ Design Lab](images/09.jpg)

说明：▼趣味性的景观体验界面，A dramatic interactive landscape interface ©U+ Design Lab

![▼流动的景观体验空间，Flowing landscape experience space ©U+ Design Lab](images/10.jpg)

说明：▼流动的景观体验空间，Flowing landscape experience space ©U+ Design Lab

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
