# 上海泾彩绿地口袋公园 / Shanghai Jingcai Pocket Park

- 序号：1
- 项目中文名：上海泾彩绿地口袋公园
- 项目英文名：Shanghai Jingcai Pocket Park
- 地点：上海市浦东新区北洋泾路栖山路交叉口
- 设计方：U+ Design Lab
- 施工：上海名汇建设发展有限公司
- 建成年份：2024.10—2024.12（建设时间）
- 面积：1300 M2
- 摄影：黎伟、王粲
- 来源：https://www.gooood.cn/shanghai-jingcai-pocket-park-by-u-design-lab.htm
- 类型（归档归类，非来源营销语）：口袋公园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于上海浦东新区洋泾街道北洋泾路、栖山路路口西南角，占地约1300 M2；改造前为街角三角形下沉绿地。来源：https://www.gooood.cn/shanghai-jingcai-pocket-park-by-u-design-lab.htm
2. 洋泾街道于2023年底决定开展改造；设计时间2024.01—2024.09，建设时间2024.10—2024.12。来源：同上（项目信息）
3. 设计单位为U+ Design Lab，主创王粲、郑志成；摄影黎伟、王粲；施工单位上海名汇建设发展有限公司；业主为上海市浦东新区洋泾街道办事处。来源：同上
4. 设计结合下沉地形分层：沿道路做花园界面，中部为社区活动界面，靠近住区围墙一侧设置雨水花园与生境界面，并以蜿蜒园路和廊架组织空间。来源：同上正文

## 图片
![▼公园整体鸟瞰航拍，Overall aerial bird’s-eye view of the park-A ©U+ Design Lab](images/01.jpg)

说明：▼公园整体鸟瞰航拍，Overall aerial bird’s-eye view of the park-A ©U+ Design Lab

![▼绿地中的景观廊架 / The Landscape Pergola Amidst the Greenery ©U+ Design Lab](images/02.jpg)

说明：▼绿地中的景观廊架 / The Landscape Pergola Amidst the Greenery ©U+ Design Lab

![▼多层次的绿地空间，Multi-layered green space ©U+ Design Lab](images/03.jpg)

说明：▼多层次的绿地空间，Multi-layered green space ©U+ Design Lab

![▼多层次的绿地空间，Multi-layered green space ©U+ Design Lab](images/04.jpg)

说明：▼多层次的绿地空间，Multi-layered green space ©U+ Design Lab

![▼流动的景观空间，Fluid landscape space ©U+ Design Lab](images/05.jpg)

说明：▼流动的景观空间，Fluid landscape space ©U+ Design Lab

![▼俯瞰蜿蜒的园路，Garden paths winding through the site aerial view ©U+ Design Lab](images/06.jpg)

说明：▼俯瞰蜿蜒的园路，Garden paths winding through the site aerial view ©U+ Design Lab

![▼夜景，Night View ©U+ Design Lab](images/07.jpg)

说明：▼夜景，Night View ©U+ Design Lab

![▼雨水花园与生境花园，Rain Garden and Habitat Garden Integration ©U+ Design Lab](images/08.jpg)

说明：▼雨水花园与生境花园，Rain Garden and Habitat Garden Integration ©U+ Design Lab

![▼雨水花园与生境花园，Rain Garden and Habitat Garden Integration ©U+ Design Lab](images/09.jpg)

说明：▼雨水花园与生境花园，Rain Garden and Habitat Garden Integration ©U+ Design Lab

![▼生境设施，Habitat features ©U+ Design Lab](images/10.jpg)

说明：▼生境设施，Habitat features ©U+ Design Lab

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
