# 上海乐山绿地口袋公园 / Leshan Pocket Park, Shanghai

- 序号：4
- 项目中文名：上海乐山绿地口袋公园
- 项目英文名：Leshan Pocket Park, Shanghai
- 地点：上海市徐汇区乐山路
- 设计方：VIA 维亚景观 / VIASCAPE design
- 施工：上海徐汇园林发展有限公司
- 建成年份：2021年10月（建成时间）
- 面积：5600㎡
- 摄影：CreatAR Images，孙轶家
- 来源：https://www.gooood.cn/leshan-pocket-park-shanghai-by-viascape-design.htm
- 类型（归档归类，非来源营销语）：口袋公园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于上海市徐汇区乐山路，来源称乐山绿地始建于1980年代，占地约5600㎡，为周边集中公共开放空间，本次为更新。来源：https://www.gooood.cn/leshan-pocket-park-shanghai-by-viascape-design.htm
2. 设计单位VIA维亚景观，主持设计师孙轶家；设计时间2021年1月，建成时间2021年10月；施工单位上海徐汇园林发展有限公司；业主上海市徐汇区绿化管理中心；摄影CreatAR Images，孙轶家。来源：同上（项目信息）
3. 建成要素包括来源所述全长80米的“众乐之廊”和400米环形慢跑道等。来源：同上图片说明与正文

## 图片
![▼项目场地鸟瞰，Aerial view of the project site ©CreatAR Images](images/01.jpg)

说明：▼项目场地鸟瞰，Aerial view of the project site ©CreatAR Images

![▼口袋公园鸟瞰，Aerial view of the pocket park ©CreatAR Images，孙轶家](images/02.jpg)

说明：▼口袋公园鸟瞰，Aerial view of the pocket park ©CreatAR Images，孙轶家

![▼口袋公园鸟瞰，Aerial view of the pocket park ©CreatAR Images，孙轶家](images/03.jpg)

说明：▼口袋公园鸟瞰，Aerial view of the pocket park ©CreatAR Images，孙轶家

![▼全长80米的“众乐之廊”，The 80-meter-long “shared happiness” gallery ©CreatAR Images](images/04.jpg)

说明：▼全长80米的“众乐之廊”，The 80-meter-long “shared happiness” gallery ©CreatAR Images

![▼供人赏玩停歇的公共空间，A public space for people to enjoy and play ©CreatAR Images](images/05.jpg)

说明：▼供人赏玩停歇的公共空间，A public space for people to enjoy and play ©CreatAR Images

![▼供人赏玩停歇的公共空间，A public space for people to enjoy and play ©CreatAR Images](images/06.jpg)

说明：▼供人赏玩停歇的公共空间，A public space for people to enjoy and play ©CreatAR Images

![▼400米的环形慢跑道，The 400-meter circular race track ©CreatAR Images，孙轶家](images/07.jpg)

说明：▼400米的环形慢跑道，The 400-meter circular race track ©CreatAR Images，孙轶家

![▼400米的环形慢跑道，The 400-meter circular race track ©CreatAR Images，孙轶家](images/08.jpg)

说明：▼400米的环形慢跑道，The 400-meter circular race track ©CreatAR Images，孙轶家

![▼从公园步道望向长廊，View from the park path to gallery ©CreatAR Images](images/09.jpg)

说明：▼从公园步道望向长廊，View from the park path to gallery ©CreatAR Images

![▼共享阅读空间近景，Detailed view of the shared reading room ©CreatAR Images](images/10.jpg)

说明：▼共享阅读空间近景，Detailed view of the shared reading room ©CreatAR Images

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
