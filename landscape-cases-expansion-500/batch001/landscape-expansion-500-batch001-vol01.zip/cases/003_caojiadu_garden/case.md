# 上海曹家渡花园更新设计 / Caojiadu Garden Renovation project

- 序号：3
- 项目中文名：上海曹家渡花园更新设计
- 项目英文名：Caojiadu Garden Renovation project
- 地点：上海市静安区康定路余姚路交叉口
- 设计方：VIA 维亚景观 / VIASCAPE design
- 施工：上海静安园林绿化发展有限公司
- 建成年份：2021年5月（项目完成时间）
- 面积：约3000㎡
- 摄影：CreatAR Images、孙轶家
- 来源：https://www.gooood.cn/caojiadu-garden-renovation-shanghai-by-viascape-design.htm
- 类型（归档归类，非来源营销语）：口袋公园更新
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于上海市静安区康定路余姚路交叉口，原名康余绿地，占地约3000㎡，最初采用日本设计师星野嘉郎方案于2003年建成，本次为更新设计。来源：https://www.gooood.cn/caojiadu-garden-renovation-shanghai-by-viascape-design.htm
2. 设计单位VIA维亚景观 / VIASCAPE design，主持设计师孙轶家、周密；完成时间2021年5月；施工单位上海静安园林绿化发展有限公司；业主上海市静安区绿化管理中心；摄影CreatAR Images、孙轶家。来源：同上（项目信息）
3. 来源指出现状问题包括传统园林节点与大量曲线景墙形成的内向复杂空间，以及常绿大乔木下中下木长势较差。来源：同上正文

## 图片
![▼场地鸟瞰，Bird ‘s-eye view of the site © CreatAR Images](images/01.jpg)

说明：▼场地鸟瞰，Bird ‘s-eye view of the site © CreatAR Images

![▼场地鸟瞰，Bird ‘s-eye view of the site © CreatAR Images](images/02.jpg)

说明：▼场地鸟瞰，Bird ‘s-eye view of the site © CreatAR Images

![▼西侧入口节点，West side entrance node © CreatAR Images](images/03.jpg)

说明：▼西侧入口节点，West side entrance node © CreatAR Images

![▼西侧入口节点，West side entrance node © CreatAR Images](images/04.jpg)

说明：▼西侧入口节点，West side entrance node © CreatAR Images

![▼发光休闲台阶坐凳与绿化景观， Luminous leisure bench seating with green landscape © CreatAR Images](images/05.jpg)

说明：▼发光休闲台阶坐凳与绿化景观， Luminous leisure bench seating with green landscape © CreatAR Images

![▼发光休闲台阶坐凳与绿化景观， Luminous leisure bench seating with green landscape © CreatAR Images](images/06.jpg)

说明：▼发光休闲台阶坐凳与绿化景观， Luminous leisure bench seating with green landscape © CreatAR Images

![▼发光休闲台阶引发的活动，Activities triggered by the luminous leisure steps © CreatAR Images](images/07.jpg)

说明：▼发光休闲台阶引发的活动，Activities triggered by the luminous leisure steps © CreatAR Images

![▼休闲台阶、遛鸟空间与绿化景观的融合，The integration of leisure steps, bird walking space and green landscape © CreatAR Images](images/08.jpg)

说明：▼休闲台阶、遛鸟空间与绿化景观的融合，The integration of leisure steps, bird walking space and green landscape © CreatAR Images

![▼景观空间引发的趣味活动，Interesting activities triggered by landscape space © CreatAR Images](images/09.jpg)

说明：▼景观空间引发的趣味活动，Interesting activities triggered by landscape space © CreatAR Images

![▼景观空间引发的趣味活动，Interesting activities triggered by landscape space © CreatAR Images](images/10.jpg)

说明：▼景观空间引发的趣味活动，Interesting activities triggered by landscape space © CreatAR Images

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
