# 明亭 / Pavilion Lucida

- 序号：6
- 项目中文名：明亭
- 项目英文名：Pavilion Lucida
- 地点：江苏省苏州市虎丘区武夷山路
- 设计方：深源创新实验室 / Deep Origin Lab
- 施工：上海标定合嘉科技有限公司
- 建成年份：2023（完成年份）
- 面积：15 ㎡（建筑面积）
- 摄影：陈颢，DONG IMAGE / Hao Chen, Dong Image
- 来源：https://www.gooood.cn/pavilion-lucida-by-deep-origin-lab.htm
- 类型（归档归类，非来源营销语）：景观亭/装置
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：9张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称明亭 Pavilion Lucida，类型为展厅/景观装置；地址为江苏省苏州市虎丘区武夷山路；建筑面积15 ㎡；完成年份2023，设计年份2022。来源：https://www.gooood.cn/pavilion-lucida-by-deep-origin-lab.htm
2. 设计方深源创新实验室，主创刘秦榕，成员姚璐、许朝财；摄影陈颢、DONG IMAGE；施工方上海标定合嘉科技有限公司；材料包括超白玻璃管、钢结构、水磨石。来源：同上（项目信息）
3. 业主为苏州科技城科新文化旅游发展有限公司。来源：同上

## 图片
![▼项目概览，Overview of the project ©DONG IMAGE](images/01.jpg)

说明：▼项目概览，Overview of the project ©DONG IMAGE

![▼亭子特写，Close-up of the pavilion ©陈颢](images/02.jpg)

说明：▼亭子特写，Close-up of the pavilion ©陈颢

![▼亭子特写，Close-up of the pavilion ©陈颢](images/03.jpg)

说明：▼亭子特写，Close-up of the pavilion ©陈颢

![▼特写，Close-up ©陈颢](images/04.jpg)

说明：▼特写，Close-up ©陈颢

![▼夜景，Night view ©陈颢](images/05.jpg)

说明：▼夜景，Night view ©陈颢

![▼内部空间对比，Comparison between day and night ©陈颢](images/06.jpg)

说明：▼内部空间对比，Comparison between day and night ©陈颢

![▼内部空间对比，Comparison between day and night ©陈颢](images/07.jpg)

说明：▼内部空间对比，Comparison between day and night ©陈颢

![▼光与影，Light and shadow ©陈颢](images/08.jpg)

说明：▼光与影，Light and shadow ©陈颢

![▼光与影，Light and shadow ©陈颢](images/09.jpg)

说明：▼光与影，Light and shadow ©陈颢

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
