# 介园 / Jie Yuan

- 序号：5
- 项目中文名：介园
- 项目英文名：Jie Yuan
- 地点：北京市（来源仅列至市）
- 设计方：介介工作室 / Jiejie Studio
- 施工：来源未列
- 建成年份：2022年05月（竣工时间）
- 面积：约800平方米（庭院面积）
- 摄影：Chill Shine丘文三映 / Chill Shine
- 来源：https://www.gooood.cn/jie-yuan-private-garden-in-beijing-suburb-by-jiejie-studio.htm
- 类型（归档归类，非来源营销语）：私人别墅庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称介园，类型为建筑与庭院景观，地址来源仅列北京市；庭院面积约800平方米，竣工时间2022年05月。来源：https://www.gooood.cn/jie-yuan-private-garden-in-beijing-suburb-by-jiejie-studio.htm
2. 设计方介介工作室，主创明冠宇；植物设计石韦；结构设计马智刚；摄影师Chill Shine丘文三映；业主为个人。来源：同上（项目信息）
3. 来源称设计建造历时三年，园子位于京郊带园现代别墅；南园主体为轻质钢结构介亭，采用双层屋顶，第一层屋顶实则为花架。来源：同上正文
4. 东园由泠泠舫、映舟、曲廊、池潭组成，围绕观鱼展开。来源：同上正文

## 图片
![▼庭院空间概览，Courtyard overview ©Chill Shine丘文三映](images/01.jpg)

说明：▼庭院空间概览，Courtyard overview ©Chill Shine丘文三映

![▼南园草坪看向介亭，A view from the lawn to the Jie Pavilion in the South garden ©Chill Shine丘文三映](images/02.jpg)

说明：▼南园草坪看向介亭，A view from the lawn to the Jie Pavilion in the South garden ©Chill Shine丘文三映

![▼介亭概览，Overview of the Jie Pavilion ©Chill Shine丘文三映](images/03.jpg)

说明：▼介亭概览，Overview of the Jie Pavilion ©Chill Shine丘文三映

![▼介亭外观近景，Close shot of the Jie Pavilion ©Chill Shine丘文三映](images/04.jpg)

说明：▼介亭外观近景，Close shot of the Jie Pavilion ©Chill Shine丘文三映

![▼介亭外观近景，Close shot of the Jie Pavilion ©Chill Shine丘文三映](images/05.jpg)

说明：▼介亭外观近景，Close shot of the Jie Pavilion ©Chill Shine丘文三映

![▼介亭的露台，The terrace of the Jie Pavilion ©Chill Shine丘文三映](images/06.jpg)

说明：▼介亭的露台，The terrace of the Jie Pavilion ©Chill Shine丘文三映

![▼石墙近景，Close shot of the stone wall ©Chill Shine丘文三映](images/07.jpg)

说明：▼石墙近景，Close shot of the stone wall ©Chill Shine丘文三映

![▼石墙近景，Close shot of the stone wall ©Chill Shine丘文三映](images/08.jpg)

说明：▼石墙近景，Close shot of the stone wall ©Chill Shine丘文三映

![▼由水面看向泠泠舫，A view from the pond to the boat house ©Chill Shine丘文三映](images/09.jpg)

说明：▼由水面看向泠泠舫，A view from the pond to the boat house ©Chill Shine丘文三映

![▼由水面看向泠泠舫，A view from the pond to the boat house ©Chill Shine丘文三映](images/10.jpg)

说明：▼由水面看向泠泠舫，A view from the pond to the boat house ©Chill Shine丘文三映

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
