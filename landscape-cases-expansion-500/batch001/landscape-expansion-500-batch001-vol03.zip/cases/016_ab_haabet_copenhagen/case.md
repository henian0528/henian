# AB Haabet 庭院 / AB Haabet

- 序号：16
- 项目中文名：AB Haabet 庭院
- 项目英文名：AB Haabet
- 地点：Amagerbrogade, Amager, Copenhagen, Denmark
- 设计方：VEGA landskab / VEGA Landskab
- 施工：来源未列
- 建成年份：2021（页面栏目 Built in 2021）
- 面积：来源未列
- 摄影：VEGA Landskab and Clara Knudsen
- 来源：https://landezine-award.com/ab-haabet/
- 类型（归档归类，非来源营销语）：住宅内庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；面积
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. AB Haabet庭院位于丹麦哥本哈根Amager的Amagerbrogade一侧，为合作住房协会AB Haabet居民的半私密庭院，建于1960年停车楼板之上。来源：https://landezine-award.com/ab-haabet/
2. 设计为VEGA landskab；页面栏目写Built in 2021；摄影VEGA Landskab and Clara Knudsen。面积、施工来源未列。来源：同上
3. 来源称东侧朝向街道布置停留、游戏与绿化，西侧布置自行车停放与主要交通，以争取日照并减少对住宅立面的干扰。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
