# Briggen Park Passage / Briggen Park Passage

- 序号：17
- 项目中文名：Briggen Park Passage
- 项目英文名：Briggen Park Passage
- 地点：Nordhemsgatan 28, 413 06 Gothenburg, Sweden
- 设计方：MARELD landskapsarkitekter / Mareld；壁画：charquipunk
- 施工：来源写由市政府自有团队施工，未列公司名
- 建成年份：2015-2017（Year Built）
- 面积：来源未列
- 摄影：来源未列
- 来源：https://landezine-award.com/briggen-park-passage/
- 类型（归档归类，非来源营销语）：口袋公园/街区通道
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：面积；摄影
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. Briggen Park Passage位于瑞典哥德堡Nordhemsgatan 28，Saluhallen Briggen食品市场后的内院通道；设计年份2013-2016，建设年份2015-2017。来源：https://landezine-award.com/briggen-park-passage/
2. 景观设计MARELD landskapsarkitekter / Mareld；壁画charquipunk。面积与摄影来源未列。来源：同上
3. 来源称预算极低，设计部分义务完成，材料多用市政其他项目剩余及风暴倒下的橡木、二手花岗岩铺石，并由市政人员施工；过程中还加做了收集市场屋顶雨水的小型雨水花园。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
