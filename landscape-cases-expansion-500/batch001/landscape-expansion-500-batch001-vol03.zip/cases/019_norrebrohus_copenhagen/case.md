# Nørrebrohus 庭院 / Nørrebrohus

- 序号：19
- 项目中文名：Nørrebrohus 庭院
- 项目英文名：Nørrebrohus
- 地点：Nørrebro, Copenhagen, Denmark
- 设计方：VEGA landskab
- 施工：来源未列
- 建成年份：2017（Year Built）
- 面积：来源未列
- 摄影：Simon Jeppesen and VEGA landskab
- 来源：https://landezine-award.com/norrebrohus-2/
- 类型（归档归类，非来源营销语）：住宅内庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；面积
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于丹麦哥本哈根Nørrebro，为住宅合作社AB Nørrebrohus的私密内院更新；设计年份2015-2017，建成2017。来源：https://landezine-award.com/norrebrohus-2/
2. 设计为VEGA landskab；摄影Simon Jeppesen and VEGA landskab。面积、施工来源未列。来源：同上
3. 来源称更新前中部绿地几乎不可达，日常交通走边缘沥青；更新后扩大中部绿色，增加柳树小丘、砖径、果树，并把自行车停在绿荫顶下。来源：同上正文（Landezine正文亦见于早期打开的 https://landezine.com/norrebrohus-by-vega-landskab/ ）

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
