# Jardin des Joyeux（快乐花园） / Jardin des Joyeux / Happy garden - Aubervilliers

- 序号：20
- 项目中文名：Jardin des Joyeux（快乐花园）
- 项目英文名：Jardin des Joyeux / Happy garden - Aubervilliers
- 地点：Maladrerie garden city, Aubervilliers, France（巴黎近郊）
- 设计方：Wagon Landscaping / Wagon-landscaping
- 施工：来源写由 Wagon 自行实施现场工程，未另列公司
- 建成年份：Landezine 项目数据：design year 2016，year of construction 2016；事务所官网叙述2015年沥青层被打碎后实施过渡方案，页末未单列竣工年
- 面积：1,600 m²（事务所官网）
- 摄影：Yann Monel et Wagon / Yann Monel and Wagon
- 来源：https://www.wagon-landscaping.fr/eng_jardin-joyeux-aubervilliers-copy ； https://landezine.com/jardin-des-joyeux-by-wagon-landscaping/
- 类型（归档归类，非来源营销语）：口袋花园/岩石园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：图纸（本批未另存或来源页图纸未收入）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：0张（本项目本批未另存）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于法国奥贝维利埃（Aubervilliers）Maladrerie花园城市入口处的废弃停车场。事务所官网称将该完全人工、不透水的地面转变为1,600 m²岩石园。来源：https://www.wagon-landscaping.fr/eng_jardin-joyeux-aubervilliers-copy
2. 设计与实施：Wagon Landscaping；摄影photos : Yann Monel et Wagon；客户官网写Council house of Aubervilliers city。来源：同上
3. 官网叙述2015年沥青层被打碎后留置现场，再以约5厘米基质覆盖破碎沥青、不外运材料；种植150种以上适应干旱贫瘠条件的植物，并长期由事务所以“减法维护”进行管养。来源：同上
4. Landezine项目数据另列：design year 2016，year of construction 2016，area 1600 m2，budget 35,000 €，image credits wagon landscaping（该页本次直接抓取遇站点验证，内容来自已打开的项目页）。来源：https://landezine.com/jardin-des-joyeux-by-wagon-landscaping/

## 图片
![WAGON-JARDIN-DES-JOYEUX©yannmonel-6008.jpg](images/01.jpg)

说明：WAGON-JARDIN-DES-JOYEUX©yannmonel-6008.jpg

![WAGON-JARDIN-DES-JOYEUX©yannmonel-6004.jpg](images/02.jpg)

说明：WAGON-JARDIN-DES-JOYEUX©yannmonel-6004.jpg

![_IGP7354.jpg](images/03.jpg)

说明：_IGP7354.jpg

![T6880x4544-00139.jpg](images/04.jpg)

说明：T6880x4544-00139.jpg

![_V9A7191.jpg](images/05.jpg)

说明：_V9A7191.jpg

![_V9A7783-2.jpg](images/06.jpg)

说明：_V9A7783-2.jpg

![T6880x4544-00028.jpg](images/07.jpg)

说明：T6880x4544-00028.jpg

![_V9A7730.jpg](images/08.jpg)

说明：_V9A7730.jpg

![_V9A7841.jpg](images/09.jpg)

说明：_V9A7841.jpg

![T6880x4544-00166.jpg](images/10.jpg)

说明：T6880x4544-00166.jpg
