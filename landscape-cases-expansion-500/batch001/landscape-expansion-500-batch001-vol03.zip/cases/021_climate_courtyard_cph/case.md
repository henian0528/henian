# Climate Courtyard / Klima Karre / Climate Courtyard / Klima Karre

- 序号：21
- 项目中文名：Climate Courtyard / Klima Karre
- 项目英文名：Climate Courtyard / Klima Karre
- 地点：Otto Mallings Gade, 2100 Copenhagen / 2100 København
- 设计方：MBYland and Urbanlab Nordic（事务所官网：项目在 URBANlab Nordic 完成，Mette Bruun Yde 于2016年3月前为该事务所共同创始人）
- 施工：来源未列；官网合作方 Holmsgaard Ingeniører
- 建成年份：事务所官网 År: 2018；Landezine 项目数据 Opening/Built: 2016。两处来源年份不一致，并存不裁断。
- 面积：1.400 sqm（Landezine Project Data）
- 摄影：Jan Jul Søndergaard og Urbanlab nordic / Jan Jul Søndergaard/ Urbanlab Nordic；无人机：KeepUp（Landezine）
- 来源：https://www.mbyland.dk/klima-karre ； https://landezine.com/climate-courtyard-by-mbyland/
- 类型（归档归类，非来源营销语）：气候适应性住宅庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；图纸（本批未另存或来源页图纸未收入）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：0张（本项目本批未另存）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于Copenhagen Otto Mallings Gade, 2100；事务所官网项目名Klima Karre，称其为既有庭院更新，并属于Østerbro的Klimakvarter气候街区项目。来源：https://www.mbyland.dk/klima-karre
2. 设计：MBYland and Urbanlab Nordic（官网注明项目在URBANlab Nordic完成，Mette Bruun Yde于2016年3月前为该所共同创始人）；合作Holmsgaard Ingeniører；业主Københavns kommune；摄影Jan Jul Søndergaard og Urbanlab nordic。来源：同上
3. 年份两处来源不一致：事务所官网År: 2018；Landezine项目数据Opening/Built: 2016，面积1.400 sqm，无人机照片KeepUp。此处并存，不裁断。来源：官网及 https://landezine.com/climate-courtyard-by-mbyland/

## 图片
![ClimateKarré_Copenhagen_01.jpg](images/01.jpg)

说明：ClimateKarré_Copenhagen_01.jpg

![ClimateKarré_Copenhagen_02.jpg](images/02.jpg)

说明：ClimateKarré_Copenhagen_02.jpg

![ClimateKarré_Copenhagen_05.jpg](images/03.jpg)

说明：ClimateKarré_Copenhagen_05.jpg

![ClimateKarré_Copenhagen_07.jpg](images/04.jpg)

说明：ClimateKarré_Copenhagen_07.jpg

![ClimateKarré_Copenhagen_06.jpg](images/05.jpg)

说明：ClimateKarré_Copenhagen_06.jpg

![ClimateKarré_Copenhagen_34.jpg](images/06.jpg)

说明：ClimateKarré_Copenhagen_34.jpg

![ClimateKarré_Copenhagen_46.jpg](images/07.jpg)

说明：ClimateKarré_Copenhagen_46.jpg

![ClimateKarré_Copenhagen_42.jpg](images/08.jpg)

说明：ClimateKarré_Copenhagen_42.jpg

![ClimateKarré_Copenhagen_12.jpg](images/09.jpg)

说明：ClimateKarré_Copenhagen_12.jpg

![ClimateKarré_Copenhagen_16.jpg](images/10.jpg)

说明：ClimateKarré_Copenhagen_16.jpg
