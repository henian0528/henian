# 苏州河顺义路口袋公园驿站 / Service Station in Shunyi Road Pocket Park, Suzhou Creek

- 序号：23
- 项目中文名：苏州河顺义路口袋公园驿站
- 项目英文名：Service Station in Shunyi Road Pocket Park, Suzhou Creek
- 地点：上海普陀区顺义路南侧，滨临苏州河
- 设计方：周蔚 + 张斌 / 致正建筑工作室；景观设计：上海市园林设计研究总院有限公司 / 刘晓嫣、钱成裕、徐元玮、赵腾
- 施工：上海盛鑫建设工程有限公司
- 建成年份：2021.05-2021.07（建造时间）
- 面积：基地面积1305 m²
- 摄影：杨敏
- 来源：https://www.gooood.cn/service-station-in-front-of-putuo-park-suzhou-creek-service-station-in-shunyi-road-pocket-park-suzhou-creek-shanghai-by-atelier-z.htm
- 类型（归档归类，非来源营销语）：口袋公园驿站
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 苏州河顺义路口袋公园驿站位于上海普陀区顺义路南侧、滨临苏州河；基地面积1305 m²，占地343 m²，建筑面积346 m²；设计2020.11-2021.04，建造2021.05-2021.07。来源：同上页面（与普陀公园驿站同一篇文章，项目信息分列）
2. 建筑师周蔚 + 张斌 / 致正建筑工作室；景观设计上海市园林设计研究总院有限公司 / 刘晓嫣、钱成裕、徐元玮、赵腾；施工总包上海盛鑫建设工程有限公司；摄影杨敏。来源：同上
3. 来源称驿站位于顺义路尽端与滨河光复西路之间的口袋公园内。来源：同上正文

## 图片
![▼苏州河鸟瞰，aerial view of the Suzhou Creek © 杨敏](images/01.jpg)

说明：▼苏州河鸟瞰，aerial view of the Suzhou Creek © 杨敏

![▼建筑鸟瞰，aerial view of the project © 杨敏](images/02.jpg)

说明：▼建筑鸟瞰，aerial view of the project © 杨敏

![▼建筑鸟瞰，aerial view of the project © 杨敏](images/03.jpg)

说明：▼建筑鸟瞰，aerial view of the project © 杨敏

![▼西侧留作步行通道，the west side is reserved as a pedestrian passage © 杨敏](images/04.jpg)

说明：▼西侧留作步行通道，the west side is reserved as a pedestrian passage © 杨敏

![▼西侧留作步行通道，the west side is reserved as a pedestrian passage © 杨敏](images/05.jpg)

说明：▼西侧留作步行通道，the west side is reserved as a pedestrian passage © 杨敏

![▼连廊与座位，the connecting corridor © 杨敏](images/06.jpg)

说明：▼连廊与座位，the connecting corridor © 杨敏

![▼内向小庭，inner courtyard © 杨敏](images/07.jpg)

说明：▼内向小庭，inner courtyard © 杨敏

![▼内向小庭，inner courtyard © 杨敏](images/08.jpg)

说明：▼内向小庭，inner courtyard © 杨敏

![▼天台花园，roof garden © 杨敏](images/09.jpg)

说明：▼天台花园，roof garden © 杨敏

![▼庭院，patio © 杨敏](images/10.jpg)

说明：▼庭院，patio © 杨敏

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
