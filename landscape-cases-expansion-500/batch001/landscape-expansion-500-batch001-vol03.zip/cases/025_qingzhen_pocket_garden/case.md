# 城市微更新·家门口的口袋花园 / Urban Micro-renewal, The Pocket Garden

- 序号：25
- 项目中文名：城市微更新·家门口的口袋花园
- 项目英文名：Urban Micro-renewal, The Pocket Garden
- 地点：贵州省 贵阳清镇
- 设计方：贵阳蓝调迈德景观规划设计有限公司（蓝调迈德期间作品；主创设计师：蒋俊）
- 施工：重庆四通园林绿化有限公司
- 建成年份：2020年（完成年份）
- 面积：1500平方米
- 摄影：JING STUDIO+MIND STUDIO
- 来源：https://mooool.com/urban-micro-renewal-the-pocket-garden-by-mind-studio.html
- 类型（归档归类，非来源营销语）：口袋花园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：9张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：2张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称城市微更新·家门口的口袋花园（蓝调迈德期间作品），地点贵州省贵阳清镇，完成年份2020年，项目面积1500平方米。来源：https://mooool.com/urban-micro-renewal-the-pocket-garden-by-mind-studio.html
2. 设计公司贵阳蓝调迈德景观规划设计有限公司，主创设计师蒋俊；景观施工重庆四通园林绿化有限公司；摄影师JING STUDIO+MIND STUDIO；开发商广大城投集团。来源：同上（项目信息）

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![▼多样的交流空间 A variety of communication spaces.](images/02.jpg)

说明：▼多样的交流空间 A variety of communication spaces.

![▼多样的交流空间 A variety of communication spaces.](images/03.jpg)

说明：▼多样的交流空间 A variety of communication spaces.

![来源页配图](images/04.jpg)

说明：来源页配图

![▼水中树池及水体旁高大的乔木为卡座空间提供了舒适的乘凉休息区域 The tree pond in the water pool and the tall trees beside the water provide a comfortable resting area for the deck space.](images/05.jpg)

说明：▼水中树池及水体旁高大的乔木为卡座空间提供了舒适的乘凉休息区域 The tree pond in the water pool and the tall trees beside the water provide a comfortable resting area for the deck space.

![▼从建筑看向廊架方向 from architecture to gallery](images/06.jpg)

说明：▼从建筑看向廊架方向 from architecture to gallery

![▼从建筑看向廊架方向 from architecture to gallery](images/07.jpg)

说明：▼从建筑看向廊架方向 from architecture to gallery

![▼通道关系实景图 channel relationship picture](images/08.jpg)

说明：▼通道关系实景图 channel relationship picture

![▼通道关系实景图 channel relationship picture](images/09.jpg)

说明：▼通道关系实景图 channel relationship picture

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)
