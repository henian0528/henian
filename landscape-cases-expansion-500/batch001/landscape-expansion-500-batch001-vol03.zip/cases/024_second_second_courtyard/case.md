# SECOND + SECOND Courtyard / SECOND + SECOND Courtyard

- 序号：24
- 项目中文名：SECOND + SECOND Courtyard
- 项目英文名：SECOND + SECOND Courtyard
- 地点：120 N 2nd St, Minneapolis, MN 55401, USA
- 设计方：TEN x TEN（LILA 页面标题区 www.tenxtenstudio.com，并列入该事务所作品）；建筑：Snow Kreilich Architects
- 施工：来源未列
- 建成年份：2020（Year Built）
- 面积：The 1-acre site（约4047㎡，来源按场地叙述，非单独庭院面积）
- 摄影：VONDELINDE
- 来源：https://landezine-award.com/second-second-courtyard/
- 类型（归档归类，非来源营销语）：街区庭院与花园街
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：2张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. SECOND + SECOND Courtyard位于美国明尼阿波利斯120 N 2nd St，Historic North Loop District；设计年份2016，建成2020。来源：https://landezine-award.com/second-second-courtyard/
2. 景观设计TEN x TEN（页面标题区www.tenxtenstudio.com）；建筑Snow Kreilich Architects；摄影VONDELINDE。施工来源未列。来源：同上
3. 来源称场地约1-acre，含Garden Street、the Portal与Foundry Court等空间，将私人开发与公共领域衔接。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)
