# 宋庄微社区公园 / Songzhuang Micro Community Park

- 序号：18
- 项目中文名：宋庄微社区公园
- 项目英文名：Songzhuang Micro Community Park
- 地点：Xiaopu Village, Songzhuang, Tongzhou, Beijing, China（北京通州宋庄小堡）
- 设计方：Crossboundaries
- 施工：来源未列
- 建成年份：2021（Year Built）
- 面积：来源未列
- 摄影：来源未列
- 来源：https://landezine-award.com/songzhuang-micro-community-park/
- 类型（归档归类，非来源营销语）：微社区公园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；面积；摄影；图纸（本批未另存或来源页图纸未收入）
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：0张（本项目本批未另存）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于中国北京通州宋庄小堡，靠近Xiaopu Cultural Plaza的停车场旁线性街景；设计年份2020，建成2021。来源：https://landezine-award.com/songzhuang-micro-community-park/
2. 设计为Crossboundaries。面积、施工、摄影来源未列。来源：同上
3. 来源称主要构件为带座位的穿孔灰砖墙，并与穿孔耐候钢交替；街道一侧有耐候钢种植池，场地以黄色环道串联一系列户外“房间”。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图
