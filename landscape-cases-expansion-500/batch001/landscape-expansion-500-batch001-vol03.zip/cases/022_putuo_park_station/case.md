# 苏州河普陀公园驿站 / Service Station in Front of Putuo Park, Suzhou Creek

- 序号：22
- 项目中文名：苏州河普陀公园驿站
- 项目英文名：Service Station in Front of Putuo Park, Suzhou Creek
- 地点：上海市区光复西路255号普陀公园东南门前
- 设计方：周蔚 + 张斌 / 致正建筑工作室；景观设计：上海市园林设计研究总院有限公司 / 刘晓嫣、钱成裕、徐元玮、赵腾
- 施工：上海普陀市政工程有限公司
- 建成年份：2021.05-2021.07（建造时间）
- 面积：基地面积771 m²
- 摄影：杨敏
- 来源：https://www.gooood.cn/service-station-in-front-of-putuo-park-suzhou-creek-service-station-in-shunyi-road-pocket-park-suzhou-creek-shanghai-by-atelier-z.htm
- 类型（归档归类，非来源营销语）：公园门前驿站
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：9张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 苏州河普陀公园驿站位于上海市区光复西路255号普陀公园东南门前；基地面积771 m²，占地330.2 m²，建筑面积334.3 m²；设计2020.11-2021.04，建造2021.05-2021.07。来源：https://www.gooood.cn/service-station-in-front-of-putuo-park-suzhou-creek-service-station-in-shunyi-road-pocket-park-suzhou-creek-shanghai-by-atelier-z.htm
2. 建筑师周蔚 + 张斌 / 致正建筑工作室，项目建筑师徐跃；景观设计上海市园林设计研究总院有限公司 / 刘晓嫣、钱成裕、徐元玮、赵腾；施工总包上海普陀市政工程有限公司；摄影杨敏。来源：同上（项目信息）
3. 用途包括休息室、展厅、公园门卫、公共卫生间；结构为钢木混合。来源：同上

## 图片
![▼项目与周边环境顶视图，top view of the project and surrounding environment © 杨敏](images/01.jpg)

说明：▼项目与周边环境顶视图，top view of the project and surrounding environment © 杨敏

![▼项目与周边环境顶视图，top view of the project and surrounding environment © 杨敏](images/02.jpg)

说明：▼项目与周边环境顶视图，top view of the project and surrounding environment © 杨敏

![▼驿站鸟瞰，aerial view of the station © 杨敏](images/03.jpg)

说明：▼驿站鸟瞰，aerial view of the station © 杨敏

![▼回形敞廊，circular open cloister © 杨敏](images/04.jpg)

说明：▼回形敞廊，circular open cloister © 杨敏

![▼回形敞廊，circular open cloister © 杨敏](images/05.jpg)

说明：▼回形敞廊，circular open cloister © 杨敏

![▼庭院露台，courtyard terrace © 杨敏](images/06.jpg)

说明：▼庭院露台，courtyard terrace © 杨敏

![▼庭院露台，courtyard terrace © 杨敏](images/07.jpg)

说明：▼庭院露台，courtyard terrace © 杨敏

![▼建筑细部，details of the cloister © 杨敏](images/08.jpg)

说明：▼建筑细部，details of the cloister © 杨敏

![▼建筑细部，details of the cloister © 杨敏](images/09.jpg)

说明：▼建筑细部，details of the cloister © 杨敏

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
