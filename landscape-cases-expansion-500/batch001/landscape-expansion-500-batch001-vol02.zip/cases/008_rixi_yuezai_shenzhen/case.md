# 日熹阁与月在庭 / Sunshine Loft and Moon Pavilion

- 序号：8
- 项目中文名：日熹阁与月在庭
- 项目英文名：Sunshine Loft and Moon Pavilion
- 地点：深圳市光明区虹桥公园内
- 设计方：南沙原创建筑设计工作室 / NODE Architecture & Urbanism
- 施工：中国中铁十局集团有限公司；月在庭清水混凝土：中建一局集团华南建设有限公司
- 建成年份：日熹阁建设时间2023年9月-2024年10月；月在庭建设时间2023年8月-2024年5月
- 面积：日熹阁用地664㎡、建筑533㎡；月在庭用地3678㎡、建筑300㎡
- 摄影：张超（张超摄影工作室）、胡康榆（直角建筑摄影）
- 来源：https://www.gooood.cn/sunshine-loft-and-moon-pavilion-by-node-architecture-urbanism.htm
- 类型（归档归类，非来源营销语）：公园内亭阁与庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：无（基础字段均有来源表述）
- 图片：10张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：3张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于深圳市光明区虹桥公园内，包含日熹阁与月在庭两组；来源标明建成。来源：https://www.gooood.cn/sunshine-loft-and-moon-pavilion-by-node-architecture-urbanism.htm
2. 日熹阁建设时间2023年9月-2024年10月，用地664㎡、建筑533㎡；月在庭建设时间2023年8月-2024年5月，用地3678㎡、建筑300㎡。来源：同上（项目信息）
3. 设计单位南沙原创建筑设计工作室，主创建筑师刘珩；摄影师张超、胡康榆；施工方包括中国中铁十局集团有限公司，月在庭清水混凝土为中建一局集团华南建设有限公司。来源：同上
4. 月在庭含来源所称“内”坡地庭院与“外”临湖自然雨水花园庭院等室外空间。来源：同上图片说明

## 图片
![▼项目概览， Bird’s-eye View of Diverse Homology Pavilion © 陈家旭](images/01.jpg)

说明：▼项目概览， Bird’s-eye View of Diverse Homology Pavilion © 陈家旭

![▼地面层公共空间实景场，The Ground Floor Public Space © 张超](images/02.jpg)

说明：▼地面层公共空间实景场，The Ground Floor Public Space © 张超

![▼十一假期的日熹阁，Sunshine Loft during the National Day Holiday © 张超](images/03.jpg)

说明：▼十一假期的日熹阁，Sunshine Loft during the National Day Holiday © 张超

![▼二层平台空间实景，Second Floor Platform Space © 张超](images/04.jpg)

说明：▼二层平台空间实景，Second Floor Platform Space © 张超

![▼“内”坡地庭院，Inner Sloped Courtyard © 张超](images/05.jpg)

说明：▼“内”坡地庭院，Inner Sloped Courtyard © 张超

![▼“外”临湖自然雨水花园庭院，External Lakeside Rain Garden © 张超](images/06.jpg)

说明：▼“外”临湖自然雨水花园庭院，External Lakeside Rain Garden © 张超

![▼一层平台与主庭院，First Floor Platform and Main Courtyard © 胡康榆](images/07.jpg)

说明：▼一层平台与主庭院，First Floor Platform and Main Courtyard © 胡康榆

![▼墙廊空间，Wall Corridor Space © 胡康榆](images/08.jpg)

说明：▼墙廊空间，Wall Corridor Space © 胡康榆

![▼月在庭中的框景，Framed View in the Moon Pavilion © 胡康榆](images/09.jpg)

说明：▼月在庭中的框景，Framed View in the Moon Pavilion © 胡康榆

![▼月在庭鸟瞰实景景，Aerial View of Moon Pavilion © 胡康榆](images/10.jpg)

说明：▼月在庭鸟瞰实景景，Aerial View of Moon Pavilion © 胡康榆

## 图纸
![](drawings/01.jpg)

![](drawings/02.jpg)

![](drawings/03.jpg)
