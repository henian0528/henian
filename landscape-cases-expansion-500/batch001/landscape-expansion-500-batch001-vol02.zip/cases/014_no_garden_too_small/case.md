# No Garden is Too Small / No Garden is Too Small

- 序号：14
- 项目中文名：No Garden is Too Small
- 项目英文名：No Garden is Too Small
- 地点：Litomyšl, Czech Republic
- 设计方：Partero / Atelier Partero（页面“more by Partero”及事务所作品列表）
- 施工：来源未列
- 建成年份：2018（Year Built）
- 面积：来源描述为狭小天井庭院，未列具体面积
- 摄影：来源未列
- 来源：https://landezine-award.com/no-garden-is-too-small/
- 类型（归档归类，非来源营销语）：小型城市庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；摄影；图纸（本批未另存或来源页图纸未收入）
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：0张（本项目本批未另存）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称No Garden is Too Small，地点Litomyšl, Czech Republic；设计年份2017，建成2018。来源：https://landezine-award.com/no-garden-is-too-small/
2. 页面标题区将本项目列入Partero / Atelier Partero作品（more by Partero）。面积、施工、摄影来源未列。来源：同上
3. 来源称这是夹在建筑与棚屋之间的狭小天井庭院，地面为多种规格石材铺装，并有锈蚀金属板围合墙及木兰枝图案穿孔；既有木兰树为院落冠盖。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图
