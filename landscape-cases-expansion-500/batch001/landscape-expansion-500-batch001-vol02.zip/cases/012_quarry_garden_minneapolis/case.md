# Quarry Garden / Quarry Garden

- 序号：12
- 项目中文名：Quarry Garden
- 项目英文名：Quarry Garden
- 地点：Minneapolis, MN, USA
- 设计方：TEN x TEN
- 施工：来源未列
- 建成年份：2020（Year Built）
- 面积：来源描述沉陷花岗石“采石场”庭为25’ x 50’，未列花园总面积
- 摄影：Gaffer Photography
- 来源：https://landezine-award.com/quarry-garden/
- 类型（归档归类，非来源营销语）：私人住宅庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称Quarry Garden，地点Minneapolis, MN, USA；设计年份2016，建成2020。来源：https://landezine-award.com/quarry-garden/
2. 景观设计为TEN x TEN（页面标题区 www.tenxtenstudio.com，并列入该事务所作品）；建筑事务所MSR Design；摄影Gaffer Photography。来源：同上
3. 来源称核心是约25’×50’的沉陷花岗石“采石场”空间，围以约四十株白桦与铁杉；花园还包含浮动平台、门廊、户外厨房和绿色巷道等室外房间。总面积来源未列。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
