# Leave the Door Open / Leave the Door Open

- 序号：15
- 项目中文名：Leave the Door Open
- 项目英文名：Leave the Door Open
- 地点：Yangzijiang Avenue 228-1, Jianye District, Nanjing, Jiangsu, China（南京市建邺区少年宫下沉小花园）
- 设计方：The Landscape Design Team：Shuyue He, Yihui Shi, Yimeng Peng, Qining Yan, Shaomin Qi, Mingxin Chen, Ming Li, Xin Gao, Sheng Huang, Yumeng Wang, Lanbin You, Xiaoyun Yang, Min cheng, Rui Zhang, Xinyu Zhao, Xinqi Zhang, Suoqi Wu；页面同时归属 Nanjing Forestry University / 南京林业大学（yuanlin.njfu.edu.cn）
- 施工：The Constructing Consultants: Min Zhang, Fei Wan（顾问，施工方名称来源未列）
- 建成年份：2021（Year Built）
- 面积：143 square meters
- 摄影：来源未列
- 来源：https://landezine-award.com/leave-the-door-open/
- 类型（归档归类，非来源营销语）：下沉小花园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；摄影
- 图片：8张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 位于中国南京市建邺区Yangzijiang Avenue 228-1（少年宫建筑转角下沉小花园），面积仅143 square meters，建成2021，设计工作2020年9–11月，施工2021年2月至4月中旬。来源：https://landezine-award.com/leave-the-door-open/
2. 来源列出景观设计团队Shuyue He等，并在页面归属Nanjing Forestry University / 南京林业大学（yuanlin.njfu.edu.cn）；施工顾问Min Zhang, Fei Wan。摄影来源未列。来源：同上
3. 来源称总造价约人民币100,000，用于少年宫相关自然教育课程，种植计划覆盖逾60个蔬果品种。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

![来源页配图](images/08.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
