# Avant-Garden / Avant-Garden

- 序号：11
- 项目中文名：Avant-Garden
- 项目英文名：Avant-Garden
- 地点：捷克共和国 Telč / Telč, Czech Republic
- 设计方：Atelier Partero（首席建筑师 Jakub Finger）
- 施工：Landeco Atelier
- 建成年份：2019年（竣工年份）
- 面积：来源仅写“小型城市花园、私人空间”，未列具体面积
- 摄影：Atelier Partero archive
- 来源：https://mooool.com/avant-garden-by-atelier-partero.html
- 类型（归档归类，非来源营销语）：小型城市私人花园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：图纸（本批未另存或来源页图纸未收入）
- 图片：7张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：0张（本项目本批未另存）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称Avant-Garden，地点捷克共和国Telč，竣工年份2019年，规模来源写为“小型城市花园、私人空间”，未列具体面积。来源：https://mooool.com/avant-garden-by-atelier-partero.html
2. 景观/建筑公司Atelier Partero，首席建筑师Jakub Finger；施工Landeco Atelier；图片来源Atelier Partero archive。来源：同上（项目信息）
3. 来源称花园距特尔奇广场很近，位于小镇历史中心后方、保护区边缘；任务是为仅有一棵树的空旷花园注入活力，同时保留邻里共享属性；花园面积不大并分为三层。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图
