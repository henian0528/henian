# 白石花园 / White Stone Garden

- 序号：10
- 项目中文名：白石花园
- 项目英文名：White Stone Garden
- 地点：北京
- 设计方：北京甲南园林设计事务所 / Jianan Landscape Design Studio, Beijing
- 施工：来源未列
- 建成年份：2025年6月（建成时间）
- 面积：300㎡
- 摄影：来源未列
- 来源：https://mooool.com/white-stone-garden-by-jianan-landscape-design-office.html
- 类型（归档归类，非来源营销语）：私家庭院
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；摄影
- 图片：6张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目名称白石花园，类型私家庭院，地点北京，建成时间2025年6月，花园面积300㎡。来源：https://mooool.com/white-stone-garden-by-jianan-landscape-design-office.html
2. 设计单位北京甲南园林设计事务所 / Jianan Landscape Design Studio, Beijing。施工、摄影来源未列。来源：同上（项目信息）

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
