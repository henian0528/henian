# 罗瓦蒂博物馆花园 / Rovati Museum garden

- 序号：13
- 项目中文名：罗瓦蒂博物馆花园
- 项目英文名：Rovati Museum garden
- 地点：Corso Venezia, 52, Milan, Italy
- 设计方：景观设计方在来源页项目数据中未列；页内建筑署名为 MCA – Mario Cucinella Architects，并提及 landscaping company 与 Landscape Director 但未写出名称
- 施工：来源未列
- 建成年份：2022（Year Completed）
- 面积：来源未列
- 摄影：来源未列
- 来源：https://landezine-award.com/rovati-museum-between-art-culture-and-nature/
- 类型（归档归类，非来源营销语）：博物馆口袋花园
- 状态：qualified
- 重复核查：已与原220案例及附录6条交叉核对（中英名/设计方/地点/年份/来源URL，含同项目异名），未见同一项目。
- 缺字段：施工；面积；摄影；景观设计方（页内未单列名称）
- 图片：7张建成实景（已排除改造前、分析图、模型与图纸），最多10张，原图下载后未经再压缩或改绘。
- 图纸：1张（见 drawings/）
- 核验：2026-11-13 打开原项目页抓取，未用搜索摘要代替原文。字段按来源原有表述，缺值写来源未列。

## 事实要点
1. 项目为米兰Corso Venezia 52号Fondazione Luigi Rovati艺术博物馆相关花园，完成年份2022。来源：https://landezine-award.com/rovati-museum-between-art-culture-and-nature/
2. 页面项目数据列出的建筑事务所为MCA – Mario Cucinella Architects；景观设计方、面积、摄影在该页项目数据中未列，正文提及 landscaping company 与 Landscape Director 但未写出名称。来源：同上
3. 来源将该园描述为与历史建筑地下扩建一体的口袋花园，并记录补植椴树、山毛榉及既有朴树、木兰等。来源：同上正文

## 图片
![来源页配图](images/01.jpg)

说明：来源页配图

![来源页配图](images/02.jpg)

说明：来源页配图

![来源页配图](images/03.jpg)

说明：来源页配图

![来源页配图](images/04.jpg)

说明：来源页配图

![来源页配图](images/05.jpg)

说明：来源页配图

![来源页配图](images/06.jpg)

说明：来源页配图

![来源页配图](images/07.jpg)

说明：来源页配图

## 图纸
![](drawings/01.jpg)
